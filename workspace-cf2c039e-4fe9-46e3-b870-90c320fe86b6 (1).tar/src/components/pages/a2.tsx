"use client";

import { useRef } from "react";
import { PageProps } from "@/components/solar/types";
import { usePageChrome } from "@/components/solar/usePageChrome";
import { ThemeToggle } from "@/components/solar/ThemeToggle";
import { HeroImage, InsetImage } from "@/components/solar/GuideImage";
import { FaqList } from "@/components/solar/Faq";

export default function A2Page({ onNavigate }: PageProps) {
  const rootRef = useRef<HTMLElement>(null);
  usePageChrome(rootRef);
  const year = new Date().getFullYear();

  return (
    <div className="page" id="page-a2" ref={rootRef}>
      <header>
        <div className="wrap nav">
          <a
            className="logo"
            href="#"
            onClick={(e) => { e.preventDefault(); onNavigate("home"); }}
          >
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </a>
          <nav className="nav-links">
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
              All guides
            </a>
            <a href="#a2-good">When it works</a>
            <a href="#a2-bad">When it doesn&apos;t</a>
            <a href="#a2-questions">Key questions</a>
            <a href="#a2-faq">FAQ</a>
          </nav>
          <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
            <a
              className="btn btn-teal btn-nav"
              href="#"
              onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
            >
              Run battery analysis
            </a>
            <ThemeToggle />
            <button className="burger" aria-label="Menu" data-burger>
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>
        <nav className="mobile-menu" data-mobile-menu>
          <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
            All guides
          </a>
          <a href="#a2-good">When it works</a>
          <a href="#a2-bad">When it doesn&apos;t</a>
          <a href="#a2-questions">Key questions</a>
          <a href="#a2-faq">FAQ</a>
          <a
            href="#"
            className="mm-primary"
            onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
          >
            Run battery analysis →
          </a>
        </nav>
      </header>

      <main id="top">
        {/* ---------- HERO ---------- */}
        <section className="dark hero-a">
          <div className="wrap">
            <nav className="crumb" aria-label="Breadcrumb">
              <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("home"); }}>
                Home
              </a>
              <span>›</span>
              <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
                Guides
              </a>
              <span>›</span>
              <b>Battery storage</b>
            </nav>
            <span className="pill pill-lime">✦ &nbsp;Guide · Battery storage</span>
            <h1>
              Battery storage: when does it make{" "}
              <em className="c-teal" style={{ fontStyle: "normal" }}>
                financial sense?
              </em>
            </h1>
            <p className="lede">
              Batteries promise energy independence, backup power and more
              self-generated solar. The real question is not whether batteries are
              good technology — it is whether one makes sense for{" "}
              <strong style={{ color: "var(--band-ink)" }}>your</strong> household.
            </p>
            <div className="meta-row">
              <span className="m-chip">🗓️ Updated 20/08/26</span>
              <span className="m-chip">📖 7 min read</span>
              <span className="m-chip">🇦🇺 Australian market</span>
              <span className="m-chip">✅ Figures are typical ranges — not quotes</span>
            </div>
            <HeroImage
              src="/guides/a2.jpg"
              alt="A house with rooftop solar panels and a wall-mounted home battery unit"
              caption="A home battery stores surplus daytime solar so it can be used in the evening, when grid imports are costliest."
            />
          </div>
        </section>

        <div className="wrap a-layout">
          {/* ---------- STICKY SIDEBAR ---------- */}
          <aside className="side">
            <div className="side-card">
              <h4>On this page</h4>
              <nav className="toc">
                <a href="#a2-intro">Not automatically worthwhile</a>
                <a href="#a2-good">When batteries work well</a>
                <a href="#a2-bad">When they may not</a>
                <a href="#a2-questions">8 questions to ask</a>
                <a href="#a2-assess">Assess your options</a>
                <a href="#a2-quality">Battery quality matters</a>
                <a href="#a2-take">Key takeaways</a>
                <a href="#a2-faq">FAQ</a>
              </nav>
            </div>
            <div className="side-card side-cta">
              <h4>Free analysis</h4>
              <p>Not sure whether a battery is justified? Run the numbers first.</p>
              <a
                className="btn btn-teal"
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
                style={{ width: "100%" }}
              >
                Run battery analysis
              </a>
            </div>
            <div className="side-card">
              <h4>More guides</h4>
              <nav className="toc">
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("pl"); }}>
                  Before you get solar quotes
                </a>
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("a1"); }}>
                  Read your electricity bill
                </a>
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("a3"); }}>
                  Time-of-use tariffs &amp; solar
                </a>
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("qd"); }}>
                  Queensland quality installs
                </a>
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
                  Browse all guides →
                </a>
              </nav>
            </div>
          </aside>

          {/* ---------- ARTICLE PROSE ---------- */}
          <article className="prose">
            <h2 id="a2-intro">A battery is not automatically worthwhile</h2>
            <p>
              Solar batteries have become increasingly popular in Australia. But a
              battery is a significant investment, and for many households the
              financial return may not justify the cost.
            </p>
            <div className="stat-chips">
              <div className="chip-stat">
                <b>$10k–$20k+</b>
                <span>Typical installed cost range</span>
              </div>
              <div className="chip-stat">
                <b>7–12 yrs</b>
                <span>Common payback range, scenario-dependent</span>
              </div>
              <div className="chip-stat">
                <b>It depends</b>
                <span>Viability depends on usage, tariff &amp; existing solar</span>
              </div>
            </div>

            <InsetImage
              src="/guides/a2-inset.png"
              alt="A home battery storage unit and EV charger mounted on an exterior wall"
              caption="Home batteries pair with rooftop solar and EV charging to shift energy use away from expensive peak periods."
            />
            <h2 id="a2-good">When batteries tend to work well financially</h2>
            <span className="pc-head pc-good">✓&nbsp; Green lights</span>
            <div className="pc-grid">
              <div className="pc-item g">
                <span className="pc-n">1</span>
                <h3>High consumption with low daytime use of solar</h3>
                <p>
                  High evening consumption, significant peak-priced grid imports and
                  limited ability to shift usage mean stored solar can displace
                  expensive imports.
                </p>
              </div>
              <div className="pc-item g">
                <span className="pc-n">2</span>
                <h3>Time-of-use tariffs with large rate differences</h3>
                <p>
                  When peak import rates (30–40¢) tower over off-peak (10–15¢) and
                  feed-in tariffs (5–10¢), charging off-peak and discharging on peak
                  can improve returns. See our{" "}
                  <a
                    href="#"
                    onClick={(e) => { e.preventDefault(); onNavigate("a3"); }}
                    style={{ color: "var(--teal-deep)", fontWeight: 600 }}
                  >
                    TOU tariff guide
                  </a>
                  .
                </p>
              </div>
              <div className="pc-item g">
                <span className="pc-n">3</span>
                <h3>Low or declining feed-in tariffs</h3>
                <p>
                  Every kWh exported at 5–10¢ instead of offsetting a 25–35¢ import
                  rate is a lost opportunity. Batteries increase self-consumption and
                  capture more of that value.
                </p>
              </div>
              <div className="pc-item g">
                <span className="pc-n">4</span>
                <h3>Planned increases in household load</h3>
                <p>
                  An electric vehicle, pool, spa, electric heating/cooling or a heat
                  pump hot water system can change usage patterns and improve battery
                  economics over time.
                </p>
              </div>
              <div className="pc-item g">
                <span className="pc-n">5</span>
                <h3>Backup power requirements</h3>
                <p>
                  Frequent outages or critical loads (medical equipment, home office,
                  security) add value beyond pure financial return — a lifestyle
                  decision, not purely a financial one.
                </p>
              </div>
            </div>

            <h2 id="a2-bad">When batteries may not make financial sense</h2>
            <span className="pc-head pc-bad">✕&nbsp; Caution signs</span>
            <div className="pc-grid">
              <div className="pc-item b">
                <span className="pc-n">1</span>
                <h3>Low-consumption households</h3>
                <p>
                  Using 10–15 kWh/day with significant solar exports may not generate
                  enough battery utilisation to justify the cost.
                </p>
              </div>
              <div className="pc-item b">
                <span className="pc-n">2</span>
                <h3>Flat-rate tariffs</h3>
                <p>
                  Without time-based price differences, load-shifting benefits are
                  reduced. Batteries perform better where arbitrage exists.
                </p>
              </div>
              <div className="pc-item b">
                <span className="pc-n">3</span>
                <h3>Generous feed-in tariffs</h3>
                <p>
                  At 15–20¢ per kWh, exporting solar may be nearly as valuable as
                  storing it — shrinking the battery&apos;s advantage.
                </p>
              </div>
              <div className="pc-item b">
                <span className="pc-n">4</span>
                <h3>Short time horizon</h3>
                <p>
                  If you plan to move within 3–5 years, typical payback periods may
                  exceed your ownership period.
                </p>
              </div>
              <div className="pc-item b">
                <span className="pc-n">5</span>
                <h3>Already well-matched solar</h3>
                <p>
                  If your system is appropriately sized and you consume most
                  generation during the day, a battery may add diminishing returns.
                </p>
              </div>
            </div>

            <h2 id="a2-questions">Eight questions to ask before buying a battery</h2>
            <div className="q8">
              <div className="qi">
                <em>01</em>
                <h3>What is my current self-consumption rate?</h3>
                <p>How much of your solar generation do you already use versus export?</p>
              </div>
              <div className="qi">
                <em>02</em>
                <h3>What are my import and export rates?</h3>
                <p>
                  The gap between what you pay for grid electricity and what exports
                  earn drives battery value.
                </p>
              </div>
              <div className="qi">
                <em>03</em>
                <h3>What is my usage pattern?</h3>
                <p>Do you consume more energy in the evening, when solar is not generating?</p>
              </div>
              <div className="qi">
                <em>04</em>
                <h3>What is the total installed cost?</h3>
                <p>What is the cost per kWh of usable battery capacity — not just headline price?</p>
              </div>
              <div className="qi">
                <em>05</em>
                <h3>What is the expected payback period?</h3>
                <p>Based on your usage and tariff, how long until the battery pays for itself?</p>
              </div>
              <div className="qi">
                <em>06</em>
                <h3>What is the warranty and expected lifespan?</h3>
                <p>How many cycles or years is the battery warranted for?</p>
              </div>
              <div className="qi">
                <em>07</em>
                <h3>Can the battery expand later?</h3>
                <p>If your needs change, can you add capacity?</p>
              </div>
              <div className="qi">
                <em>08</em>
                <h3>Does it support my electricity plan?</h3>
                <p>
                  Can it participate in virtual power plants or wholesale market
                  programs where available?
                </p>
              </div>
            </div>

            <h2 id="a2-assess">How to assess battery options for your household</h2>
            <p>
              The Solar Sensei calculator models hundreds of battery configurations
              against your actual consumption, tariff and existing solar system. It
              can show:
            </p>
            <ul className="plain">
              <li>How different battery capacities would affect your grid imports</li>
              <li>The potential savings from increased self-consumption</li>
              <li>The payback period for various battery sizes</li>
              <li>Whether a battery adds value on your current electricity plan</li>
              <li>How the outcome may change if you also switch plans</li>
            </ul>
            <p>
              This helps you understand whether a battery is financially justified —
              or whether you would be better served by additional solar, efficiency
              measures, or staying with your current setup.
            </p>

            <h2 id="a2-quality">If you proceed: battery quality matters</h2>
            <ul className="plain">
              <li>
                <strong>Warranty terms</strong> — cycle life, calendar life and degradation guarantees
              </li>
              <li>
                <strong>Expandability</strong> — whether modules can be added later
              </li>
              <li>
                <strong>Compatibility</strong> — with your existing inverter and system
              </li>
              <li>
                <strong>Brand reputation</strong> — an established manufacturer more likely to honour warranties long-term
              </li>
              <li>
                <strong>Grid services</strong> — virtual power plant and wholesale program participation where available
              </li>
            </ul>
            <p>
              A higher-quality battery may cost more upfront but can deliver better
              long-term value through longevity, flexibility and reliability.
            </p>

            <div className="take" id="a2-take">
              <h3>Key takeaways</h3>
              <ul>
                <li>Batteries are not automatically worthwhile for every household</li>
                <li>
                  Financial viability depends on consumption patterns, tariff structure and existing solar
                </li>
                <li>Time-of-use tariffs and low feed-in tariffs tend to improve battery economics</li>
                <li>Payback periods typically range from 7–12 years depending on circumstances</li>
                <li>Quality, warranty and expandability matter for long-term value</li>
                <li>Independent analysis before purchase helps avoid costly mistakes</li>
              </ul>
            </div>

            <h2 id="a2-faq">Frequently asked questions</h2>
            <FaqList
              items={[
                {
                  q: "Are solar batteries worth it in Australia?",
                  a: "It depends on your household. Batteries tend to work best financially with high evening consumption, time-of-use tariffs with large rate differences, and low feed-in tariffs. For other profiles, additional solar or plan changes may deliver better value.",
                },
                {
                  q: "How much does a home battery cost?",
                  a: "Installed costs typically start around $10,000 and can exceed $20,000 depending on capacity, brand and installation complexity.",
                },
                {
                  q: "How long does a battery take to pay for itself?",
                  a: "Payback periods commonly fall between 7 and 12 years, depending on consumption patterns, tariffs, battery cost and how much solar surplus is available to store.",
                },
                {
                  q: "Is a battery worth it on a flat-rate tariff?",
                  a: "The financial benefit is usually reduced. Load-shifting relies on price differences between periods, so single-rate tariffs limit arbitrage. Some value can remain from increased solar self-consumption.",
                },
                {
                  q: "Can I add a battery to my existing solar system?",
                  a: "In most cases, yes. Existing solar can be included when assessing whether additional storage may improve your position, including compatibility considerations with your current inverter.",
                },
                {
                  q: "Does Solar Sensei sell batteries?",
                  a: "No. Solar Sensei is an independent analysis tool. It does not sell systems or earn commissions from installers. The calculator compares battery options against alternatives so you can judge whether a battery is justified for your home.",
                },
              ]}
            />

            <section className="cta-sec" id="a2-cta">
              <div className="cta-box">
                <span className="pill pill-lime">Free battery analysis</span>
                <h2>Is a battery justified for your home — or not?</h2>
                <p>
                  Model battery sizes against your actual usage and tariff, compare
                  them with additional solar and plan changes, and see the payback
                  picture before you commit.
                </p>
                <a
                  className="btn btn-teal"
                  href="#"
                  onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
                >
                  Run your free battery analysis →
                </a>
                <div className="cta-trust">
                  <span>🔒 No obligation to proceed</span>
                  <span>📍 Australia-wide</span>
                  <span>📋 Indicative modelling — not a quote</span>
                </div>
              </div>
            </section>

            <h2>Keep reading</h2>
            <div className="related">
              <a
                className="rel-card"
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("pl"); }}
              >
                <small>Guide · Quotes</small>
                <h3>Before you get solar quotes</h3>
                <p>Take your battery verdict into a smarter quoting process.</p>
              </a>
              <a
                className="rel-card"
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("a1"); }}
              >
                <small>Guide · Your bill</small>
                <h3>How to read your electricity bill</h3>
                <p>The six figures that shape any solar or battery analysis.</p>
              </a>
              <a
                className="rel-card"
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("a3"); }}
              >
                <small>Guide · Tariffs</small>
                <h3>Time-of-use tariffs &amp; solar</h3>
                <p>Why rate differences are the engine of battery economics.</p>
              </a>
            </div>
          </article>
        </div>
      </main>

      {/* ---------- MINI FOOTER ---------- */}
      <footer className="f-mini">
        <div className="wrap fmini">
          <div className="f-logo">
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </div>
          <nav>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
              All guides
            </a>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("a1"); }}>
              Bill guide
            </a>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("a3"); }}>
              Tariff guide
            </a>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("pl"); }}>
              Before you quote
            </a>
          </nav>
          <p>
            Independent analysis for Australian homeowners. Indicative modelling only —
            not a quote or financial advice. © {year} Solar Sensei.
          </p>
        </div>
      </footer>
    </div>
  );
}
