"use client";

import { useRef } from "react";
import { PageProps } from "@/components/solar/types";
import { usePageChrome } from "@/components/solar/usePageChrome";
import { ThemeToggle } from "@/components/solar/ThemeToggle";
import { HeroImage, InsetImage } from "@/components/solar/GuideImage";

export default function QdPage({ onNavigate }: PageProps) {
  const rootRef = useRef<HTMLElement>(null);
  usePageChrome(rootRef);
  const year = new Date().getFullYear();

  return (
    <div className="page" id="page-qd" ref={rootRef}>
      <header>
        <div className="wrap nav">
          <a
            className="logo"
            href="#"
            onClick={(e) => { e.preventDefault(); onNavigate("home"); }}
          >
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </a>
          <nav className="nav-links">
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
              All guides
            </a>
            <a href="#qd-mislead">Why quotes mislead</a>
            <a href="#qd-vic">QLD vs Victoria</a>
            <a href="#qd-ask">Before you sign</a>
          </nav>
          <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
            <a
              className="btn btn-teal btn-nav"
              href="#"
              onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
            >
              Start free analysis
            </a>
            <ThemeToggle />
            <button className="burger" aria-label="Menu" data-burger>
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>
        <nav className="mobile-menu" data-mobile-menu>
          <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
            All guides
          </a>
          <a href="#qd-mislead">Why quotes mislead</a>
          <a href="#qd-vic">QLD vs Victoria</a>
          <a href="#qd-ask">Before you sign</a>
          <a
            href="#"
            className="mm-primary"
            onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
          >
            Start free analysis →
          </a>
        </nav>
      </header>

      <main id="top">
        {/* ---------- HERO ---------- */}
        <section className="dark hero-a">
          <div className="wrap">
            <nav className="crumb" aria-label="Breadcrumb">
              <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("home"); }}>
                Home
              </a>
              <span>›</span>
              <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
                Guides
              </a>
              <span>›</span>
              <b>Queensland installs</b>
            </nav>
            <span className="pill pill-orange">✦ &nbsp;Guide · Queensland</span>
            <h1>
              Getting quotes for solar in Queensland? Here&apos;s how to ensure
              a{" "}
              <em className="c-orange" style={{ fontStyle: "normal" }}>
                quality install
              </em>
            </h1>
            <p className="lede">
              A good price does not guarantee a good install. Unlike Victoria,
              Queensland doesn&apos;t require an independent inspection after
              every residential solar installation — which leaves homeowners with
              less protection unless they arrange extra checks themselves.
            </p>
            <div className="meta-row">
              <span className="m-chip">🗓️ Updated 28/08/26</span>
              <span className="m-chip">📖 5 min read</span>
              <span className="m-chip">📍 Queensland-specific</span>
              <span className="m-chip">✅ General information — verify requirements with your installer</span>
            </div>
            <HeroImage
              src="/guides/qd.jpg"
              alt="A modern Queensland home with solar panels across its roof under a blue sky"
              caption="Queensland homes see some of Australia's strongest solar generation — but install quality still varies between providers."
            />
          </div>
        </section>

        <div className="wrap a-layout">
          {/* ---------- STICKY SIDEBAR ---------- */}
          <aside className="side">
            <div className="side-card">
              <h4>On this page</h4>
              <nav className="toc">
                <a href="#qd-intro">The inspection gap</a>
                <a href="#qd-mislead">Why quote comparisons mislead</a>
                <a href="#qd-vic">What Victoria does differently</a>
                <a href="#qd-help">How Solar Sensei helps</a>
                <a href="#qd-ask">What to ask before you sign</a>
                <a href="#qd-value">Why this is better value</a>
              </nav>
            </div>
            <div className="side-card side-cta">
              <h4>Free analysis</h4>
              <p>Know what system you need before comparing installers.</p>
              <a
                className="btn btn-teal"
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
                style={{ width: "100%" }}
              >
                Start free analysis
              </a>
            </div>
            <div className="side-card">
              <h4>More guides</h4>
              <nav className="toc">
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("pl"); }}>
                  Before you get solar quotes
                </a>
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("a2"); }}>
                  Battery: when it makes sense
                </a>
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("a1"); }}>
                  Read your electricity bill
                </a>
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
                  Browse all guides →
                </a>
              </nav>
            </div>
          </aside>

          {/* ---------- ARTICLE PROSE ---------- */}
          <article className="prose">
            <h2 id="qd-intro">The inspection gap</h2>
            <p>
              If you&apos;re comparing solar quotes in Queensland, the number one
              thing to remember is this:{" "}
              <strong>a good price does not guarantee a good install.</strong>{" "}
              Unlike Victoria, Queensland does not require an independent
              inspection after every residential solar installation, which leaves
              homeowners with less protection unless they arrange extra checks
              themselves.
            </p>
            <p>
              That gap matters because poor installation work is not always
              obvious. A system can look fine from the ground and still have
              issues with wiring, isolators, mounting, cable protection, or
              overall compliance. Those problems can affect safety, performance,
              warranty coverage, and long-term reliability.
            </p>

            <InsetImage
              src="/guides/qd-inset.jpg"
              alt="An engineer in safety gear inspecting rooftop solar panels during an independent quality check"
              caption="Independent inspection of a completed install — checking panel mounting, wiring and inverter performance."
            />
            <h2 id="qd-mislead">Why solar quote comparisons can be misleading</h2>
            <p>
              Most homeowners compare solar quotes by looking at the total price,
              panel brand, inverter brand, and maybe the installer&apos;s
              reputation. That&apos;s a sensible starting point, but it is only
              part of the picture. What often gets missed is the quality control
              process behind the quote.
            </p>
            <p>
              In Queensland, there is no legal requirement for a homeowner to
              have solar inspected after installation, although the government
              recommends using licensed or appropriately qualified professionals
              for close-quarters inspections and checking the system periodically.
              That means the homeowner is often relying on the installer&apos;s
              own process unless they pay for a separate inspection.
            </p>

            <h2 id="qd-vic">What Victoria does differently</h2>
            <p>
              Victoria takes a stricter approach to solar installation
              compliance. Its system includes an independent electrical inspection
              regime, and prescribed electrical installations such as solar
              systems must be inspected before they can be energised. Victorian
              guidance also sets out detailed compliance expectations for
              installers, covering matters like wiring, conduit, equipment
              placement, and safety labelling.
            </p>
            <p>
              That extra step gives homeowners more certainty. Instead of
              assuming the job was done properly, there is an independent check
              that helps verify the system meets the required standard before it
              is considered complete.
            </p>
            <div className="yn-grid">
              <div className="yn y">
                <h3>Victoria — independent check</h3>
                <ul>
                  <li>Independent electrical inspection regime</li>
                  <li>Solar systems must be inspected before energisation</li>
                  <li>
                    Detailed compliance expectations for installers — wiring,
                    conduit, equipment placement, labelling
                  </li>
                </ul>
              </div>
              <div className="yn n">
                <h3>Queensland — self-reliance</h3>
                <ul>
                  <li>No mandatory post-install inspection for residential solar</li>
                  <li>Homeowner relies on the installer&apos;s own quality process</li>
                  <li>
                    Independent checks are optional and arranged at the
                    homeowner&apos;s initiative
                  </li>
                </ul>
              </div>
            </div>

            <h2 id="qd-help">How Solar Sensei helps</h2>
            <p>
              Solar Sensei is built to give Queensland homeowners a stronger
              level of confidence than a standard quote comparison. The first
              layer is installer selection: Solar Sensei works with only a small
              number of installers in each area, chosen for reputation, track
              record, and business stability rather than just the cheapest price.
            </p>
            <p>
              The second layer is the important one: every install arranged
              through Solar Sensei includes a free independent inspection. That
              gives homeowners a third-party report confirming whether the system
              was installed to regulation and to the expected standard.
            </p>
            <div className="steps" style={{ gridTemplateColumns: "1fr 1fr" }}>
              <div className="step-card">
                <div className="step-num">1</div>
                <h3>Vetted installer selection</h3>
                <p>
                  A small panel of installers per area, chosen for reputation,
                  track record and business stability — not just price.
                </p>
              </div>
              <div className="step-card">
                <div className="step-num">2</div>
                <h3>Free independent inspection</h3>
                <p>
                  Every install includes a third-party report confirming the
                  system meets regulation and the expected standard.
                </p>
              </div>
            </div>
            <p>
              The result is simple. Homeowners get help finding the right system,
              the right installer, and then an independent check that confirms
              the work was completed properly.
            </p>

            <h2 id="qd-ask">What to ask before you sign</h2>
            <p>
              If you&apos;re reviewing quotes now, ask these questions before
              you commit:
            </p>
            <div className="q-grid">
              <div className="q-item">Is the installer accredited and appropriately licensed?</div>
              <div className="q-item">What exact equipment is being supplied?</div>
              <div className="q-item">Is compliance paperwork included?</div>
              <div className="q-item">Will the install be independently inspected?</div>
              <div className="q-item">Who do I contact if something looks wrong later?</div>
            </div>
            <p>
              These questions are practical, not technical. They help separate a
              polished sales pitch from a genuinely well-controlled installation
              process.
            </p>

            <h2 id="qd-value">Why this is better value</h2>
            <p>
              A lot of people assume independent checking will add cost. With
              Solar Sensei, it doesn&apos;t. The homeowner pays the same system
              price they would pay going directly to the installer, but with the
              added benefit of vetting and an independent inspection included at
              no extra cost.
            </p>
            <p>
              That makes the service especially useful for people who want more
              than a cheap quote. If your goal is a solar system that is installed
              properly, documented properly, and backed by a clear compliance
              check, Solar Sensei gives you a much stronger position from day
              one.
            </p>

            <div className="icb">
              <div>
                <h3>Start with the right system — then the right installer.</h3>
                <p>
                  Run the free analysis to identify your likely solar and battery
                  pathway, then approach the quoting process with confidence.
                </p>
              </div>
              <a
                className="btn btn-teal"
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
              >
                Start free analysis
              </a>
            </div>

            <section className="cta-sec" id="qd-cta">
              <div className="cta-box">
                <span className="pill pill-lime">Free · No sign-up required</span>
                <h2>Quality starts with knowing what you need.</h2>
                <p>
                  Model your household&apos;s usage, tariff and existing system
                  first — then compare installers against a clear brief, with the
                  questions above in hand.
                </p>
                <a
                  className="btn btn-teal"
                  href="#"
                  onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
                >
                  Start your free analysis →
                </a>
                <div className="cta-trust">
                  <span>🔒 No sign-up required</span>
                  <span>📍 Australia-wide</span>
                  <span>📋 Indicative modelling — not a quote</span>
                </div>
              </div>
            </section>

            <div className="limits" style={{ padding: "20px 0 0" }}>
              <div className="limits-box">
                <h3>General information only</h3>
                <p
                  style={{
                    fontSize: "13.5px",
                    color: "var(--l-mut)",
                    margin: 0,
                  }}
                >
                  This article provides general information for Queensland
                  homeowners. Regulatory settings, inspection requirements and
                  installer practices can change — verify current requirements
                  with your installer and relevant authorities. It does not
                  replace advice from a licensed electrical contractor.
                </p>
              </div>
            </div>

            <h2>Keep reading</h2>
            <div className="related">
              <a
                className="rel-card"
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("pl"); }}
              >
                <small>Guide · Strategy</small>
                <h3>Before you get solar quotes</h3>
                <p>Find the right solar and battery setup before entering the quoting process.</p>
              </a>
              <a
                className="rel-card"
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("a2"); }}
              >
                <small>Guide · Battery</small>
                <h3>When batteries make financial sense</h3>
                <p>The green-light / caution-sign framework.</p>
              </a>
              <a
                className="rel-card"
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
              >
                <small>Free tool</small>
                <h3>Solar &amp; battery calculator</h3>
                <p>Know what you need before the quotes arrive.</p>
              </a>
            </div>
          </article>
        </div>
      </main>

      {/* ---------- MINI FOOTER ---------- */}
      <footer className="f-mini">
        <div className="wrap fmini">
          <div className="f-logo">
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </div>
          <nav>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
              All guides
            </a>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("pl"); }}>
              Quotes pillar
            </a>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("a2"); }}>
              Battery guide
            </a>
            <a
              href="#"
              onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
            >
              Calculator
            </a>
          </nav>
          <p>
            Independent analysis for Australian homeowners. Indicative modelling
            only — not a quote or financial advice. © {year} Solar Sensei.
          </p>
        </div>
      </footer>
    </div>
  );
}
