"use client";

import { useRef } from "react";
import { PageProps } from "@/components/solar/types";
import { usePageChrome } from "@/components/solar/usePageChrome";
import { ThemeToggle } from "@/components/solar/ThemeToggle";
import { HeroImage, InsetImage } from "@/components/solar/GuideImage";
import { FaqList } from "@/components/solar/Faq";

/* ---------- structured data (BlogPosting + FAQPage) ---------- */
const LD_BLOG_POSTING = `{"@context":"https://schema.org","@type":"BlogPosting","headline":"Understanding Time-of-Use Tariffs and Solar","description":"How time-of-use electricity tariffs affect solar panel returns and battery storage value — and when TOU tariffs make batteries worthwhile.","datePublished":"2026-08-22","dateModified":"2026-08-22","author":{"@type":"Organization","name":"Solar Sensei"},"publisher":{"@type":"Organization","name":"Solar Sensei"},"mainEntityOfPage":"https://www.solarsensei.com.au/time-of-use-tariffs-solar-battery-guide"}`;

const LD_FAQ_PAGE = `{"@context":"https://schema.org","@type":"FAQPage","mainEntity":[{"@type":"Question","name":"What are typical peak, shoulder and off-peak times?","acceptedAnswer":{"@type":"Answer","text":"Peak is typically late afternoon and evening (for example 4pm to 9pm on weekdays), shoulder covers daytime and early evening outside peak, and off-peak is usually overnight. Exact windows vary by retailer, state and tariff."}},{"@type":"Question","name":"Is solar still worth it on a time-of-use tariff?","acceptedAnswer":{"@type":"Answer","text":"Generally yes, but timing matters. Solar generation often lands in shoulder or off-peak pricing periods while household consumption peaks in expensive evening periods. This makes self-consumption timing, and potentially battery storage, more important."}},{"@type":"Question","name":"Do batteries work with time-of-use tariffs?","acceptedAnswer":{"@type":"Answer","text":"They can. Batteries can store daytime solar surplus for evening use, and where plans allow, charge off-peak and discharge during peak periods to capture the rate difference."}},{"@type":"Question","name":"Should I change plans before installing solar?","acceptedAnswer":{"@type":"Answer","text":"It is worth assessing. Usage rates, supply charges, feed-in tariffs and peak windows differ between plans, and a plan change may sometimes deliver more immediate savings than additional equipment. Solar Sensei models system and plan effects separately."}},{"@type":"Question","name":"Does time-of-use pricing change feed-in tariff value?","acceptedAnswer":{"@type":"Answer","text":"Indirectly. Some plans link feed-in rates to the time of export. Under low flat feed-in tariffs, every kWh consumed directly saves the full import rate rather than the lower export rate."}}]}`;

/* ---------- "timing mismatch" heat blocks (12 × 2hr bands) ---------- */
const MIS_GEN = ["#E4EDE7", "#E4EDE7", "#E4EDE7", "#8FD6BC", "#3ECFA8", "#C9F24C", "#C9F24C", "#3ECFA8", "#8FD6BC", "#E4EDE7", "#E4EDE7", "#E4EDE7"];
const MIS_USE = ["#EFE0D4", "#FF8A66", "#FFD166", "#EFE0D4", "#E4EDE7", "#E4EDE7", "#EFE0D4", "#FFD166", "#FF8A66", "#FF8A66", "#FFD166", "#EFE0D4"];

export default function A3Page({ onNavigate }: PageProps) {
  const rootRef = useRef<HTMLElement>(null);
  usePageChrome(rootRef);
  const year = new Date().getFullYear();

  return (
    <div className="page" id="page-a3" ref={rootRef}>
      {/* structured data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: LD_BLOG_POSTING }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: LD_FAQ_PAGE }}
      />

      <header>
        <div className="wrap nav">
          <a
            className="logo"
            href="#"
            onClick={(e) => { e.preventDefault(); onNavigate("home"); }}
          >
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </a>
          <nav className="nav-links">
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
              All guides
            </a>
            <a href="#a3-what">Tariff periods</a>
            <a href="#a3-solar">Solar value</a>
            <a href="#a3-battery">Battery value</a>
            <a href="#a3-faq">FAQ</a>
          </nav>
          <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
            <a
              className="btn btn-teal btn-nav"
              href="#"
              onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
            >
              Analyse my tariff
            </a>
            <ThemeToggle />
            <button className="burger" aria-label="Menu" data-burger>
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>
        <nav className="mobile-menu" data-mobile-menu>
          <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
            All guides
          </a>
          <a href="#a3-what">Tariff periods</a>
          <a href="#a3-solar">Solar value</a>
          <a href="#a3-battery">Battery value</a>
          <a href="#a3-faq">FAQ</a>
          <a
            href="#"
            className="mm-primary"
            onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
          >
            Analyse my tariff →
          </a>
        </nav>
      </header>

      <main id="top">
        {/* ---------- HERO ---------- */}
        <section className="dark hero-a">
          <div className="wrap">
            <nav className="crumb" aria-label="Breadcrumb">
              <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("home"); }}>
                Home
              </a>
              <span>›</span>
              <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
                Guides
              </a>
              <span>›</span>
              <b>Time-of-use tariffs</b>
            </nav>
            <span className="pill pill-lime">✦ &nbsp;Guide · Tariffs</span>
            <h1>
              Your tariff can make or break your{" "}
              <em style={{ fontStyle: "normal" }} className="c-orange">
                solar return
              </em>
            </h1>
            <p className="lede">
              Most homeowners focus on panel efficiency, inverter brands and
              install costs. But one of the biggest factors in your solar return
              is something you may never have considered: your electricity
              tariff&apos;s clock.
            </p>
            <div className="meta-row">
              <span className="m-chip">🗓️ Updated 22/08/26</span>
              <span className="m-chip">📖 6 min read</span>
              <span className="m-chip">🇦🇺 Australian tariffs</span>
              <span className="m-chip">✅ Example rates — windows vary by retailer</span>
            </div>
            <HeroImage
              src="/guides/a3.jpg"
              alt="A digital smart energy monitor displaying household electricity usage"
              caption="A smart meter or in-home display reveals exactly when — and how much — energy your household uses."
            />
          </div>
        </section>

        <div className="wrap a-layout">
          {/* ---------- STICKY SIDE (TOC + CTA + more guides) ---------- */}
          <aside className="side">
            <div className="side-card">
              <h4>On this page</h4>
              <nav className="toc">
                <a href="#a3-what">What is a TOU tariff?</a>
                <a href="#a3-solar">How TOU affects solar value</a>
                <a href="#a3-battery">How TOU affects battery value</a>
                <a href="#a3-verdict">When batteries stack up</a>
                <a href="#a3-plan">Should you change plans?</a>
                <a href="#a3-take">Key takeaways</a>
                <a href="#a3-faq">FAQ</a>
              </nav>
            </div>
            <div className="side-card side-cta">
              <h4>Free analysis</h4>
              <p>See how your tariff shapes the result — before quotes.</p>
              <a
                className="btn btn-teal"
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
                style={{ width: "100%" }}
              >
                Analyse my tariff
              </a>
            </div>
            <div className="side-card">
              <h4>More guides</h4>
              <nav className="toc">
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("pl"); }}>
                  Before you get solar quotes
                </a>
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("a1"); }}>
                  Read your electricity bill
                </a>
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("a2"); }}>
                  Battery: when it makes sense
                </a>
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
                  Browse all guides →
                </a>
              </nav>
            </div>
          </aside>

          {/* ---------- ARTICLE PROSE ---------- */}
          <article className="prose">
            <p>
              Time-of-use (TOU) tariffs charge different rates at different times
              of day. This can significantly affect the value of your solar
              generation, the attractiveness of battery storage, and whether
              changing plans may be more valuable than installing equipment.
            </p>

            <h2 id="a3-what">What is a time-of-use tariff?</h2>
            <div className="tou">
              <div className="tou-bar" aria-label="Example TOU pricing windows">
                <div className="seg seg-off" style={{ width: "29.2%" }}>
                  Off-peak
                </div>
                <div className="seg seg-sh" style={{ width: "37.5%" }}>
                  Shoulder
                </div>
                <div className="seg seg-pk" style={{ width: "20.8%" }}>
                  Peak 4–9pm
                </div>
                <div className="seg seg-sh" style={{ width: "4.2%" }} />
                <div className="seg seg-off" style={{ width: "8.3%" }}>
                  Off
                </div>
              </div>
              <div className="tou-axis">
                <span>12am</span>
                <span>3am</span>
                <span>6am</span>
                <span>9am</span>
                <span>12pm</span>
                <span>3pm</span>
                <span>6pm</span>
                <span>9pm</span>
                <span>12am</span>
              </div>
            </div>
            <p className="note-fine" style={{ margin: "0 0 18px" }}>
              Example weekday windows. Exact times and rates vary by retailer,
              state and specific tariff.
            </p>
            <div className="period-grid">
              <div className="period-card">
                <small>Peak period</small>
                <h3>Highest price</h3>
                <ul>
                  <li><b>When:</b> late afternoon–evening (e.g. 4pm–9pm weekdays)</li>
                  <li><b>Rate:</b> ~30–45¢ per kWh</li>
                  <li><b>Why:</b> highest demand on the grid</li>
                </ul>
              </div>
              <div className="period-card sh">
                <small>Shoulder period</small>
                <h3>Mid-range price</h3>
                <ul>
                  <li><b>When:</b> daytime &amp; early evening outside peak</li>
                  <li><b>Rate:</b> ~20–30¢ per kWh</li>
                  <li><b>Why:</b> moderate demand</li>
                </ul>
              </div>
              <div className="period-card off">
                <small>Off-peak period</small>
                <h3>Lowest price</h3>
                <ul>
                  <li><b>When:</b> overnight, sometimes midday (e.g. 10pm–7am)</li>
                  <li><b>Rate:</b> ~10–15¢ per kWh</li>
                  <li><b>Why:</b> lowest demand on the grid</li>
                </ul>
              </div>
            </div>

            <InsetImage
              src="/guides/a3-inset.jpg"
              alt="A smartphone app displaying household energy usage by time of day"
              caption="In-home energy displays and smart-meter portals show your usage by time of day — the foundation of tariff analysis."
            />
            <h2 id="a3-solar">How TOU tariffs affect solar value</h2>
            <h3>The timing mismatch</h3>
            <p>
              Solar generates through the middle of the day — often during
              shoulder or off-peak pricing — while many households consume most
              energy in the morning and, especially, the evening peak:
            </p>
            <div className="mis" aria-hidden="true">
              <div className="mis-row">
                <span className="ml">Solar generation</span>
                <div className="blocks">
                  {MIS_GEN.map((c, i) => (
                    <i key={i} style={{ background: c }} />
                  ))}
                </div>
              </div>
              <div className="mis-row">
                <span className="ml">Household use</span>
                <div className="blocks">
                  {MIS_USE.map((c, i) => (
                    <i key={i} style={{ background: c }} />
                  ))}
                </div>
              </div>
              <div className="mis-cap">
                Illustrative 24-hour pattern (2-hour blocks): generation peaks
                midday while demand peaks morning and evening — exactly when peak
                pricing often applies.
              </div>
            </div>
            <p>
              <strong>The value of self-consumption:</strong> under TOU pricing,
              every kWh of solar you consume directly saves you the import rate
              for that period rather than earning the feed-in rate:
            </p>
            <div className="eq">
              <div className="eq-chip">
                <b>35¢</b>
                <span>Peak import rate saved</span>
              </div>
              <span className="eq-op">−</span>
              <div className="eq-chip">
                <b>8¢</b>
                <span>Feed-in tariff earned</span>
              </div>
              <span className="eq-op">=</span>
              <div className="eq-chip result">
                <b>27¢</b>
                <span>Extra value per kWh self-consumed</span>
              </div>
            </div>
            <p>
              This makes maximising self-consumption more valuable under TOU
              tariffs than under flat rates. Example figures only.
            </p>

            <h2 id="a3-battery">How TOU tariffs affect battery value</h2>
            <div
              className="steps"
              style={{ gridTemplateColumns: "repeat(3,1fr)" }}
            >
              <div className="step-card">
                <div className="step-num">1</div>
                <h3>Time-shift solar</h3>
                <p>
                  Store excess daytime solar and discharge in the evening peak,
                  avoiding expensive grid imports.
                </p>
              </div>
              <div className="step-card">
                <div className="step-num">2</div>
                <h3>Charge off-peak</h3>
                <p>
                  Where your plan allows, charge from the grid overnight and
                  discharge during peak — capturing the rate difference.
                </p>
              </div>
              <div className="step-card">
                <div className="step-num">3</div>
                <h3>Manage load</h3>
                <p>
                  Cover high-cost periods from storage and potentially reduce
                  demand charges on demand tariffs.
                </p>
              </div>
            </div>

            <h2 id="a3-verdict">So — do batteries stack up on TOU?</h2>
            <div className="yn-grid">
              <div className="yn y">
                <h3>More attractive when…</h3>
                <ul>
                  <li>Peak rates are significantly higher than off-peak (e.g. 35¢ vs 12¢)</li>
                  <li>Feed-in tariffs are low (5–10¢), making self-consumption valuable</li>
                  <li>Evening consumption is high, creating peak-import displacement opportunities</li>
                  <li>Solar generation exceeds daytime use, leaving surplus to store</li>
                </ul>
              </div>
              <div className="yn n">
                <h3>Less attractive when…</h3>
                <ul>
                  <li>Rate differences are small (e.g. 28¢ vs 22¢) — limited arbitrage</li>
                  <li>Feed-in tariffs are generous (15–20¢) — exporting competes with storing</li>
                  <li>Evening consumption is low — little expensive demand to displace</li>
                  <li>You&apos;re on a flat-rate tariff — no time-based pricing to exploit</li>
                </ul>
              </div>
            </div>
            <p>
              For the full battery decision framework, see{" "}
              <a
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("a2"); }}
                style={{ color: "var(--teal-deep)", fontWeight: 600 }}
              >
                when battery storage makes financial sense
              </a>
              .
            </p>

            <h2 id="a3-plan">Should you change your electricity plan?</h2>
            <p>
              Many homeowners remain on default or legacy tariffs without
              realising better-fitting options exist. Before installing solar or
              batteries, consider:
            </p>
            <ul className="plain">
              <li><strong>Current structure</strong> — are you on flat-rate or time-of-use?</li>
              <li><strong>Alternatives</strong> — do other plans price your usage pattern better?</li>
              <li><strong>Feed-in comparisons</strong> — do some retailers pay more for exports?</li>
              <li><strong>Peak alignment</strong> — do peak windows match your high-consumption hours?</li>
            </ul>
            <p>
              Changing plans may sometimes deliver more immediate savings than
              installing additional equipment — which is why Solar Sensei shows
              the two effects separately.
            </p>

            <div className="icb">
              <div>
                <h3>See what your tariff is doing to your solar return.</h3>
                <p>
                  Solar Sensei analyses your actual tariff structure and models
                  system and plan-change benefits separately, so nothing is
                  blended into one opaque number.
                </p>
              </div>
              <a
                className="btn btn-teal"
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
              >
                Analyse my tariff — free
              </a>
            </div>

            <div className="take" id="a3-take">
              <h3>Key takeaways</h3>
              <ul>
                <li>Time-of-use tariffs charge different rates at different times of day</li>
                <li>TOU tariffs can significantly affect solar self-consumption value</li>
                <li>Batteries tend to perform better under TOU tariffs with large rate differences</li>
                <li>Low feed-in tariffs and high peak import rates increase battery attractiveness</li>
                <li>Changing electricity plans may sometimes deliver more value than installing equipment</li>
                <li>Understanding your tariff is essential before making solar or battery decisions</li>
              </ul>
            </div>

            <h2 id="a3-faq">Frequently asked questions</h2>
            <FaqList
              items={[
                {
                  q: "What are typical peak, shoulder and off-peak times?",
                  a: "Peak is typically late afternoon and evening (for example 4pm to 9pm on weekdays), shoulder covers daytime and early evening outside peak, and off-peak is usually overnight. Exact windows vary by retailer, state and tariff.",
                },
                {
                  q: "Is solar still worth it on a time-of-use tariff?",
                  a: "Generally yes, but timing matters. Solar generation often lands in shoulder or off-peak pricing periods while household consumption peaks in expensive evening periods. This makes self-consumption timing, and potentially battery storage, more important.",
                },
                {
                  q: "Do batteries work with time-of-use tariffs?",
                  a: "They can. Batteries can store daytime solar surplus for evening use, and where plans allow, charge off-peak and discharge during peak periods to capture the rate difference.",
                },
                {
                  q: "Should I change plans before installing solar?",
                  a: "It is worth assessing. Usage rates, supply charges, feed-in tariffs and peak windows differ between plans, and a plan change may sometimes deliver more immediate savings than additional equipment. Solar Sensei models system and plan effects separately.",
                },
                {
                  q: "Does time-of-use pricing change feed-in tariff value?",
                  a: "Indirectly. Some plans link feed-in rates to the time of export. Under low flat feed-in tariffs, every kWh consumed directly saves the full import rate rather than the lower export rate.",
                },
              ]}
            />

            <section className="cta-sec" id="a3-cta">
              <div className="cta-box">
                <span className="pill pill-lime">Free tariff analysis</span>
                <h2>Modelled against your actual tariff — not averages.</h2>
                <p>
                  Upload your bill and see how your peak, shoulder and off-peak
                  rates shape solar value, battery economics and plan-change
                  potential.
                </p>
                <a
                  className="btn btn-teal"
                  href="#"
                  onClick={(e) => { e.preventDefault(); onNavigate("lp1", "#cta1"); }}
                >
                  Analyse your tariff and usage — free →
                </a>
                <div className="cta-trust">
                  <span>🔒 No sign-up required</span>
                  <span>📍 Australia-wide</span>
                  <span>📋 Indicative modelling — not a quote</span>
                </div>
              </div>
            </section>

            <h2>Keep reading</h2>
            <div className="related">
              <a
                className="rel-card"
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("pl"); }}
              >
                <small>Guide · Quotes</small>
                <h3>Before you get solar quotes</h3>
                <p>Turn tariff knowledge into a smarter quoting brief.</p>
              </a>
              <a
                className="rel-card"
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("a1"); }}
              >
                <small>Guide · Your bill</small>
                <h3>How to read your electricity bill</h3>
                <p>Find your tariff type, rates and feed-in details in minutes.</p>
              </a>
              <a
                className="rel-card"
                href="#"
                onClick={(e) => { e.preventDefault(); onNavigate("a2"); }}
              >
                <small>Guide · Battery</small>
                <h3>When batteries make financial sense</h3>
                <p>The complete green-light / caution-sign framework.</p>
              </a>
            </div>
          </article>
        </div>
      </main>

      {/* ---------- MINI FOOTER ---------- */}
      <footer className="f-mini">
        <div className="wrap fmini">
          <div className="f-logo">
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </div>
          <nav>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>All guides</a>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("a1"); }}>Bill guide</a>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("a2"); }}>Battery guide</a>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("pl"); }}>Before you quote</a>
          </nav>
          <p>
            Independent analysis for Australian homeowners. Indicative modelling
            only — not a quote or financial advice. © {year} Solar Sensei.
          </p>
        </div>
      </footer>
    </div>
  );
}
