"use client";

import { useRef } from "react";
import { PageProps } from "@/components/solar/types";
import { usePageChrome } from "@/components/solar/usePageChrome";
import { ThemeToggle } from "@/components/solar/ThemeToggle";
import { HeroImage, InsetImage } from "@/components/solar/GuideImage";
import { FaqList } from "@/components/solar/Faq";

/* ---------- structured data (JSON-LD) for SEO ---------- */
const BLOG_POSTING_LD =
  '{"@context":"https://schema.org","@type":"BlogPosting","headline":"How to Read Your Electricity Bill for Solar and Battery Analysis","description":"Learn what to look for on your electricity bill before installing solar or battery storage — tariffs, usage rates and feed-in tariffs explained.","datePublished":"2026-08-18","dateModified":"2026-08-18","author":{"@type":"Organization","name":"Solar Sensei"},"publisher":{"@type":"Organization","name":"Solar Sensei"},"mainEntityOfPage":"https://www.solarsensei.com.au/how-to-read-electricity-bill-solar-analysis"}';

const FAQ_PAGE_LD =
  '{"@context":"https://schema.org","@type":"FAQPage","mainEntity":[' +
  '{"@type":"Question","name":"Where do I find my usage rate on my electricity bill?","acceptedAnswer":{"@type":"Answer","text":"Usage rates appear in the usage or consumption section of your bill, expressed in cents per kWh. Time-of-use bills show separate rates for peak, shoulder and off-peak periods, along with a daily supply charge."}},' +
  '{"@type":"Question","name":"How many bills do I need for a solar analysis?","acceptedAnswer":{"@type":"Answer","text":"Three to four recent bills help capture seasonal variation. Where possible, a full 12 months of usage data from your online account gives the clearest picture."}},' +
  '{"@type":"Question","name":"What is a controlled load tariff?","acceptedAnswer":{"@type":"Answer","text":"A controlled load is a separately metered circuit for specific appliances, commonly hot water, charged at its own (usually lower) rate. It appears as a distinct line on your bill and can affect battery and load-shifting economics."}},' +
  '{"@type":"Question","name":"Does my bill show when I use electricity?","acceptedAnswer":{"@type":"Answer","text":"Usually not. Most bills show total consumption for the billing period, and time-of-use bills show totals per pricing period. Interval data, which shows usage every 30 minutes, is typically accessed through your online account or a data authorisation."}},' +
  '{"@type":"Question","name":"Can Solar Sensei read my bill for me?","acceptedAnswer":{"@type":"Answer","text":"Yes. Upload a PDF or clear image and the calculator extracts consumption, tariff structure, supply charges and other details, then models solar and battery configurations against your actual usage."}},' +
  '{"@type":"Question","name":"Is solar worth it if I do not understand tariffs?","acceptedAnswer":{"@type":"Answer","text":"That is exactly why analysis matters. Tariff structure, usage rates and feed-in tariffs all influence results, so understanding or modelling them before requesting quotes helps you judge which options may genuinely improve your bill."}}' +
  "]}";

export default function A1Page({ onNavigate }: PageProps) {
  const rootRef = useRef<HTMLElement>(null);
  usePageChrome(rootRef);
  const year = new Date().getFullYear();

  return (
    <div className="page" id="page-a1" ref={rootRef}>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: BLOG_POSTING_LD }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: FAQ_PAGE_LD }}
      />

      {/* ============================================================
           TAB: ARTICLE 1 — BILL
      ============================================================ */}
      <header>
        <div className="wrap nav">
          <a
            className="logo"
            href="#"
            onClick={(e) => {
              e.preventDefault();
              onNavigate("home");
            }}
          >
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </a>
          <nav className="nav-links">
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("hub");
              }}
            >
              All guides
            </a>
            <a href="#a1-look">What to look for</a>
            <a href="#a1-formats">Bill formats</a>
            <a href="#a1-steps">How to use it</a>
            <a href="#a1-faq">FAQ</a>
          </nav>
          <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
            <a
              className="btn btn-teal btn-nav"
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("lp1", "#cta1");
              }}
            >
              Start free analysis
            </a>
            <ThemeToggle />
            <button className="burger" aria-label="Menu" data-burger>
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>
        <nav className="mobile-menu" data-mobile-menu>
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              onNavigate("hub");
            }}
          >
            All guides
          </a>
          <a href="#a1-look">What to look for</a>
          <a href="#a1-formats">Bill formats</a>
          <a href="#a1-steps">How to use it</a>
          <a href="#a1-faq">FAQ</a>
          <a
            href="#"
            className="mm-primary"
            onClick={(e) => {
              e.preventDefault();
              onNavigate("lp1", "#cta1");
            }}
          >
            Start free analysis →
          </a>
        </nav>
      </header>

      <main id="top">
        {/* ---------- HERO ---------- */}
        <section className="dark hero-a">
          <div className="wrap">
            <nav className="crumb" aria-label="Breadcrumb">
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("home");
                }}
              >
                Home
              </a>
              <span>›</span>
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("hub");
                }}
              >
                Guides
              </a>
              <span>›</span>
              <b>Reading your electricity bill</b>
            </nav>
            <span className="pill pill-lime">✦ &nbsp;Guide · Before you buy</span>
            <h1>How to read your electricity bill for solar &amp; battery analysis</h1>
            <p className="lede">
              Most homeowners check their bill to see what they owe. If
              you&apos;re considering solar panels or battery storage, it contains
              far more valuable information — and knowing where to look changes
              the quality of every decision that follows.
            </p>
            <div className="meta-row">
              <span className="m-chip">🗓️ Updated 18/08/26</span>
              <span className="m-chip">📖 8 min read</span>
              <span className="m-chip">🇦🇺 Australian bills &amp; tariffs</span>
              <span className="m-chip">
                ✅ Reviewed for accuracy · figures are examples only
              </span>
            </div>
            <HeroImage
              src="/guides/a1.jpg"
              alt="A couple reviewing an electricity bill and usage details together at a table"
              caption="Reading your electricity bill carefully is the first step to understanding your solar and battery potential."
            />
          </div>
        </section>

        {/* ---------- ARTICLE LAYOUT ---------- */}
        <div className="wrap a-layout">
          <aside className="side">
            <div className="side-card">
              <h4>On this page</h4>
              <nav className="toc">
                <a href="#a1-intro">Why your bill matters</a>
                <a href="#a1-look">Six things to look for</a>
                <a href="#a1-formats">Common bill formats</a>
                <a href="#a1-gaps">What your bill won&apos;t tell you</a>
                <a href="#a1-steps">Using your bill for analysis</a>
                <a href="#a1-quotes">Before requesting quotes</a>
                <a href="#a1-take">Key takeaways</a>
                <a href="#a1-faq">FAQ</a>
              </nav>
            </div>
            <div className="side-card side-cta">
              <h4>Free analysis</h4>
              <p>Not sure what system you need? Run a free analysis first.</p>
              <a
                className="btn btn-teal"
                href="#"
                style={{ width: "100%" }}
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("lp1", "#cta1");
                }}
              >
                Start free analysis
              </a>
            </div>
            <div className="side-card">
              <h4>More guides</h4>
              <nav className="toc">
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate("pl");
                  }}
                >
                  Before you get solar quotes
                </a>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate("a2");
                  }}
                >
                  Battery: when it makes sense
                </a>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate("a3");
                  }}
                >
                  Time-of-use tariffs &amp; solar
                </a>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate("hub");
                  }}
                >
                  Browse all guides →
                </a>
              </nav>
            </div>
          </aside>

          <article className="prose">
            <h2 id="a1-intro">Your bill holds the key to better solar decisions</h2>
            <p>
              Your electricity bill is a record of how your home actually uses
              energy. Understanding these details is the first step toward an
              informed solar or battery decision, because it reveals:
            </p>
            <ul className="plain">
              <li>How much energy your household consumes</li>
              <li>When you use electricity (if you have time-of-use pricing)</li>
              <li>What you pay for imports from the grid</li>
              <li>What you receive for exported solar energy</li>
              <li>
                Whether your current tariff structure supports solar or battery
                storage
              </li>
            </ul>

            <InsetImage
              src="/guides/a1-inset.jpg"
              alt="Illustration of an electricity bill broken down into usage, supply and tariff components"
              caption="Your bill breaks down into usage charges, supply charges and tariff structures — each affects solar economics differently."
            />
            <h2 id="a1-look">What to look for on your bill</h2>
            <p>
              Here is an illustrative bill with the six key items highlighted.
              Your retailer&apos;s format will differ, but the same information
              appears on every Australian bill.
            </p>
            <div className="bill" aria-label="Illustrative electricity bill">
              <div className="bill-head">
                <b>Everyday Energy</b>
                <span>Bill period: 12 Oct – 10 Nov · 30 days · Illustrative example</span>
              </div>
              <div className="bill-row">
                <span className="bnum c1">1</span>
                <span className="bl">Average daily use</span>
                <span className="bv">
                  21.6 kWh/day<small>Total consumption this period</small>
                </span>
              </div>
              <div className="bill-row">
                <span className="bnum c2">2</span>
                <span className="bl">Tariff type</span>
                <span className="bv">
                  Time-of-use<small>Smart meter required</small>
                </span>
              </div>
              <div className="bill-row">
                <span className="bnum c3">3</span>
                <span className="bl">Usage rates</span>
                <span className="bv">
                  Peak 38.2¢ · Shoulder 28.4¢ · Off-peak 16.8¢
                  <small>cents per kWh + supply charge $1.12/day</small>
                </span>
              </div>
              <div className="bill-row">
                <span className="bnum c4">4</span>
                <span className="bl">Solar feed-in</span>
                <span className="bv">
                  412 kWh @ 6.5¢<small>Energy exported to the grid</small>
                </span>
              </div>
              <div className="bill-row">
                <span className="bnum c5">5</span>
                <span className="bl">Billing period</span>
                <span className="bv">
                  30 days<small>Seasonal variation matters</small>
                </span>
              </div>
              <div className="bill-row">
                <span className="bnum c6">6</span>
                <span className="bl">Controlled load</span>
                <span className="bv">
                  3.1 kWh/day @ 19.4¢<small>Separately metered hot water</small>
                </span>
              </div>
            </div>
            <p className="note-fine">
              Illustrative layout with example figures. Rates vary by retailer,
              network and state.
            </p>

            <h3>
              <span className="h3num">
                <span className="nbadge c1">1</span>Total consumption (kWh)
              </span>
            </h3>
            <p>
              Your bill shows how many kilowatt-hours (kWh) your household
              consumed during the billing period — typically labelled{" "}
              <strong>Total usage</strong> or <strong>Consumption</strong>,
              sometimes broken down by peak, shoulder and off-peak periods if
              you have time-of-use pricing.
            </p>
            <div className="why">
              <b>Why it matters</b>Solar and battery systems are sized in part
              based on your consumption. A household using 20 kWh per day has
              different requirements to one using 40 kWh per day.
            </div>

            <h3>
              <span className="h3num">
                <span className="nbadge c2">2</span>Tariff type
              </span>
            </h3>
            <p>
              Check whether your bill shows a <strong>flat rate</strong> (a
              single rate for all usage), <strong>time-of-use</strong> (different
              rates for peak, shoulder and off-peak), or a{" "}
              <strong>controlled load</strong> (separate metering for appliances
              like hot water).
            </p>
            <div className="why">
              <b>Why it matters</b>Time-of-use tariffs can significantly affect
              the value of solar and battery storage. Batteries may be more
              valuable if you can charge during off-peak periods and discharge
              during peak periods — our{" "}
              <a
                href="#"
                style={{ color: "var(--teal-deep)", fontWeight: 600 }}
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("a3");
                }}
              >
                time-of-use tariff guide
              </a>{" "}
              explains this in detail.
            </div>

            <h3>
              <span className="h3num">
                <span className="nbadge c3">3</span>Usage rates (cents per kWh)
              </span>
            </h3>
            <p>
              This includes your <strong>peak rate</strong> (highest, typically
              evening), <strong>shoulder rate</strong> (mid-range, daytime or
              early evening), <strong>off-peak rate</strong> (lowest, overnight),
              and the <strong>supply charge</strong> — a daily fixed cost
              independent of usage.
            </p>
            <div className="why">
              <b>Why it matters</b>The difference between your import rate and
              your feed-in tariff determines how valuable self-consumption is. A
              larger gap makes solar and battery storage more attractive.
            </div>

            <h3>
              <span className="h3num">
                <span className="nbadge c4">4</span>Feed-in tariff (if you have
                solar)
              </span>
            </h3>
            <p>
              With existing solar, your bill shows how much energy you exported
              to the grid and the rate you were paid for it.
            </p>
            <div className="why">
              <b>Why it matters</b>Low feed-in tariffs (around 5–10¢ per kWh)
              compared to high import rates (around 25–35¢ per kWh) increase the
              value of using your own solar generation rather than exporting it.
            </div>

            <h3>
              <span className="h3num">
                <span className="nbadge c5">5</span>Billing period &amp;
                seasonal variation
              </span>
            </h3>
            <p>
              Check the dates on your bill. Consumption varies significantly
              between summer and winter due to heating, cooling and daylight
              hours.
            </p>
            <div className="why">
              <b>Why it matters</b>A single bill may not represent your annual
              usage. Solar and battery analysis should consider seasonal
              variation to avoid over- or under-sizing systems.
            </div>

            <h3>
              <span className="h3num">
                <span className="nbadge c6">6</span>Controlled loads &amp;
                special tariffs
              </span>
            </h3>
            <p>
              Some bills show separate charges for controlled loads such as hot
              water, electric vehicle tariffs with special overnight rates, or
              demand charges for larger households.
            </p>
            <div className="why">
              <b>Why it matters</b>These can affect whether battery storage or
              load-shifting strategies make financial sense for your home.
            </div>

            <h2 id="a1-formats">Common bill formats in Australia</h2>
            <div className="fmt-grid">
              <div className="fmt">
                <h3>Single-rate (flat) tariff</h3>
                <ul>
                  <li>One usage rate applies at all times</li>
                  <li>Simpler to understand</li>
                  <li>May not reward solar self-consumption as effectively</li>
                </ul>
                <span className="fmt-tag">Common regionally</span>
              </div>
              <div className="fmt f2">
                <h3>Time-of-use tariff</h3>
                <ul>
                  <li>Peak: typically 4pm–9pm</li>
                  <li>Shoulder: daytime &amp; early evening</li>
                  <li>Off-peak: overnight (varies by retailer)</li>
                </ul>
                <span className="fmt-tag">Urban areas · smart meters</span>
              </div>
              <div className="fmt f3">
                <h3>Demand tariff</h3>
                <ul>
                  <li>Charged on your highest 30-minute usage period</li>
                  <li>Less common for residential customers</li>
                  <li>Can significantly affect battery value</li>
                </ul>
                <span className="fmt-tag">Larger households</span>
              </div>
            </div>

            <h2 id="a1-gaps">What your bill does not tell you</h2>
            <div className="gap-card">
              <h3>Three blind spots worth knowing</h3>
              <ul>
                <li>
                  <strong>No interval data</strong> — most bills show total
                  consumption for the period, not when you used electricity
                  throughout the day
                </li>
                <li>
                  <strong>No solar generation data</strong> — with existing
                  solar, bills show exports but not total generation or
                  self-consumption
                </li>
                <li>
                  <strong>No future projection</strong> — bills reflect past
                  consumption, not planned changes such as an EV, pool or heat
                  pump
                </li>
              </ul>
              <p>
                This is where tools like Solar Sensei add value — combining your
                bill information with interval data (where available) and
                modelling hundreds of system combinations for a clearer picture
                of what may work best.
              </p>
            </div>

            <h2 id="a1-steps">How to use your bill for solar analysis</h2>
            <div className="steps">
              <div className="step-card">
                <div className="step-num">1</div>
                <h3>Gather recent bills</h3>
                <p>
                  Collect 3–4 recent bills to capture seasonal variation — or
                  download 12 months from your online account if possible.
                </p>
              </div>
              <div className="step-card">
                <div className="step-num">2</div>
                <h3>Identify key figures</h3>
                <p>
                  Total kWh, tariff type, usage rates for each period, feed-in
                  tariff, and the daily supply charge.
                </p>
              </div>
              <div className="step-card">
                <div className="step-num">3</div>
                <h3>Calculate daily averages</h3>
                <p>
                  Divide total consumption by days in the billing period —
                  useful for comparing system capacity options.
                </p>
              </div>
              <div className="step-card">
                <div className="step-num">4</div>
                <h3>Upload to Solar Sensei</h3>
                <p>
                  The calculator extracts key details automatically, then models
                  configurations against your actual tariff and usage.
                </p>
              </div>
            </div>

            <h2 id="a1-quotes">Why this matters before requesting quotes</h2>
            <p>When you understand your bill, you can:</p>
            <ul className="plain">
              <li>
                Ask installers why they are recommending a particular system size
              </li>
              <li>
                Check whether quoted savings align with your actual tariff
                structure
              </li>
              <li>
                Assess whether a battery would be valuable given your usage
                patterns
              </li>
              <li>
                Determine whether changing electricity plans may be more
                beneficial than installing equipment
              </li>
            </ul>
            <p>
              <strong>Three quotes cannot provide this clarity.</strong>{" "}
              Understanding your bill — and using tools that model your actual
              consumption — can.
            </p>

            <div className="icb">
              <div>
                <h3>Let your bill do the talking.</h3>
                <p>
                  Upload a PDF or photo and Solar Sensei extracts the details,
                  then models solar and battery options against your actual
                  tariff and usage.
                </p>
              </div>
              <a
                className="btn btn-teal"
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("lp1", "#cta1");
                }}
              >
                Upload your bill — free
              </a>
            </div>

            <div className="take" id="a1-take">
              <h3>Key takeaways</h3>
              <ul>
                <li>
                  Your electricity bill contains essential information for solar
                  and battery analysis
                </li>
                <li>
                  Tariff type, usage rates and feed-in tariffs all affect the
                  financial outcome of different systems
                </li>
                <li>
                  Bills show past consumption, not when you use energy throughout
                  the day
                </li>
                <li>
                  Interval data and modelling tools provide a more complete
                  picture
                </li>
                <li>
                  Understanding your bill helps you ask better questions before
                  requesting quotes
                </li>
              </ul>
            </div>

            <h2 id="a1-faq">Frequently asked questions</h2>
            <FaqList
              items={[
                {
                  q: "Where do I find my usage rate on my electricity bill?",
                  a: "Usage rates appear in the usage or consumption section of your bill, expressed in cents per kWh. Time-of-use bills show separate rates for peak, shoulder and off-peak periods, along with a daily supply charge.",
                },
                {
                  q: "How many bills do I need for a solar analysis?",
                  a: "Three to four recent bills help capture seasonal variation. Where possible, a full 12 months of usage data from your online account gives the clearest picture.",
                },
                {
                  q: "What is a controlled load tariff?",
                  a: "A controlled load is a separately metered circuit for specific appliances, commonly hot water, charged at its own (usually lower) rate. It appears as a distinct line on your bill and can affect battery and load-shifting economics.",
                },
                {
                  q: "Does my bill show when I use electricity?",
                  a: "Usually not. Most bills show total consumption for the billing period, and time-of-use bills show totals per pricing period. Interval data, which shows usage every 30 minutes, is typically accessed through your online account or a data authorisation.",
                },
                {
                  q: "Can Solar Sensei read my bill for me?",
                  a: "Yes. Upload a PDF or clear image and the calculator extracts consumption, tariff structure, supply charges and other details, then models solar and battery configurations against your actual usage.",
                },
                {
                  q: "Is solar worth it if I don't understand tariffs?",
                  a: "That is exactly why analysis matters. Tariff structure, usage rates and feed-in tariffs all influence results, so understanding or modelling them before requesting quotes helps you judge which options may genuinely improve your bill.",
                },
              ]}
            />

            <section className="cta-sec" id="a1-cta">
              <div className="cta-box">
                <span className="pill pill-lime">Free · No sign-up required</span>
                <h2>Your bill, decoded. Your options, ranked.</h2>
                <p>
                  Upload your electricity bill and see how different solar and
                  battery configurations may perform against your actual
                  consumption and tariff — before you compare quotes.
                </p>
                <a
                  className="btn btn-teal"
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate("lp1", "#cta1");
                  }}
                >
                  Start your free analysis →
                </a>
                <div className="cta-trust">
                  <span>🔒 No sign-up required</span>
                  <span>📍 Australia-wide</span>
                  <span>📋 Indicative modelling — not a quote</span>
                </div>
              </div>
            </section>

            <h2>Keep reading</h2>
            <div className="related">
              <a
                className="rel-card"
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("pl");
                }}
              >
                <small>Guide · Quotes</small>
                <h3>Before you get solar quotes</h3>
                <p>Find the right setup before entering the quoting process.</p>
              </a>
              <a
                className="rel-card"
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("a2");
                }}
              >
                <small>Guide · Battery</small>
                <h3>When does battery storage make financial sense?</h3>
                <p>
                  The five situations where batteries tend to work — and five
                  where they may not.
                </p>
              </a>
              <a
                className="rel-card"
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("a3");
                }}
              >
                <small>Guide · Tariffs</small>
                <h3>Understanding time-of-use tariffs and solar</h3>
                <p>
                  How peak, shoulder and off-peak pricing shapes solar and
                  battery value.
                </p>
              </a>
            </div>
          </article>
        </div>
      </main>

      {/* ---------- MINI FOOTER ---------- */}
      <footer className="f-mini">
        <div className="wrap fmini">
          <div className="f-logo">
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </div>
          <nav>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("hub");
              }}
            >
              All guides
            </a>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("a2");
              }}
            >
              Battery guide
            </a>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("a3");
              }}
            >
              Tariff guide
            </a>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("pl");
              }}
            >
              Before you quote
            </a>
          </nav>
          <p>
            Independent analysis for Australian homeowners. Indicative modelling
            only — not a quote or financial advice. © {year} Solar Sensei.
          </p>
        </div>
      </footer>
    </div>
  );
}
