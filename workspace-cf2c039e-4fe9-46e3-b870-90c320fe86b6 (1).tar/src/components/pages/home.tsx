"use client";

import { useRef } from "react";
import { PageProps } from "@/components/solar/types";
import { usePageChrome } from "@/components/solar/usePageChrome";
import { ThemeToggle } from "@/components/solar/ThemeToggle";
import { FaqList } from "@/components/solar/Faq";
import { OptGroup } from "@/components/solar/OptGroup";

/* ---------- heatmap data + renderer (home "fingerprint" section) ---------- */
const PAL_USAGE = ["#DDE3DA", "#8FD6BC", "#FFD166", "#FF8A66"];
const PAL_COST = ["#E2E6F2", "#9CC3F5", "#FFD166", "#FF8A66"];
const USAGE_WEEK = "100001232110000123332110";
const USAGE_WKND = "1000001233322112233332110";
const USAGE_AVG = "100001222110000123332100";
const COST_WEEK = "111111222111111223333211";
const COST_WKND = "111111112221112233332111";
const COST_AVG = "111111222111111223333211";

function Heatmap({
  palette,
  rows,
}: {
  palette: string[];
  rows: { l: string; c: string }[];
}) {
  return (
    <div className="hm-grid">
      {rows.map((r, ri) => (
        <span key={ri} style={{ display: "contents" }}>
          <span className="lab">{r.l}</span>
          {[...r.c].map((ch, ci) => (
            <i key={ci} style={{ background: palette[+ch] }} />
          ))}
        </span>
      ))}
    </div>
  );
}

const HM_AXIS = (
  <div className="hm-axis">
    <span />
    <div>
      <span>12am</span>
      <span>6am</span>
      <span>12pm</span>
      <span>6pm</span>
      <span>12am</span>
    </div>
  </div>
);

export default function HomePage({ onNavigate }: PageProps) {
  const rootRef = useRef<HTMLElement>(null);
  usePageChrome(rootRef);
  const year = new Date().getFullYear();

  return (
    <div className="page" id="page-home" ref={rootRef}>
      <header>
        <div className="wrap nav">
          <a className="logo" href="#top">
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </a>
          <nav className="nav-links">
            <a href="#how">How it works</a>
            <a href="#fingerprint">What it analyses</a>
            <a href="#results">What you&apos;ll get</a>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
              Guides
            </a>
            <a href="#faq">FAQ</a>
          </nav>
          <div className="nav-cta">
            <a
              className="btn btn-nav-ghost"
              href="#"
              onClick={(e) => { e.preventDefault(); onNavigate("lp1"); }}
            >
              Free calculator
            </a>
            <a className="btn btn-teal btn-nav" href="#cta">
              Start free analysis
            </a>
            <ThemeToggle />
            <button className="burger" aria-label="Menu" data-burger>
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>
        <nav className="mobile-menu" data-mobile-menu>
          <a href="#how">How it works</a>
          <a href="#fingerprint">What it analyses</a>
          <a href="#results">What you&apos;ll get</a>
          <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
            Guides
          </a>
          <a href="#faq">FAQ</a>
          <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("lp1"); }}>
            Free calculator →
          </a>
          <a href="#cta" className="mm-primary">
            Start free analysis →
          </a>
        </nav>
      </header>

      <main id="top">
        {/* ---------- HERO ---------- */}
        <section className="dark hero">
          <div className="wrap hero-grid">
            <div>
              <span className="pill pill-lime">✦ &nbsp;Solar &amp; battery analysis · Australia</span>
              <h1 className="display">
                Solar.
                <br />
                <span className="c-teal">Is it worth it</span>{" "}
                <span className="c-orange">for you?</span>
              </h1>
              <p className="lead">
                Every home uses energy differently. Solar Sensei analyses your
                electricity bill and models hundreds of solar and battery
                combinations against your household&apos;s actual energy profile —
                then ranks the options by potential savings, estimated return on
                investment and break-even period.
              </p>
              <div className="hero-actions">
                <a className="btn btn-teal" href="#cta">
                  Start my free analysis
                </a>
                <a className="btn btn-ghost" href="#how">
                  See how it works
                </a>
              </div>
              <ul className="checks">
                <li>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Analyses your actual electricity rates, charges and usage timing.
                </li>
                <li>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Compares solar-only, battery-only and combined configurations.
                </li>
                <li>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Ranks modelled options so you know what to ask before quotes.
                </li>
              </ul>
              <p className="hero-fine">
                <b>Free analysis</b> · No sign-up required · Designed for Australian
                households
              </p>
            </div>
            <div className="window" aria-hidden="true">
              <div className="window-bar">
                <i className="wdot-r" />
                <i className="wdot-y" />
                <i className="wdot-g" />
                <span className="window-title">Solar Sensei analysis dashboard</span>
              </div>
              <div className="window-body">
                <div className="bench">
                  <span className="pill pill-white" style={{ fontSize: "9.5px", padding: "7px 12px" }}>
                    Data-backed benchmark
                  </span>
                  <h3>Know what to ask for before you compare quotes.</h3>
                  <p>
                    Solar Sensei models the pathways first, so installer
                    conversations start from evidence — not guesswork.
                  </p>
                  <div className="mini-grid">
                    <div className="mini">
                      <small>Solar-only</small>
                      <b>Modelled</b>
                    </div>
                    <div className="mini">
                      <small>Battery-only</small>
                      <b>Modelled</b>
                    </div>
                    <div className="mini">
                      <small>Combined</small>
                      <b>Ranked</b>
                    </div>
                    <div className="mini">
                      <small>Existing solar</small>
                      <b>Included</b>
                    </div>
                  </div>
                </div>
                <div className="panel">
                  <div className="panel-t">Clarity check</div>
                  <div className="meter-row">
                    <span>Quote guesswork</span>
                    <span className="meter">
                      <i style={{ width: "26%", background: "var(--coral)" }} />
                    </span>
                    <span style={{ color: "var(--teal-deep)" }}>Lower</span>
                  </div>
                  <div className="meter-row">
                    <span>Data clarity</span>
                    <span className="meter">
                      <i style={{ width: "88%", background: "var(--teal)" }} />
                    </span>
                    <span>High</span>
                  </div>
                  <div className="meter-row">
                    <span>Oversizing risk</span>
                    <span className="meter">
                      <i style={{ width: "20%", background: "var(--purple)" }} />
                    </span>
                    <span style={{ color: "var(--teal-deep)" }}>Lower</span>
                  </div>
                </div>
                <div className="panel">
                  <div className="panel-t">Ranked options (modelled example)</div>
                  <div className="meter-row">
                    <span>Solar + battery</span>
                    <span className="meter">
                      <i style={{ width: "92%", background: "linear-gradient(90deg,var(--teal),var(--lime))" }} />
                    </span>
                    <span>$1,850/yr</span>
                  </div>
                  <div className="meter-row">
                    <span>Solar only</span>
                    <span className="meter">
                      <i style={{ width: "70%", background: "var(--teal)" }} />
                    </span>
                    <span>$1,430/yr</span>
                  </div>
                  <div className="meter-row">
                    <span>Battery only</span>
                    <span className="meter">
                      <i style={{ width: "42%", background: "var(--coral)" }} />
                    </span>
                    <span>$610/yr</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ---------- HOW IT WORKS ---------- */}
        <section className="light" id="how">
          <div className="wrap">
            <div className="sec-head">
              <span className="pill pill-teal">How it works</span>
              <h2 className="h-serif">From your bill to a ranked shortlist.</h2>
              <p className="lead">
                Four steps. Your own data. No assumptions about &quot;average&quot; homes.
              </p>
            </div>
            <div className="steps">
              <div className="step-card">
                <div className="step-num">1</div>
                <h3>Upload your electricity bill</h3>
                <p>
                  Upload a PDF or clear image of your current bill. Solar Sensei
                  extracts usage, tariff structure, supply charges and other
                  details. No bill handy? Enter the information manually instead.
                </p>
              </div>
              <div className="step-card">
                <div className="step-num">2</div>
                <h3>Analyse your energy profile</h3>
                <p>
                  Your information is used to model how your household consumes
                  electricity — solar generation, grid imports, battery storage and
                  time-of-use tariffs.
                </p>
              </div>
              <div className="step-card">
                <div className="step-num">3</div>
                <h3>Compare possible solutions</h3>
                <p>
                  A wide range of solar and battery configurations is compared
                  against your profile — assessing whether extra solar, storage, a
                  combination, or neither may help.
                </p>
              </div>
              <div className="step-card">
                <div className="step-num">4</div>
                <h3>Review the ranked results</h3>
                <p>
                  Options are ranked by highest potential bill savings, strongest
                  estimated return on investment, fastest break-even, and best
                  cost-versus-benefit balance.
                </p>
              </div>
            </div>
            <p className="steps-note">
              The more detailed the information you provide, the more specific the
              modelled analysis can be.
            </p>
            <div
              className="strip"
              style={{ marginTop: "26px", background: "var(--wash-mint)", borderColor: "#CBE9DD" }}
            >
              <span className="strip-label">Step 5 · When you&apos;re ready to install</span>
              <span className="chip">
                <span className="dot" style={{ background: "var(--teal)" }} />
                Vetted installer network — chosen for track record, not price
              </span>
              <span className="chip">
                <span className="dot" style={{ background: "var(--gold)" }} />
                Free independent inspection on every install
              </span>
              <span className="chip">
                <span className="dot" style={{ background: "var(--coral)" }} />
                Same system price as going direct
              </span>
            </div>
            <div className="strip">
              <span className="strip-label">What Solar Sensei analyses</span>
              <span className="chip">
                <span className="dot" style={{ background: "var(--teal)" }} />
                Electricity rates &amp; charges
              </span>
              <span className="chip">
                <span className="dot" style={{ background: "var(--gold)" }} />
                Usage across the day
              </span>
              <span className="chip">
                <span className="dot" style={{ background: "var(--coral)" }} />
                Time-of-use &amp; controlled-load tariffs
              </span>
              <span className="chip">
                <span className="dot" style={{ background: "var(--purple)" }} />
                Existing solar &amp; batteries
              </span>
              <span className="chip">
                <span className="dot" style={{ background: "var(--blue)" }} />
                Feed-in arrangements
              </span>
              <span className="chip">
                <span className="dot" style={{ background: "var(--red)" }} />
                Solar · battery · combined options
              </span>
            </div>
          </div>
        </section>

        {/* ---------- FINGERPRINT ---------- */}
        <section className="dark" id="fingerprint" style={{ padding: "100px 0", background: "var(--wash-mint)" }}>
          <div className="wrap">
            <div className="sec-head">
              <span className="pill pill-teal">Usage &amp; cost fingerprint</span>
              <h2 className="h-serif">
                See when you use power — <br />
                and when it gets expensive.
              </h2>
              <p className="lead">
                Two homes with the same annual kWh can need very different
                recommendations. Timing is the difference.
              </p>
            </div>
            <div className="duo">
              <div className="duo-card">
                <div className="duo-head">
                  <span className="pill pill-teal" style={{ fontSize: "10px" }}>
                    Energy fingerprint
                  </span>
                  <span className="tag">Usage timing</span>
                </div>
                <h3>Modelled usage heatmap</h3>
                <p>
                  Highlights import patterns by day and hour, making evening and
                  weekend clusters visible.
                </p>
                <div className="hm">
                  <Heatmap
                    palette={PAL_USAGE}
                    rows={[
                      { l: "Mon", c: USAGE_WEEK },
                      { l: "Tue", c: USAGE_WEEK },
                      { l: "Wed", c: USAGE_WEEK },
                      { l: "Thu", c: USAGE_WEEK },
                      { l: "Fri", c: USAGE_WEEK },
                      { l: "Sat", c: USAGE_WKND },
                      { l: "Sun", c: USAGE_WKND },
                      { l: "Avg", c: USAGE_AVG },
                    ]}
                  />
                  {HM_AXIS}
                </div>
                <div className="legend">
                  <span>
                    <span className="dot" style={{ background: "#DDE3DA" }} />
                    Low import
                  </span>
                  <span>
                    <span className="dot" style={{ background: "#8FD6BC" }} />
                    Moderate
                  </span>
                  <span>
                    <span className="dot" style={{ background: "#FFD166" }} />
                    Morning peak
                  </span>
                  <span>
                    <span className="dot" style={{ background: "#FF8A66" }} />
                    Evening peak
                  </span>
                </div>
                <p className="insight">
                  <b>Example insight:</b> morning and evening demand peaks — plus
                  heavier weekend daytime use — show why usage timing matters for
                  solar and battery sizing.
                </p>
              </div>
              <div className="duo-card">
                <div className="duo-head">
                  <span className="pill pill-green" style={{ fontSize: "10px" }}>
                    Cost drivers
                  </span>
                  <span className="tag">Tariff exposure</span>
                </div>
                <h3>Modelled cost heatmap</h3>
                <p>
                  Colours the same intervals by dollar impact under the current
                  tariff.
                </p>
                <div className="hm">
                  <Heatmap
                    palette={PAL_COST}
                    rows={[
                      { l: "Mon", c: COST_WEEK },
                      { l: "Tue", c: COST_WEEK },
                      { l: "Wed", c: COST_WEEK },
                      { l: "Thu", c: COST_WEEK },
                      { l: "Fri", c: COST_WEEK },
                      { l: "Sat", c: COST_WKND },
                      { l: "Sun", c: COST_WKND },
                      { l: "Avg", c: COST_AVG },
                    ]}
                  />
                  {HM_AXIS}
                </div>
                <div className="legend">
                  <span>
                    <span className="dot" style={{ background: "#9CC3F5" }} />
                    Off-peak
                  </span>
                  <span>
                    <span className="dot" style={{ background: "#FFD166" }} />
                    Shoulder
                  </span>
                  <span>
                    <span className="dot" style={{ background: "#FF8A66" }} />
                    Peak
                  </span>
                </div>
                <p className="insight">
                  <b>Example insight:</b> the same evening usage pattern becomes
                  more expensive under peak tariffs, so tariff timing can drive the
                  recommendation.
                </p>
              </div>
            </div>
            <p className="hm-note">
              Modelled illustration based on typical interval data. Your fingerprint
              is built from the bill information you provide.
            </p>
          </div>
        </section>

        {/* ---------- WHY SOLAR SENSEI ---------- */}
        <section className="light" id="different">
          <div className="wrap">
            <div className="sec-head">
              <span className="pill pill-teal">Why Solar Sensei</span>
              <h2 className="h-serif">Built to question the default answer.</h2>
              <p className="lead">
                Most tools start with a product. Solar Sensei starts with your
                household.
              </p>
            </div>
            <div className="trio">
              <div className="trio-card">
                <div className="icon-bub" style={{ background: "#E2F5F1", color: "#0B7C72" }}>
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                    <path d="M4 20V4" />
                    <path d="M4 20h16" />
                    <path d="M8 15l4-6 3 3 4-7" />
                  </svg>
                </div>
                <h3>Averages hide the details</h3>
                <p>
                  Generic calculators rely on broad assumptions about consumption,
                  prices and generation. Useful for a rough indication — but they
                  can&apos;t reflect how your home actually uses energy. Solar Sensei
                  starts with your own electricity information.
                </p>
              </div>
              <div className="trio-card">
                <div className="icon-bub" style={{ background: "#FFF0E6", color: "#B4632E" }}>
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                    <circle cx="12" cy="12" r="4" />
                    <path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1" />
                  </svg>
                </div>
                <h3>More solar isn&apos;t always better</h3>
                <p>
                  Generation alone doesn&apos;t determine the financial result. The
                  balance between each of these matters — and Solar Sensei examines
                  it rather than assuming bigger is best:
                </p>
                <div className="balance-chips">
                  <span>Generating more</span>
                  <span>Using power directly</span>
                  <span>Storing surplus</span>
                  <span>Reducing grid imports</span>
                  <span>Exporting excess</span>
                </div>
              </div>
              <div className="trio-card">
                <div className="icon-bub" style={{ background: "#EFE9FB", color: "#6B46C1" }}>
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                    <rect x="2.5" y="8" width="15" height="9" rx="2.5" />
                    <path d="M20.5 11v3" />
                    <path d="M6 11v3M10 11v3" />
                  </svg>
                </div>
                <h3>No preset battery agenda</h3>
                <p>
                  A battery can suit some households, but it isn&apos;t automatically the
                  best investment. Its value depends on evening consumption, tariff
                  rates, solar surplus, battery cost and how long you expect to stay.
                  Solar Sensei compares the alternatives instead of starting with a
                  product recommendation.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ---------- RESULTS / REPORT FLOW ---------- */}
        <section className="light results" id="results">
          <div className="wrap">
            <div className="split">
              <div>
                <span className="pill pill-blue">Report flow</span>
                <h2 className="h-serif">
                  The answer first — then the evidence behind it.
                </h2>
                <ul className="checks" style={{ color: "var(--l-head)" }}>
                  <li style={{ color: "var(--body)" }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" style={{ color: "var(--teal)" }}>
                      <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    Executive summary with estimated savings, payback and confidence.
                  </li>
                  <li style={{ color: "var(--body)" }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" style={{ color: "var(--teal)" }}>
                      <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    Usage and cost fingerprint built from your bill information.
                  </li>
                  <li style={{ color: "var(--body)" }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" style={{ color: "var(--teal)" }}>
                      <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    Solar-only, battery-only and combined scenario comparison.
                  </li>
                  <li style={{ color: "var(--body)" }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" style={{ color: "var(--teal)" }}>
                      <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    Transparent assumptions and limitations, stated up front.
                  </li>
                </ul>
                <p style={{ marginTop: "22px" }}>
                  <a
                    className="btn btn-teal"
                    href="#"
                    onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}
                  >
                    Read the guides first →
                  </a>
                </p>
              </div>
              <div className="report-card">
                <div className="rc-head">
                  <div>
                    <span className="pill pill-teal" style={{ fontSize: "10px" }}>
                      Executive recommendation
                    </span>
                    <h3 style={{ marginTop: "10px" }}>Decision summary card</h3>
                  </div>
                  <span className="tag" style={{ background: "#E7EEFB", color: "#2C5B9F", borderColor: "#CFE0F5" }}>
                    Answer first
                  </span>
                </div>
                <div className="reco">
                  <div>
                    <span className="pill pill-lime" style={{ fontSize: "9.5px", padding: "6px 11px" }}>
                      Modelled pathway
                    </span>
                    <h4>6.6 kW solar + 13.5 kWh battery</h4>
                    <p>
                      Selected because it may capture midday surplus and offset
                      expensive evening imports for this usage pattern.
                    </p>
                  </div>
                  <div className="donut-wrap" style={{ ["--p" as string]: 78 } as React.CSSProperties}>
                    <div className="donut" />
                    <div className="donut-val">
                      <b>78%</b>
                      <span>self-sufficiency</span>
                    </div>
                  </div>
                </div>
                <div className="stats">
                  <div className="stat">
                    <small>Year 1 est. savings</small>
                    <b>$1,850</b>
                  </div>
                  <div className="stat">
                    <small>Indicative payback</small>
                    <b>6.4 yrs</b>
                  </div>
                  <div className="stat">
                    <small>10-yr potential</small>
                    <b>$21.8k</b>
                  </div>
                  <div className="stat">
                    <small>Self-sufficiency</small>
                    <b>78%</b>
                  </div>
                </div>
                <p className="rc-note">
                  <b>Example insight:</b> the report explains the trade-off — not just
                  the selected system size. Modelled illustration only; your results
                  depend on the information you provide.
                </p>
              </div>
            </div>
            <div className="receive">
              <h3>Your results at a glance</h3>
              <ul className="receive-grid">
                <li>
                  <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Estimated household consumption
                </li>
                <li>
                  <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Grid imports and solar exports
                </li>
                <li>
                  <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  The effect of time-of-use pricing
                </li>
                <li>
                  <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Potential solar generation
                </li>
                <li>
                  <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Battery charging and discharge behaviour
                </li>
                <li>
                  <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Estimated bill impact
                </li>
                <li>
                  <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Comparison of different system sizes
                </li>
                <li>
                  <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Indicative savings and payback measures
                </li>
                <li>
                  <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Ranked options based on different priorities
                </li>
              </ul>
              <p className="caveat">
                Results are modelled and indicative based on the information
                provided. They are not guaranteed savings, a quotation, or financial
                advice.
              </p>
            </div>
          </div>
        </section>

        {/* ---------- AUSTRALIA-WIDE ---------- */}
        <section className="brisbane" id="brisbane">
          <div className="wrap b-grid">
            <div>
              <span className="pill pill-orange">Australia-wide</span>
              <h2 className="h-serif">Solar decisions need local context.</h2>
            </div>
            <div className="b-copy">
              <p>
                Australian homeowners enjoy strong solar potential — but the most
                suitable system still depends on the home&apos;s individual energy
                profile. Household demand, electricity tariffs, roof orientation,
                shading, existing solar equipment and battery use can all influence
                the financial outcome.
              </p>
              <p>
                Solar Sensei provides analysis for homeowners across Australia. It
                helps you investigate your options before approaching a solar
                retailer or installer — wherever you are.
              </p>
              <div className="b-highlight">
                <p>
                  Thinking about solar panels or a home battery? Before comparing
                  system prices, find out how different options may work with your
                  household&apos;s actual electricity use. Solar Sensei analyses your
                  bill, tariff structure and consumption profile, then compares
                  solar and battery combinations to help identify the options most
                  likely to improve your energy costs.
                </p>
              </div>
              <div className="b-chips">
                <span className="b-chip">📍 Australia-wide</span>
                <span className="b-chip">🇦🇺 Australian tariffs &amp; feed-in rates</span>
                <span className="b-chip">☀️ Climate &amp; location-aware modelling</span>
                <span className="b-chip">🛡️ Free independent inspection on every install</span>
              </div>
            </div>
          </div>
        </section>

        {/* ---------- CTA / FREE ANALYSIS FORM ---------- */}
        <section className="cta" id="cta">
          <div className="wrap cta-grid">
            <div>
              <span className="pill pill-lime">Start your free analysis</span>
              <h2 className="h-serif">Analyse before you commit.</h2>
              <p className="lead">
                A solar quote tells you what a company wants to sell you. An
                independent analysis can help you understand what your household may
                actually need. Explore the likely impact of different system
                combinations before comparing installation quotes.
              </p>
              <ul className="checks">
                <li>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Get a benchmark before installer conversations.
                </li>
                <li>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Compare plan, solar-only, battery and combined pathways.
                </li>
                <li>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  See modelled savings, payback and self-sufficiency.
                </li>
              </ul>
              <div className="trust-row">
                <span>🔒 No sign-up required</span>
                <span>📋 Indicative — not a quote</span>
                <span>🛡️ Vetted installs · independent inspection included</span>
              </div>
            </div>
            <div className="form-card">
              <div className="form-head">
                <h3>Start your free analysis</h3>
                <span className="tag" style={{ background: "#F2F9D3", color: "#55731A", borderColor: "#DDEBB0" }}>
                  Free · No sign-up
                </span>
              </div>
              <p>Choose how to provide your information, and continue to the analysis setup.</p>
              <OptGroup
                opts={[
                  {
                    title: "Upload my bill",
                    desc: "PDF or clear photo. Fastest, most specific analysis.",
                    defaultSelected: true,
                  },
                  {
                    title: "Enter details manually",
                    desc: "If your bill isn't handy. Results may be less specific.",
                  },
                ]}
              />
              <button className="btn btn-teal btn-block">Continue to my analysis →</button>
              <p className="form-fine">
                Next, you&apos;ll be guided through providing a recent bill or your
                usage details. Your results are modelled and indicative.
              </p>
              <div className="form-chips">
                <div>Secure start</div>
                <div>Customer-controlled</div>
                <div>Quote-ready output</div>
              </div>
            </div>
          </div>
        </section>

        {/* ---------- LIMITATIONS ---------- */}
        <section className="limits">
          <div className="wrap">
            <div className="limits-box">
              <h3>Important limitations</h3>
              <ul>
                <li>
                  Solar Sensei provides independent analysis first; installations,
                  where chosen, are arranged through a vetted third-party installer
                  network — Solar Sensei is not an installer and does not provide
                  financial advice.
                </li>
                <li>Results are indicative modelled estimates, not guaranteed savings.</li>
                <li>
                  The analysis is not an installation quote, financial guarantee or
                  electrical design.
                </li>
                <li>Accuracy depends on the completeness of the information you provide.</li>
                <li>Household energy use, tariffs and prices can change over time.</li>
                <li>
                  Consult a suitably qualified installer or electrician before any
                  purchase decision.
                </li>
                <li>Analysis is available Australia-wide; installation availability varies by state.</li>
              </ul>
            </div>
          </div>
        </section>

        {/* ---------- FAQ ---------- */}
        <section className="faq" id="faq">
          <div className="wrap">
            <div className="sec-head">
              <span className="pill pill-teal">FAQ</span>
              <h2 className="h-serif">Frequently asked questions.</h2>
            </div>
            <FaqList
              items={[
                {
                  q: "Is Solar Sensei a solar installer?",
                  a: "No — installation is carried out by licensed third-party installers. Solar Sensei's role is the independent analysis first, then arranging your install through a small vetted network, with a free independent inspection afterwards. Keeping analysis, installation and verification separate is what keeps the recommendation honest.",
                },
                {
                  q: "Does Solar Sensei arrange the installation?",
                  a: "If you want us to, yes. After your analysis you can have your system installed through our vetted installer network. Every install includes a free independent inspection — a third-party report confirming the work meets regulation and the expected standard — at no extra cost, and you pay the same system price as going direct.",
                },
                {
                  q: "Does Solar Sensei recommend a specific brand?",
                  a: "The tool is intended to compare system approaches and configurations rather than direct users toward a particular product brand. The purpose is to help homeowners understand which type of solution may suit their energy profile.",
                },
                {
                  q: "Do I need an electricity bill?",
                  a: "A bill provides useful information about consumption, tariffs and charges. If you don't have one available, information can be entered manually, although the results may be less specific.",
                },
                {
                  q: "Can Solar Sensei analyse an existing solar system?",
                  a: "Yes. Existing solar can be included when assessing whether additional panels, battery storage or another configuration may improve the household's position.",
                },
                {
                  q: "Does a battery always reduce electricity bills?",
                  a: "Not necessarily. The potential value of a battery depends on factors including your household's energy use, tariff structure, solar surplus, battery cost and operating assumptions. Solar Sensei compares battery options against the alternatives rather than assuming a battery suits every home.",
                },
                {
                  q: "Is the analysis a quote?",
                  a: "No. The analysis is not an installation quote, financial guarantee or electrical design. It is an indicative modelling tool to help homeowners make better-informed decisions and ask more relevant questions when obtaining professional quotes.",
                },
                {
                  q: "Where is Solar Sensei available?",
                  a: "Analysis is available to homeowners across Australia, built on Australian tariffs, feed-in rates and conditions. Installation through our vetted network is currently available in Queensland, with more states being added — and the analysis remains a strong basis for comparing quotes wherever you are.",
                },
              ]}
            />
          </div>
        </section>
      </main>

      {/* ---------- FOOTER ---------- */}
      <footer>
        <div className="wrap">
          <div className="f-grid">
            <div className="f-brand">
              <div className="f-logo">
                <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
                  <use href="#mark-lantern" />
                </svg>
                <span className="wm-text">
                  Solar <b>Sensei</b>
                </span>
              </div>
              <p>
                Independent analysis first — then a small vetted installer network,
                with a free independent inspection included on every install. No
                particular brand to sell.
              </p>
              <p style={{ color: "var(--f-mut)" }}>Serving homeowners across Australia.</p>
            </div>
            <div>
              <h4>Explore</h4>
              <ul>
                <li><a href="#how">How it works</a></li>
                <li><a href="#results">What you&apos;ll get</a></li>
                <li>
                  <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("lp1"); }}>
                    Free solar &amp; battery calculator
                  </a>
                </li>
                <li>
                  <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
                    Guides &amp; articles
                  </a>
                </li>
                <li><a href="#brisbane">Service area</a></li>
                <li><a href="#faq">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h4>Guides</h4>
              <ul>
                <li>
                  <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("pl"); }}>
                    Before you get solar quotes
                  </a>
                </li>
                <li>
                  <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("a1"); }}>
                    How to read your electricity bill
                  </a>
                </li>
                <li>
                  <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("a2"); }}>
                    When does a battery make financial sense?
                  </a>
                </li>
                <li>
                  <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("a3"); }}>
                    Understanding time-of-use tariffs &amp; solar
                  </a>
                </li>
                <li>
                  <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("qd"); }}>
                    Queensland quality installs
                  </a>
                </li>
                <li>
                  <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
                    Browse all guides →
                  </a>
                </li>
                <li className="f-soon">Coming soon: How much solar do I need?</li>
              </ul>
            </div>
            <div>
              <h4>Legal</h4>
              <ul>
                <li><a href="#">Disclaimer &amp; limitations</a></li>
                <li><a href="#">Privacy policy</a></li>
                <li><a href="#">Terms of use</a></li>
              </ul>
            </div>
          </div>
          <div className="f-bottom">
            <span>© {year} Solar Sensei · Australia</span>
            <span>Indicative modelling only — not a quote or financial advice.</span>
          </div>
        </div>
      </footer>

      {/* ---------- STICKY CTA ---------- */}
      <div className="stickybar">
        <p>Informed choice starts here.</p>
        <a className="btn btn-teal" href="#cta">
          Start analysis
        </a>
      </div>
    </div>
  );
}
