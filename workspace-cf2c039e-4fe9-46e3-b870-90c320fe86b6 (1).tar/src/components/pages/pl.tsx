"use client";

import { useRef } from "react";
import { PageProps } from "@/components/solar/types";
import { usePageChrome } from "@/components/solar/usePageChrome";
import { ThemeToggle } from "@/components/solar/ThemeToggle";
import { HeroImage, InsetImage } from "@/components/solar/GuideImage";
import { FaqList } from "@/components/solar/Faq";

/* ---------- FAQ items (shared between visible list + JSON-LD schema) ---------- */
const FAQ_ITEMS: { q: string; a: string }[] = [
  {
    q: "Is SolarQuotes a good way to get solar quotes?",
    a: "SolarQuotes and similar services can be a convenient starting point for finding installers and obtaining multiple proposals. However, quotes are generally most useful after you have assessed the likely solar and battery configuration for your household. Comparing several proposals does not automatically determine whether you need more solar panels, a battery, both or no upgrade.",
  },
  {
    q: "Is Solar Choice a good way to compare solar and battery systems?",
    a: "Solar Choice and other comparison services may help consumers connect with providers. The important distinction is between comparing suppliers and deciding what system your household needs. Consider your energy usage, existing solar generation, exports, electricity tariff and future demand before deciding whether a recommendation is appropriately sized.",
  },
  {
    q: "Are three solar quotes enough?",
    a: "Three quotes can help compare installer scope, pricing, equipment, warranties and service. But they may not identify the best system design if each quote recommends a different solution. Establishing a likely household-level upgrade path first makes quotes easier to compare.",
  },
  {
    q: "Should I add a battery to my existing solar system?",
    a: "It depends on your solar exports, evening and overnight electricity use, retail electricity tariff, feed-in tariff, existing equipment, battery compatibility and goals. A battery may be worth investigating where you regularly export solar energy during the day and purchase significant grid electricity after sunset.",
  },
  {
    q: "Is it better to add more solar panels or a battery?",
    a: "Additional panels may be the stronger first option where your existing solar system is small and you have suitable roof space. A battery may be more appropriate if you already export substantial solar energy and use significant electricity outside solar-production hours. The best option depends on your household data and objectives.",
  },
  {
    q: "Can I add a battery to an older solar system?",
    a: "Often, yes. An AC-coupled battery can often be added without replacing the existing solar inverter. A qualified installer should assess equipment condition, electrical compatibility, switchboard capacity, network requirements, backup-power needs and site-specific design issues before work proceeds.",
  },
  {
    q: "Can a solar battery save money in Australia?",
    a: "A battery can reduce grid electricity purchases by storing solar energy for later use. The financial result depends on upfront cost, usable capacity, electricity and feed-in tariffs, household consumption, solar generation, battery operation, degradation and warranty terms. A household-specific assessment is more useful than generic savings claims.",
  },
];

const FAQ_SCHEMA = FAQ_ITEMS.map((it) => ({
  "@type": "Question",
  name: it.q,
  acceptedAnswer: { "@type": "Answer", text: it.a },
}));

export default function PlPage({ onNavigate }: PageProps) {
  const rootRef = useRef<HTMLElement>(null);
  usePageChrome(rootRef);
  const year = new Date().getFullYear();

  return (
    <div className="page" id="page-pl" ref={rootRef}>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BlogPosting",
            headline:
              "Before You Get Solar Quotes, Find the Right Solar and Battery Setup",
            description:
              "Three quotes can compare installers — but not tell you what your household needs. Find the right solar and battery pathway before entering the quoting process.",
            datePublished: "2026-08-25",
            dateModified: "2026-08-25",
            author: { "@type": "Organization", name: "Solar Sensei" },
            publisher: { "@type": "Organization", name: "Solar Sensei" },
            mainEntityOfPage:
              "https://www.solarsensei.com.au/before-you-get-solar-quotes",
          }),
        }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            mainEntity: FAQ_SCHEMA,
          }),
        }}
      />

      <header>
        <div className="wrap nav">
          <a
            className="logo"
            href="#"
            onClick={(e) => {
              e.preventDefault();
              onNavigate("home");
            }}
          >
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </a>
          <nav className="nav-links">
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("hub");
              }}
            >
              All guides
            </a>
            <a href="#pl-platforms">Comparison platforms</a>
            <a href="#pl-paths">Four pathways</a>
            <a href="#pl-use">Using quotes</a>
            <a href="#pl-faq">FAQ</a>
          </nav>
          <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
            <a
              className="btn btn-teal btn-nav"
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("lp1", "#cta1");
              }}
            >
              Start free analysis
            </a>
            <ThemeToggle />
            <button className="burger" aria-label="Menu" data-burger>
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>
        <nav className="mobile-menu" data-mobile-menu>
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              onNavigate("hub");
            }}
          >
            All guides
          </a>
          <a href="#pl-platforms">Comparison platforms</a>
          <a href="#pl-paths">Four pathways</a>
          <a href="#pl-use">Using quotes</a>
          <a href="#pl-faq">FAQ</a>
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              onNavigate("lp1", "#cta1");
            }}
            className="mm-primary"
          >
            Start free analysis →
          </a>
        </nav>
      </header>

      <main id="top">
        {/* ---------- HERO ---------- */}
        <section className="dark hero-a">
          <div className="wrap">
            <nav className="crumb" aria-label="Breadcrumb">
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("home");
                }}
              >
                Home
              </a>
              <span>›</span>
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("hub");
                }}
              >
                Guides
              </a>
              <span>›</span>
              <b>Before you get quotes</b>
            </nav>
            <span className="pill pill-lime">✦ &nbsp;Guide · Quotes &amp; strategy</span>
            <h1>
              Before you get solar quotes, find the right{" "}
              <em style={{ fontStyle: "normal" }} className="c-teal">
                solar and battery setup
              </em>
            </h1>
            <p className="lede">
              Comparing SolarQuotes or Solar Choice, or weighing up a battery?
              Three quotes can compare installers — but they can&apos;t tell you
              what your household actually needs. Here&apos;s the logic to work
              out first.
            </p>
            <div className="meta-row">
              <span className="m-chip">🗓️ Updated 25/08/26</span>
              <span className="m-chip">📖 9 min read</span>
              <span className="m-chip">🇦🇺 Australian market</span>
              <span className="m-chip">
                ✅ General information — not installation or financial advice
              </span>
            </div>
            <HeroImage
              src="/guides/pl.jpg"
              alt="Solar installers in safety gear fitting photovoltaic panels to a roof"
              caption="Installer quality and correct system sizing matter more than the headline price on a solar quote."
            />
          </div>
        </section>

        <div className="wrap a-layout">
          {/* ---------- SIDEBAR ---------- */}
          <aside className="side">
            <div className="side-card">
              <h4>On this page</h4>
              <nav className="toc">
                <a href="#pl-intro">The three-quote assumption</a>
                <a href="#pl-platforms">
                  SolarQuotes, Solar Choice &amp; the process
                </a>
                <a href="#pl-notlike">Quotes aren&apos;t like-for-like</a>
                <a href="#pl-why">Why quotes differ so much</a>
                <a href="#pl-paths">Panels, battery, both — or neither?</a>
                <a href="#pl-use">Using quotes more effectively</a>
                <a href="#pl-free">A free starting point</a>
                <a href="#pl-faq">FAQ</a>
              </nav>
            </div>
            <div className="side-card side-cta">
              <h4>Free analysis</h4>
              <p>
                Find your likely pathway before the quoting process begins.
              </p>
              <a
                className="btn btn-teal"
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("lp1", "#cta1");
                }}
                style={{ width: "100%" }}
              >
                Start free analysis
              </a>
            </div>
            <div className="side-card">
              <h4>More guides</h4>
              <nav className="toc">
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate("qd");
                  }}
                >
                  Queensland quality installs
                </a>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate("a1");
                  }}
                >
                  Read your electricity bill
                </a>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate("a2");
                  }}
                >
                  Battery: when it makes sense
                </a>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate("a3");
                  }}
                >
                  Time-of-use tariffs &amp; solar
                </a>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate("hub");
                  }}
                >
                  Browse all guides →
                </a>
              </nav>
            </div>
          </aside>

          {/* ---------- ARTICLE ---------- */}
          <article className="prose">
            <h2 id="pl-intro">The three-quote assumption</h2>
            <p>
              If you are searching for solar battery quotes, comparing
              SolarQuotes or Solar Choice, or trying to work out whether a
              battery is worthwhile, it is easy to assume that getting three
              quotes is the best first step.
            </p>
            <p>It can be useful — but it is not always the right starting point.</p>
            <p>
              Three solar quotes can help you compare installers, equipment,
              warranties and pricing. They do not necessarily tell you whether
              your household needs more solar panels, a battery, both, or no
              upgrade at all.
            </p>
            <p>
              Before entering a sales and quoting process, it helps to
              understand the basic logic of what is likely to work best for your
              household.
            </p>

            <InsetImage
              src="/guides/pl-inset.jpg"
              alt="A solar inverter and battery storage unit installed in an enclosure on an exterior wall"
              caption="A typical solar and battery installation: inverter, battery enclosure and safety isolators on an exterior wall."
            />
            <h2 id="pl-platforms">
              SolarQuotes, Solar Choice and the three-quote process
            </h2>
            <p>
              Services such as SolarQuotes, Solar Choice and other solar
              comparison platforms can be a convenient way to find installers and
              request multiple proposals.
            </p>
            <p>
              That has obvious benefits. Solar and battery systems are
              significant purchases, and comparing installer experience, product
              options, warranty support, inclusions and price is sensible.
            </p>
            <p>
              However, a quote-request service generally begins a process in
              which several businesses contact you to recommend and price a
              system. Each business may have different preferred brands, product
              availability, installation methods, commercial arrangements and
              views about system design.
            </p>
            <p>As a result, you may receive several different recommendations:</p>
            <div
              style={{
                display: "flex",
                flexWrap: "wrap",
                gap: "9px",
                margin: "18px 0 20px",
              }}
            >
              <span className="chip">
                <span className="dot" style={{ background: "var(--teal)" }} />
                Add more solar panels first
              </span>
              <span className="chip">
                <span className="dot" style={{ background: "var(--gold)" }} />
                Install a battery with existing solar
              </span>
              <span className="chip">
                <span className="dot" style={{ background: "var(--coral)" }} />
                Replace the inverter with a hybrid
              </span>
              <span className="chip">
                <span className="dot" style={{ background: "var(--purple)" }} />
                Install a larger battery
              </span>
              <span className="chip">
                <span className="dot" style={{ background: "var(--blue)" }} />
                Replace the whole system
              </span>
              <span className="chip">
                <span className="dot" style={{ background: "var(--red)" }} />
                Make no changes — adjust usage
              </span>
            </div>
            <p>
              Any one of those recommendations may be appropriate. But without a
              clear understanding of your household energy profile, it can be
              difficult to tell which proposal is genuinely aligned with your
              needs.
            </p>

            <h2 id="pl-notlike">
              Comparing quotes is not the same as choosing the right system
            </h2>
            <p>
              The central issue is that solar and battery quotes are often not
              like-for-like.
            </p>
            <p>
              One installer may quote a 10 kWh battery. Another may recommend 13
              kWh, while a third proposes 20 kWh of storage alongside additional
              solar panels and a new inverter.
            </p>
            <p>
              Those quotes may all look professional. Each may include credible
              products and legitimate savings estimates. Yet they may be solving
              different problems.
            </p>
            <p>
              A lower-priced proposal may involve a smaller battery that does
              not cover much of your evening electricity use. A larger system may
              offer greater capability but cost more than the likely benefit
              justifies. A full system replacement may be sensible if your
              existing equipment is old or incompatible — or unnecessary if a
              battery retrofit is practical.
            </p>
            <div className="why">
              <b>The principle</b>
              The right solution is not automatically the cheapest, largest or
              most heavily promoted one. It is the system that best matches your
              household&apos;s electricity use, solar generation, equipment,
              tariff and goals.
            </div>

            <h2 id="pl-why">Why solar and battery quotes can be so different</h2>
            <p>
              Different installers can reach different recommendations because a
              solar and battery upgrade involves more than a simple product
              choice. A useful analysis should consider:
            </p>
            <ul className="plain">
              <li>Annual household electricity consumption</li>
              <li>Daytime, evening and overnight energy use</li>
              <li>Existing solar capacity and actual generation</li>
              <li>The amount of solar energy you export to the grid</li>
              <li>
                Your electricity tariff, including time-of-use rates where
                relevant
              </li>
              <li>
                Your feed-in tariff and the value of exported solar energy
              </li>
              <li>Existing inverter type, age and battery compatibility</li>
              <li>
                Roof space, panel orientation, shading and network export limits
              </li>
              <li>
                Expected changes to the household, such as an EV, pool, heat
                pump, home office or replacement of gas appliances
              </li>
              <li>
                Your objectives, including lower bills, backup power, greater
                energy independence or environmental outcomes
              </li>
            </ul>
            <p>
              For example, a home with high daytime solar exports and
              substantial electricity use after sunset may be a sensible
              candidate for a battery.
            </p>
            <p>
              But a household with a small existing solar system and available
              roof space may benefit more from additional panels before
              considering battery storage.
            </p>
            <p>
              And sometimes the analysis may suggest that no major upgrade is
              currently justified. That is still a useful outcome: it can prevent
              an expensive decision being made before the underlying numbers
              support it.
            </p>

            <h2 id="pl-paths">
              Do you need more solar panels, a battery, both — or neither?
            </h2>
            <p>
              There is no single answer for every Australian home. The best next
              step will usually fall into one of four broad categories.
            </p>

            <h3>
              <span className="h3num">
                <span className="nbadge c1">1</span>
                Add more solar panels
              </span>
            </h3>
            <p>Additional solar panels may be worth investigating where:</p>
            <ul className="plain">
              <li>Your current solar system is relatively small</li>
              <li>
                Your household still buys significant electricity during daylight
                hours
              </li>
              <li>You have suitable roof space with limited shading</li>
              <li>
                Your inverter and network connection can accommodate expansion
              </li>
              <li>
                You anticipate higher future electricity use, such as EV charging
                or electrification
              </li>
            </ul>
            <p>
              More solar may reduce daytime grid purchases and provide additional
              energy that could later support a battery.
            </p>

            <h3>
              <span className="h3num">
                <span className="nbadge c2">2</span>
                Retrofit a battery to existing solar
              </span>
            </h3>
            <p>A battery retrofit may be worth exploring where:</p>
            <ul className="plain">
              <li>
                Your household exports substantial solar energy during the day
              </li>
              <li>
                You buy a meaningful amount of grid electricity in the evening or
                overnight
              </li>
              <li>Your current solar system is producing reliably</li>
              <li>
                Your equipment and switchboard can support a battery installation
              </li>
              <li>
                You understand the distinction between bill savings and
                backup-power capability
              </li>
            </ul>
            <p>
              In many cases, an AC-coupled battery can be added to an existing
              solar system without replacing the original solar inverter.
              However, a qualified installer must assess compatibility, system
              condition, network requirements and site-specific electrical
              issues.
            </p>

            <h3>
              <span className="h3num">
                <span className="nbadge c3">3</span>
                Add solar and battery capacity together
              </span>
            </h3>
            <p>
              A combined upgrade may be appropriate where the existing solar
              system is too small to create sufficient surplus energy for storage,
              while the household also has substantial evening consumption.
            </p>
            <p>
              This approach can make sense for some homes, but it requires
              careful sizing. Installing a large battery without enough solar
              energy to charge it — or adding panels without considering the
              timing of household use — may reduce the value of the investment.
            </p>

            <h3>
              <span className="h3num">
                <span className="nbadge c4">4</span>
                Make no change for now
              </span>
            </h3>
            <p>Sometimes the best immediate decision is to wait.</p>
            <p>
              That may be the case where the likely savings are limited, the
              existing system is already well matched to household use, major
              lifestyle changes are expected soon, equipment replacement is
              imminent, or the household wants to monitor its consumption before
              committing to a larger investment.
            </p>
            <p>
              Good consumer advice should be able to identify when an upgrade may
              not yet be the strongest option.
            </p>

            <h2 id="pl-use">How to use solar quotes more effectively</h2>
            <p>
              Solar comparison services can still be useful once you have a
              clearer idea of what you are trying to achieve. Instead of asking
              installers to decide everything from the beginning, you can approach
              the quote process with a more informed brief. That makes it easier
              to compare scope, equipment, service and price.
            </p>
            <p>When reviewing quotes, consider asking:</p>
            <div className="q-grid">
              <div className="q-item">
                Why is this solar system or battery size appropriate for my
                household?
              </div>
              <div className="q-item">
                What usage, tariff and solar-generation assumptions sit behind the
                savings estimate?
              </div>
              <div className="q-item">
                How much of my evening and overnight consumption is the battery
                expected to cover?
              </div>
              <div className="q-item">
                Does the proposal include additional solar capacity, and why?
              </div>
              <div className="q-item">
                Can the system work with my existing inverter and panels?
              </div>
              <div className="q-item">
                Is backup power included, and which circuits or appliances can
                run during an outage?
              </div>
              <div className="q-item">
                Are switchboard upgrades, export limits, grid-connection
                requirements or other costs included?
              </div>
              <div className="q-item">
                What are the product, installation and workmanship warranty
                arrangements?
              </div>
              <div className="q-item">
                How does this quote compare with a smaller or larger alternative?
              </div>
            </div>

            <h2 id="pl-free">
              A free starting point for solar and battery decisions
            </h2>
            <p>
              A free solar and battery analysis tool can help Australian
              households assess their options before they become caught between
              competing recommendations.
            </p>
            <p>
              It does not sell a particular panel, battery or installation
              package. Instead, it helps you understand the likely logic of the
              available pathways:
            </p>
            <ul className="plain">
              <li>Retain your current system</li>
              <li>Add solar panels</li>
              <li>Add battery storage</li>
              <li>Combine solar and battery upgrades</li>
              <li>
                Investigate further because existing equipment may limit the
                available options
              </li>
            </ul>
            <p>
              The goal is not to replace installer advice. A qualified installer
              remains essential for site inspections, electrical design, safety,
              compliance, final equipment selection and installation.
            </p>
            <p>
              The goal is to give you a clearer starting point — so you can seek
              quotes with confidence, ask better questions and recognise whether
              a proposal is likely to suit your home.
            </p>

            <div className="icb">
              <div>
                <h3>Find your pathway before the quotes arrive.</h3>
                <p>
                  The free Solar Sensei analysis models your usage, tariff and
                  existing system — then ranks solar, battery and combined
                  options so you enter the quoting process with a brief.
                </p>
              </div>
              <a
                className="btn btn-teal"
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("lp1", "#cta1");
                }}
              >
                Start your free analysis
              </a>
            </div>

            <h2 id="pl-faq">Frequently asked questions</h2>
            <FaqList items={FAQ_ITEMS} />

            <section className="cta-sec" id="pl-cta">
              <div className="cta-box">
                <span className="pill pill-lime">Free · No sign-up required</span>
                <h2>Make the decision before you compare the quotes.</h2>
                <p>
                  Start with your energy use, existing system, tariffs and future
                  plans. Then obtain quotes for the solution most likely to fit
                  your household — not simply the package a sales process puts in
                  front of you.
                </p>
                <a
                  className="btn btn-teal"
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate("lp1", "#cta1");
                  }}
                >
                  Use the free analysis tool →
                </a>
                <div className="cta-trust">
                  <span>🔒 No sign-up required</span>
                  <span>📍 Australia-wide</span>
                  <span>📋 Indicative modelling — not a quote</span>
                </div>
              </div>
            </section>

            <div className="limits" style={{ padding: "20px 0 0" }}>
              <div className="limits-box">
                <h3>General information only</h3>
                <p
                  style={{
                    fontSize: "13.5px",
                    color: "var(--l-mut)",
                    margin: 0,
                  }}
                >
                  This article provides household-level guidance to support
                  informed decision-making. It does not replace a site
                  inspection, electrical design, financial advice or advice from
                  a qualified solar and battery installer. Actual system
                  suitability, cost, savings and installation requirements depend
                  on site-specific circumstances.
                </p>
              </div>
            </div>

            <h2>Keep reading</h2>
            <div className="related">
              <a
                className="rel-card"
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("qd");
                }}
              >
                <small>Guide · Queensland</small>
                <h3>Getting quotes at Queensland: ensuring a quality install</h3>
                <p>
                  Why a good price doesn&apos;t guarantee a good install — and
                  what to check.
                </p>
              </a>
              <a
                className="rel-card"
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("a2");
                }}
              >
                <small>Guide · Battery</small>
                <h3>When does battery storage make financial sense?</h3>
                <p>The green-light / caution-sign framework for battery decisions.</p>
              </a>
              <a
                className="rel-card"
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("a1");
                }}
              >
                <small>Guide · Your bill</small>
                <h3>How to read your electricity bill</h3>
                <p>The six figures that shape any solar or battery analysis.</p>
              </a>
            </div>
          </article>
        </div>
      </main>

      <footer className="f-mini">
        <div className="wrap fmini">
          <div className="f-logo">
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </div>
          <nav>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("hub");
              }}
            >
              All guides
            </a>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("qd");
              }}
            >
              QLD installs
            </a>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("a2");
              }}
            >
              Battery guide
            </a>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("lp1", "#cta1");
              }}
            >
              Calculator
            </a>
          </nav>
          <p>
            Independent analysis for Australian homeowners. Indicative modelling
            only — not a quote or financial advice. © {year} Solar Sensei.
          </p>
        </div>
      </footer>
    </div>
  );
}
