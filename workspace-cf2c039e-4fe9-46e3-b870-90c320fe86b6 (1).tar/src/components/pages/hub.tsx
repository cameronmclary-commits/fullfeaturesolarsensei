"use client";

import { useRef, useState } from "react";
import { PageProps } from "@/components/solar/types";
import { usePageChrome } from "@/components/solar/usePageChrome";
import { ThemeToggle } from "@/components/solar/ThemeToggle";
import { HeroImage } from "@/components/solar/GuideImage";

/* ---------- JSON-LD: guides collection structured data ---------- */
const HUB_JSONLD = {
  "@context": "https://schema.org",
  "@type": "CollectionPage",
  name: "Solar & Battery Guides",
  url: "https://www.solarsensei.com.au/guides/",
  description:
    "Practical guides for Australian homeowners on electricity bills, time-of-use tariffs, battery storage and solar decisions.",
  publisher: { "@type": "Organization", name: "Solar Sensei" },
  mainEntity: {
    "@type": "ItemList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        url: "https://www.solarsensei.com.au/how-to-read-electricity-bill-solar-analysis",
        name: "How to Read Your Electricity Bill for Solar and Battery Analysis",
      },
      {
        "@type": "ListItem",
        position: 2,
        url: "https://www.solarsensei.com.au/when-does-solar-battery-make-financial-sense",
        name: "Battery Storage: When Does It Make Financial Sense?",
      },
      {
        "@type": "ListItem",
        position: 3,
        url: "https://www.solarsensei.com.au/time-of-use-tariffs-solar-battery-guide",
        name: "Understanding Time-of-Use Tariffs and Solar",
      },
      {
        "@type": "ListItem",
        position: 4,
        url: "https://www.solarsensei.com.au/before-you-get-solar-quotes",
        name: "Before You Get Solar Quotes, Find the Right Solar and Battery Setup",
      },
      {
        "@type": "ListItem",
        position: 5,
        url: "https://www.solarsensei.com.au/solar-quotes-queensland-quality-install",
        name: "Getting Quotes for Solar in Queensland: Ensuring a Quality Install",
      },
    ],
  },
};

/* ---------- category filter chips ---------- */
const FILTERS: { key: string; label: string }[] = [
  { key: "all", label: "All topics" },
  { key: "bill", label: "Your bill" },
  { key: "tariff", label: "Tariffs" },
  { key: "battery", label: "Battery" },
  { key: "quotes", label: "Quotes & installers" },
  { key: "solar", label: "Solar basics" },
];

export default function HubPage({ onNavigate }: PageProps) {
  const rootRef = useRef<HTMLElement>(null);
  usePageChrome(rootRef);
  const year = new Date().getFullYear();
  const [filter, setFilter] = useState<string>("all");

  const cardDisplay = (cat: string): undefined | "none" =>
    filter === "all" || cat === filter ? undefined : "none";

  return (
    <div className="page" id="page-hub" ref={rootRef}>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(HUB_JSONLD) }}
      />

      <header>
        <div className="wrap nav">
          <a
            className="logo"
            href="#"
            onClick={(e) => {
              e.preventDefault();
              onNavigate("home");
            }}
          >
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </a>
          <nav className="nav-links">
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("home");
              }}
            >
              Home
            </a>
            <a href="#hub-grid">All guides</a>
            <a href="#hub-start">Where to start</a>
            <a href="#hub-cta">Free analysis</a>
          </nav>
          <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
            <a
              className="btn btn-teal btn-nav"
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("lp1", "#cta1");
              }}
            >
              Start free analysis
            </a>
            <ThemeToggle />
            <button className="burger" aria-label="Menu" data-burger>
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>
        <nav className="mobile-menu" data-mobile-menu>
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              onNavigate("home");
            }}
          >
            Home
          </a>
          <a href="#hub-grid">All guides</a>
          <a href="#hub-start">Where to start</a>
          <a href="#hub-cta" className="mm-primary">
            Start free analysis →
          </a>
        </nav>
      </header>

      <main id="top">
        {/* ---------- HERO ---------- */}
        <section className="dark hero-a" style={{ paddingBottom: "52px" }}>
          <div className="wrap">
            <nav className="crumb" aria-label="Breadcrumb">
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("home");
                }}
              >
                Home
              </a>
              <span>›</span>
              <b>Guides</b>
            </nav>
            <span className="pill pill-lime">✦ &nbsp;Guides &amp; resources</span>
            <h1>Solar &amp; battery guides, grounded in your data</h1>
            <p className="lede">
              Practical explainers for Australian homeowners on electricity bills,
              tariffs, batteries, quotes and installation quality — so you can
              analyse your options before you commit. New guides are added
              regularly.
            </p>
            <div className="meta-row">
              <span className="m-chip">📚 5 guides live · 3 more planned</span>
              <span className="m-chip">🇦🇺 Australian bills &amp; tariffs</span>
              <span className="m-chip">🗓️ Updated regularly</span>
            </div>
            <HeroImage
              src="/guides/hub.jpg"
              alt="Row of Australian houses with solar panels installed on their roofs"
              caption="Solar panels on Australian rooftops — strong generation potential across the country."
            />
          </div>
        </section>

        {/* ---------- WHERE TO START (3 steps) ---------- */}
        <section className="dark hub-band" id="hub-start">
          <div className="wrap">
            <div className="start">
              <a
                className="start-card"
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("a1");
                }}
              >
                <small>Start here · Step 1</small>
                <h3>Read your electricity bill</h3>
                <p>The six figures that shape every solar and battery decision.</p>
              </a>
              <a
                className="start-card"
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("a3");
                }}
              >
                <small>Then · Step 2</small>
                <h3>Understand your tariff</h3>
                <p>How peak, shoulder and off-peak windows drive solar value.</p>
              </a>
              <a
                className="start-card"
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("lp1", "#cta1");
                }}
              >
                <small>Finally · Step 3</small>
                <h3>Run the free analysis</h3>
                <p>Model hundreds of configurations against your actual usage.</p>
              </a>
            </div>
          </div>
        </section>

        {/* ---------- ALL GUIDES (filterable grid) ---------- */}
        <div className="wrap hub-body" id="hub-grid">
          <div className="hub-top">
            <h2>All guides</h2>
            <span style={{ fontSize: "13px", color: "var(--mut-2)" }}>
              Filter by topic ↓
            </span>
          </div>

          <div
            className="cat-chips"
            role="group"
            aria-label="Filter guides by topic"
          >
            {FILTERS.map((f) => (
              <button
                key={f.key}
                type="button"
                className={"ccat" + (filter === f.key ? " on" : "")}
                aria-pressed={filter === f.key}
                onClick={() => setFilter(f.key)}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* featured guide (always visible — outside the filter scope) */}
          <a
            className="featured"
            href="#"
            onClick={(e) => {
              e.preventDefault();
              onNavigate("pl");
            }}
          >
            <div className="feat-copy">
              <div>
                <span className="pill pill-lime" style={{ fontSize: "10px" }}>
                  Most comprehensive · Read before you quote
                </span>
              </div>
              <h3>
                Before you get solar quotes, find the right solar and battery
                setup
              </h3>
              <p>
                Three quotes can compare installers — they can&apos;t tell you
                whether your home needs more panels, a battery, both, or no
                upgrade at all. Work out the likely pathway first, then quote
                with a brief.
              </p>
              <div className="feat-meta">
                <span>📖 9 min read</span>
                <span>🏷️ Quotes &amp; strategy</span>
                <span>✓ The complete guide</span>
              </div>
            </div>
            <div className="feat-vis" aria-hidden="true">
              <span className="f-chip" style={{ top: "22px", left: "26px" }}>
                10 kWh… or 20?
              </span>
              <span className="f-chip" style={{ top: "64px", right: "30px" }}>
                3 quotes, 3 answers
              </span>
              <span className="f-chip" style={{ top: "110px", left: "48px" }}>
                Four pathways
              </span>
              <div className="spark">
                <i style={{ height: "40%", background: "#CFE8DA" }} />
                <i style={{ height: "62%", background: "#8FD6BC" }} />
                <i style={{ height: "84%", background: "#3ECFA8" }} />
                <i style={{ height: "100%", background: "#C9F24C" }} />
                <i style={{ height: "72%", background: "#8FD6BC" }} />
                <i style={{ height: "52%", background: "#CFE8DA" }} />
                <i style={{ height: "36%", background: "#E4EDE7" }} />
                <i style={{ height: "24%", background: "#CFE8DA" }} />
                <i style={{ height: "44%", background: "#FFD166" }} />
                <i style={{ height: "66%", background: "#FF8A66" }} />
              </div>
              <span
                style={{
                  fontSize: "10.5px",
                  color: "var(--mut-2)",
                  marginTop: "12px",
                }}
              >
                Illustrative pathway comparison
              </span>
            </div>
          </a>

          <div className="hub-grid">
            <a
              className="gcard"
              href="#"
              data-cat="bill"
              style={{ display: cardDisplay("bill") }}
              onClick={(e) => {
                e.preventDefault();
                onNavigate("a1");
              }}
            >
              <span
                className="pill pill-blue"
                style={{ fontSize: "9.5px", alignSelf: "flex-start" }}
              >
                Your bill
              </span>
              <h3>How to read your electricity bill for solar &amp; battery analysis</h3>
              <p>
                Tariffs, usage rates, feed-in tariffs and the three things your
                bill can&apos;t tell you.
              </p>
              <div className="gmeta">
                <span>📖 8 min · 18/08/26</span>
                <b>Read guide →</b>
              </div>
            </a>

            <a
              className="gcard"
              href="#"
              data-cat="battery"
              style={{ display: cardDisplay("battery") }}
              onClick={(e) => {
                e.preventDefault();
                onNavigate("a2");
              }}
            >
              <span
                className="pill pill-teal"
                style={{ fontSize: "9.5px", alignSelf: "flex-start" }}
              >
                Battery
              </span>
              <h3>Battery storage: when does it make financial sense?</h3>
              <p>
                Five green lights, five caution signs, and the eight questions to
                ask before spending $10k–$20k.
              </p>
              <div className="gmeta">
                <span>📖 7 min · 20/08/26</span>
                <b>Read guide →</b>
              </div>
            </a>

            <a
              className="gcard"
              href="#"
              data-cat="tariff"
              style={{ display: cardDisplay("tariff") }}
              onClick={(e) => {
                e.preventDefault();
                onNavigate("a3");
              }}
            >
              <span
                className="pill pill-orange"
                style={{ fontSize: "9.5px", alignSelf: "flex-start" }}
              >
                Tariffs
              </span>
              <h3>Understanding time-of-use tariffs and solar</h3>
              <p>
                Peak, shoulder, off-peak — how the clock on your tariff shapes
                solar value and battery economics.
              </p>
              <div className="gmeta">
                <span>📖 6 min · 22/08/26</span>
                <b>Read guide →</b>
              </div>
            </a>

            <a
              className="gcard"
              href="#"
              data-cat="quotes"
              style={{ display: cardDisplay("quotes") }}
              onClick={(e) => {
                e.preventDefault();
                onNavigate("pl");
              }}
            >
              <span
                className="pill pill-lime"
                style={{ fontSize: "9.5px", alignSelf: "flex-start" }}
              >
                Quotes · Start here
              </span>
              <h3>Before you get solar quotes, find the right setup</h3>
              <p>
                Why three quotes can&apos;t tell you what your household needs —
                and the four pathways to work out first.
              </p>
              <div className="gmeta">
                <span>📖 9 min · 25/08/26</span>
                <b>Read guide →</b>
              </div>
            </a>

            <a
              className="gcard"
              href="#"
              data-cat="quotes"
              style={{ display: cardDisplay("quotes") }}
              onClick={(e) => {
                e.preventDefault();
                onNavigate("qd");
              }}
            >
              <span
                className="pill pill-orange"
                style={{ fontSize: "9.5px", alignSelf: "flex-start" }}
              >
                Quotes · Queensland
              </span>
              <h3>Getting solar quotes in QLD: ensuring a quality install</h3>
              <p>
                No mandatory post-install inspection in Queensland — the
                questions to ask and the checks that matter.
              </p>
              <div className="gmeta">
                <span>📖 5 min · 28/08/26</span>
                <b>Read guide →</b>
              </div>
            </a>

            <div
              className="gcard soon"
              data-cat="solar"
              style={{ display: cardDisplay("solar") }}
            >
              <span className="soon-badge">Coming soon</span>
              <span
                className="pill pill-green"
                style={{ fontSize: "9.5px", alignSelf: "flex-start" }}
              >
                Solar basics
              </span>
              <h3>How much solar do I need in Brisbane?</h3>
              <p>Sizing systems to your consumption — not to a sales quota.</p>
              <div className="gmeta">
                <span>Planned</span>
              </div>
            </div>

            <div
              className="gcard soon"
              data-cat="battery"
              style={{ display: cardDisplay("battery") }}
            >
              <span className="soon-badge">Coming soon</span>
              <span
                className="pill pill-teal"
                style={{ fontSize: "9.5px", alignSelf: "flex-start" }}
              >
                Battery
              </span>
              <h3>Is a home battery worth it in Brisbane?</h3>
              <p>
                A Brisbane-specific look at battery economics, tariffs and
                payback.
              </p>
              <div className="gmeta">
                <span>Planned</span>
              </div>
            </div>

            <div
              className="gcard soon"
              data-cat="solar"
              style={{ display: cardDisplay("solar") }}
            >
              <span className="soon-badge">Coming soon</span>
              <span
                className="pill pill-green"
                style={{ fontSize: "9.5px", alignSelf: "flex-start" }}
              >
                Solar basics
              </span>
              <h3>Solar panels or battery storage: which comes first?</h3>
              <p>Sequencing your investment when budget is finite.</p>
              <div className="gmeta">
                <span>Planned</span>
              </div>
            </div>
          </div>

          {/* ---------- CTA ---------- */}
          <section className="cta-sec" id="hub-cta">
            <div className="cta-box">
              <span className="pill pill-lime">Free · No sign-up required</span>
              <h2>Read the guides — then run your own numbers.</h2>
              <p>
                Guides give you the concepts. The free Solar Sensei calculator
                applies them to your actual bill, tariff and usage — and ranks the
                options that may suit your home.
              </p>
              <a
                className="btn btn-teal"
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate("lp1", "#cta1");
                }}
              >
                Start your free analysis →
              </a>
              <div className="cta-trust">
                <span>🔒 No sign-up required</span>
                <span>📍 Australia-wide</span>
                <span>📋 Indicative modelling — not a quote</span>
              </div>
            </div>
          </section>
        </div>
      </main>

      {/* ---------- FOOTER (mini) ---------- */}
      <footer className="f-mini">
        <div className="wrap fmini">
          <div className="f-logo">
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </div>
          <nav>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("home");
              }}
            >
              Home
            </a>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("pl");
              }}
            >
              Before you quote
            </a>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("a1");
              }}
            >
              Your bill
            </a>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("a2");
              }}
            >
              Battery
            </a>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("qd");
              }}
            >
              QLD installs
            </a>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("lp1", "#cta1");
              }}
            >
              Calculator
            </a>
          </nav>
          <p>
            Independent analysis for Australian homeowners. Indicative modelling
            only — not a quote or financial advice. © {year} Solar Sensei.
          </p>
        </div>
      </footer>
    </div>
  );
}
