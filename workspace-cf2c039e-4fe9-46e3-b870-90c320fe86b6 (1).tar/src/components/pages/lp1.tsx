"use client";

import { useRef } from "react";
import { PageProps } from "@/components/solar/types";
import { usePageChrome } from "@/components/solar/usePageChrome";
import { ThemeToggle } from "@/components/solar/ThemeToggle";
import { FaqList } from "@/components/solar/Faq";
import { OptGroup } from "@/components/solar/OptGroup";

export default function Lp1Page({ onNavigate }: PageProps) {
  const rootRef = useRef<HTMLElement>(null);
  usePageChrome(rootRef);
  const year = new Date().getFullYear();

  return (
    <div className="page" id="page-lp1" ref={rootRef}>
      <header>
        <div className="wrap nav">
          <a
            className="logo"
            href="#"
            onClick={(e) => { e.preventDefault(); onNavigate("home"); }}
          >
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </a>
          <nav className="nav-links">
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("home"); }}>
              Home
            </a>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
              Guides
            </a>
            <a href="#driving1">Why it&apos;s different</a>
            <a href="#how1">How it works</a>
            <a href="#free1">What you get</a>
            <a href="#faq1">FAQ</a>
          </nav>
          <div className="nav-cta">
            <a
              className="btn btn-nav-ghost"
              href="#"
              onClick={(e) => { e.preventDefault(); onNavigate("home", "#results"); }}
            >
              See sample output
            </a>
            <a className="btn btn-teal btn-nav" href="#cta1">
              Start free analysis
            </a>
            <ThemeToggle />
            <button className="burger" aria-label="Menu" data-burger>
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>
        <nav className="mobile-menu" data-mobile-menu>
          <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("home"); }}>
            Home
          </a>
          <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>
            Guides
          </a>
          <a href="#driving1">Why it&apos;s different</a>
          <a href="#how1">How it works</a>
          <a href="#free1">What you get</a>
          <a href="#faq1">FAQ</a>
          <a href="#cta1" className="mm-primary">
            Start free analysis →
          </a>
        </nav>
      </header>

      <main>
        {/* ---------- HERO ---------- */}
        <section className="dark hero">
          <div className="wrap hero-grid">
            <div>
              <nav className="crumb" aria-label="Breadcrumb">
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("home"); }}>
                  Home
                </a>
                <span>›</span>
                <b>Free Solar &amp; Battery Calculator</b>
              </nav>
              <span className="pill pill-lime">✦ &nbsp;Free calculator · Australia</span>
              <h1 className="display">
                Is solar or battery
                <br />
                <span className="c-teal">storage worth it</span>{" "}
                <span className="c-orange">for your home?</span>
              </h1>
              <p className="lead">
                Get a clearer answer using your own energy data — not a generic
                system recommendation. The free Solar Sensei calculator compares
                hundreds of solar and battery combinations against your household
                consumption, electricity tariff and existing system. It also
                separates the result of changing your system from the potential
                benefit of changing electricity plans.
              </p>
              <div className="hero-actions">
                <a className="btn btn-teal" href="#cta1">
                  Start your free analysis
                </a>
                <a className="btn btn-ghost" href="#how1">
                  See how the calculator works
                </a>
              </div>
              <ul className="checks">
                <li>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Compares hundreds of solar and battery configurations against your actual profile.
                </li>
                <li>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Separates equipment benefits from electricity-plan benefits.
                </li>
                <li>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Free personalised PDF report — no sign-up required.
                </li>
              </ul>
              <p className="hero-fine">
                <b>Free to use</b> · No sign-up required · No obligation to proceed
              </p>
            </div>
            <div className="window" aria-hidden="true">
              <div className="window-bar">
                <i className="wdot-r" />
                <i className="wdot-y" />
                <i className="wdot-g" />
                <span className="window-title">Solar Sensei calculator — results preview</span>
              </div>
              <div className="window-body">
                <div className="bench">
                  <span className="pill pill-white" style={{ fontSize: "9.5px", padding: "7px 12px" }}>
                    Data-backed benchmark
                  </span>
                  <h3>Know what&apos;s creating the value before you compare quotes.</h3>
                  <p>
                    Every pathway is modelled against your current plan first — then
                    against plan-change scenarios.
                  </p>
                  <div className="mini-grid">
                    <div className="mini"><small>Solar-only</small><b>Modelled</b></div>
                    <div className="mini"><small>Battery-only</small><b>Modelled</b></div>
                    <div className="mini"><small>Combined</small><b>Ranked</b></div>
                    <div className="mini"><small>Plan change</small><b>Separated</b></div>
                  </div>
                  <div className="attrib">
                    <div>
                      <div className="att-top"><span>Solar + battery · current plan</span><b>$1,730/yr</b></div>
                      <div className="att-bar"><i style={{ width: "74%", background: "var(--teal)" }} /></div>
                    </div>
                    <div>
                      <div className="att-top"><span>Electricity-plan change</span><b>+ $610/yr</b></div>
                      <div className="att-bar"><i style={{ width: "26%", background: "var(--gold)" }} /></div>
                    </div>
                    <div className="att-total"><span>Combined modelled result</span><b>$2,340/yr est.</b></div>
                  </div>
                </div>
                <div className="panel">
                  <div className="panel-t">Pathway comparison (modelled example)</div>
                  <div className="meter-row">
                    <span>Stay as-is</span>
                    <span className="meter"><i style={{ width: "6%", background: "#C9CFC4" }} /></span>
                    <span>$0</span>
                  </div>
                  <div className="meter-row">
                    <span>Solar only · current plan</span>
                    <span className="meter"><i style={{ width: "48%", background: "var(--teal)" }} /></span>
                    <span>$1,120/yr</span>
                  </div>
                  <div className="meter-row">
                    <span>Battery only · current plan</span>
                    <span className="meter"><i style={{ width: "23%", background: "var(--coral)" }} /></span>
                    <span>$540/yr</span>
                  </div>
                  <div className="meter-row">
                    <span>Solar + battery · current plan</span>
                    <span className="meter"><i style={{ width: "74%", background: "var(--teal)" }} /></span>
                    <span>$1,730/yr</span>
                  </div>
                  <div className="meter-row">
                    <span>+ plan change</span>
                    <span className="meter"><i style={{ width: "100%", background: "linear-gradient(90deg,var(--teal),var(--lime))" }} /></span>
                    <span>$2,340/yr</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ---------- VALUE ATTRIBUTION ---------- */}
        <section className="light" id="driving1">
          <div className="wrap split">
            <div>
              <span className="pill pill-teal">Value attribution</span>
              <h2 className="h-serif">See what is really driving the result.</h2>
              <p className="lead">
                A solar or battery recommendation can look highly attractive when its
                projected savings combine several different changes at once. For
                example, a proposal may include:
              </p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: "9px", margin: "20px 0 22px" }}>
                <span className="chip"><span className="dot" style={{ background: "var(--teal)" }} />A new solar or battery system</span>
                <span className="chip"><span className="dot" style={{ background: "var(--gold)" }} />A change to your electricity plan</span>
                <span className="chip"><span className="dot" style={{ background: "var(--coral)" }} />A different feed-in tariff</span>
                <span className="chip"><span className="dot" style={{ background: "var(--purple)" }} />Different import rates or time-of-use charges</span>
                <span className="chip"><span className="dot" style={{ background: "var(--blue)" }} />Assumptions about how the system will operate</span>
              </div>
              <p className="lead">
                When these factors are combined into one figure, it can be difficult
                to know how much benefit comes from the equipment and how much comes
                from the electricity plan.{" "}
                <strong style={{ color: "var(--l-head)" }}>
                  Solar Sensei presents these pathways separately
                </strong>
                , so you can make a more informed decision.
              </p>
            </div>
            <div className="vs">
              <div className="vs-card">
                <div className="vs-tag">
                  <span>Typical single-figure proposal</span>
                  <span className="dot" style={{ background: "var(--coral)" }} />
                </div>
                <div className="vs-big">Projected saving: $2,340/yr*</div>
                <p className="vs-fine">
                  *System, plan change, feed-in tariff and operating assumptions —
                  combined into one number. Hard to verify, hard to compare.
                </p>
                <div className="vs-bar" style={{ marginTop: "14px" }}>
                  <i style={{ width: "100%", background: "linear-gradient(90deg,var(--coral),var(--purple),var(--blue),var(--red))" }} />
                </div>
              </div>
              <div className="vs-card sensei">
                <div className="vs-tag">
                  <span style={{ color: "var(--teal-deep)" }}>Solar Sensei</span>
                  <span className="dot" style={{ background: "var(--teal)" }} />
                </div>
                <div className="vs-bars">
                  <div className="vs-bar-row">
                    <div className="t"><span>Equipment (solar + battery)</span><b>$1,730/yr</b></div>
                    <div className="vs-bar"><i style={{ width: "74%", background: "var(--teal)" }} /></div>
                  </div>
                  <div className="vs-bar-row">
                    <div className="t"><span>Electricity-plan change</span><b>$610/yr</b></div>
                    <div className="vs-bar"><i style={{ width: "26%", background: "var(--gold)" }} /></div>
                  </div>
                  <div className="vs-sum"><span>Each contribution shown separately</span><b>Modelled, indicative</b></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ---------- BASELINE (STEP ONE) ---------- */}
        <section className="light tint" id="baseline1">
          <div className="wrap split">
            <div className="base-card">
              <h3>Compared on your current plan</h3>
              <div className="base-row first">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Your current bill, no new system
                <span className="bb">Baseline</span>
              </div>
              <div className="base-row">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Solar options on your current plan
              </div>
              <div className="base-row">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Battery options on your current plan
              </div>
              <div className="base-row">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Solar and battery combinations on your current plan
              </div>
              <div className="base-row">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Expansion options for an existing system
              </div>
            </div>
            <div>
              <span className="pill pill-blue">Step one — baseline</span>
              <h2 className="h-serif">Analyse your current plan first.</h2>
              <p className="lead">
                The calculator assesses how potential solar and battery solutions
                perform against your{" "}
                <strong style={{ color: "var(--l-head)" }}>current electricity plan</strong>.
                This shows what the equipment may achieve without assuming that you
                first change retailers or tariffs.
              </p>
              <p className="lead">
                This provides a clearer baseline for assessing whether the proposed
                system itself makes sense.
              </p>
            </div>
          </div>
        </section>

        {/* ---------- PLAN CHANGE (STEP TWO) ---------- */}
        <section className="dark" id="plans1" style={{ padding: "100px 0", background: "var(--wash-mint)" }}>
          <div className="wrap">
            <div className="split" style={{ marginBottom: "20px" }}>
              <div>
                <span className="pill pill-lime">Step two — plan change</span>
                <h2 className="h-serif">Then consider a plan change.</h2>
                <p className="lead">
                  The calculator can also model the potential outcome if you move to
                  a different electricity plan in combination with the system. This
                  helps identify whether the improvement comes from:
                </p>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "9px", margin: "20px 0 22px" }}>
                  <span className="chip"><span className="dot" style={{ background: "var(--teal)" }} />The solar system</span>
                  <span className="chip"><span className="dot" style={{ background: "var(--gold)" }} />The battery system</span>
                  <span className="chip"><span className="dot" style={{ background: "var(--coral)" }} />The electricity plan</span>
                  <span className="chip"><span className="dot" style={{ background: "var(--purple)" }} />The combination of system + plan</span>
                </div>
              </div>
              <div>
                <p className="lead">
                  You can therefore see whether changing plans is{" "}
                  <strong style={{ color: "var(--band-ink)" }}>
                    necessary to achieve the projected result
                  </strong>{" "}
                  — or whether the equipment remains worthwhile on your current plan.
                </p>
                <p className="lead" style={{ marginTop: "16px" }}>
                  Electricity plans can differ in usage rates, supply charges,
                  feed-in tariffs and time-of-use structures, all of which can affect
                  the financial outcome of solar and battery storage.
                </p>
              </div>
            </div>
            <h3 style={{ fontFamily: "'Fraunces',serif", fontWeight: 600, fontSize: "clamp(1.5rem,2.6vw,2rem)", letterSpacing: "-.015em", margin: "44px 0 6px" }}>
              A clearer view of each decision.
            </h3>
            <p style={{ color: "var(--band-mut)", fontSize: "15.5px", maxWidth: "64ch", marginBottom: "4px" }}>
              Your analysis is designed to show more than one headline savings figure
              — so the value of a new system and the value of a plan change are never
              presented as though they were the same benefit.
            </p>
            <div className="view-cards">
              <div className="view-card">
                <small>Pathway 1</small>
                <h3>Current plan</h3>
                <p>How does each solar or battery solution perform if you remain on your existing electricity plan?</p>
              </div>
              <div className="view-card v2">
                <small>Pathway 2</small>
                <h3>New plan</h3>
                <p>How does the result change if you move to another plan or tariff?</p>
              </div>
              <div className="view-card v3">
                <small>Pathway 3</small>
                <h3>Combined outcome</h3>
                <p>What is the potential result when the system and electricity-plan change are considered together?</p>
              </div>
            </div>
          </div>
        </section>

        {/* ---------- YOUR DATA, YOUR CHOICE ---------- */}
        <section className="light" id="data1">
          <div className="wrap">
            <div className="sec-head">
              <span className="pill pill-teal">Your data, your choice</span>
              <h2 className="h-serif">Make the decision with your own data.</h2>
              <p className="lead">
                Choose the information you have available. Every pathway leads to
                the same ranked analysis.
              </p>
            </div>
            <div className="steps">
              <div className="step-card">
                <div className="icon-bub" style={{ background: "#E2F5F1", color: "#0B7C72" }}>
                  <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                    <path d="M12 16V4" />
                    <path d="M7 9l5-5 5 5" />
                    <path d="M4 16v3a2 2 0 002 2h12a2 2 0 002-2v-3" />
                  </svg>
                </div>
                <h3>Upload your electricity bill</h3>
                <p>
                  Upload a PDF or image of your bill. The calculator uses the
                  information to identify relevant consumption, tariff and charge
                  details.
                </p>
                <p style={{ marginTop: "12px", fontSize: "12px", fontWeight: 700, letterSpacing: ".1em", textTransform: "uppercase", color: "var(--teal-deep)" }}>
                  Most specific
                </p>
              </div>
              <div className="step-card">
                <div className="icon-bub" style={{ background: "#F2F9D3", color: "#55731A" }}>
                  <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                    <path d="M3 12h4l3-8 4 16 3-8h4" />
                  </svg>
                </div>
                <h3>Authorise interval data</h3>
                <p>
                  If interval data is available, authorise access for a more
                  detailed analysis of when your home uses and exports energy.
                </p>
                <p style={{ marginTop: "12px", fontSize: "12px", fontWeight: 700, letterSpacing: ".1em", textTransform: "uppercase", color: "#55731A" }}>
                  Most detailed
                </p>
              </div>
              <div className="step-card">
                <div className="icon-bub" style={{ background: "#EFE9FB", color: "#6B46C1" }}>
                  <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                    <path d="M4 6h16M4 12h16M4 18h10" />
                  </svg>
                </div>
                <h3>Enter your figures manually</h3>
                <p>
                  You can still begin the analysis without a bill or interval data
                  by entering your consumption and tariff figures yourself.
                </p>
                <p style={{ marginTop: "12px", fontSize: "12px", fontWeight: 700, letterSpacing: ".1em", textTransform: "uppercase", color: "#6B46C1" }}>
                  No bill needed
                </p>
              </div>
            </div>
            <p style={{ textAlign: "center", fontSize: "13.5px", color: "var(--l-mut)", marginTop: "26px" }}>
              Using detailed usage data can provide a more realistic view of how
              solar and battery storage may affect grid imports and household energy
              costs.
            </p>
          </div>
        </section>

        {/* ---------- HOW IT WORKS (SIX STEPS) ---------- */}
        <section className="light tint" id="how1">
          <div className="wrap">
            <div className="sec-head">
              <span className="pill pill-blue">How the calculator works</span>
              <h2 className="h-serif">Six steps from bill to ranked report.</h2>
            </div>
            <div className="steps">
              <div className="step-card">
                <div className="step-num">1</div>
                <h3>Provide your energy information</h3>
                <p>Upload your bill, authorise interval data or enter your consumption figures manually.</p>
              </div>
              <div className="step-card">
                <div className="step-num">2</div>
                <h3>Build your household profile</h3>
                <p>The calculator models your consumption, tariff structure, existing solar or battery system and interaction with the grid.</p>
              </div>
              <div className="step-card">
                <div className="step-num">3</div>
                <h3>Test hundreds of combinations</h3>
                <p>Different solar capacities, battery sizes and system configurations are analysed against your household circumstances.</p>
              </div>
              <div className="step-card">
                <div className="step-num">4</div>
                <h3>Compare current-plan and upgrade pathways</h3>
                <p>Results are assessed first against your current electricity plan, then against relevant plan-change scenarios.</p>
              </div>
              <div className="step-card">
                <div className="step-num">5</div>
                <h3>Review your ranked options</h3>
                <p>Solutions can be ranked according to factors such as estimated savings, return on investment, payback period or potential energy independence.</p>
              </div>
              <div className="step-card">
                <div className="step-num">6</div>
                <h3>Download your PDF report</h3>
                <p>Generate a personalised report that you can keep, review and use when discussing options with installers or consultants.</p>
              </div>
            </div>
          </div>
        </section>

        {/* ---------- ASSESSMENT CRITERIA ---------- */}
        <section className="light" id="outcomes1">
          <div className="wrap">
            <div className="sec-head">
              <span className="pill pill-green">Assessment criteria</span>
              <h2 className="h-serif">Compare the outcomes that matter.</h2>
              <p className="lead">
                Solar Sensei can help you assess solutions from different
                perspectives, including:
              </p>
            </div>
            <div className="cloud">
              <span className="chip"><span className="dot" style={{ background: "var(--teal)" }} />Estimated reduction in electricity costs</span>
              <span className="chip"><span className="dot" style={{ background: "var(--gold)" }} />Return on investment</span>
              <span className="chip"><span className="dot" style={{ background: "var(--coral)" }} />Estimated payback period</span>
              <span className="chip"><span className="dot" style={{ background: "var(--purple)" }} />Reduction in grid imports</span>
              <span className="chip"><span className="dot" style={{ background: "var(--blue)" }} />Potential energy independence</span>
              <span className="chip"><span className="dot" style={{ background: "var(--red)" }} />Solar self-consumption</span>
              <span className="chip"><span className="dot" style={{ background: "var(--teal)" }} />Battery utilisation</span>
              <span className="chip"><span className="dot" style={{ background: "var(--gold)" }} />Exported energy &amp; feed-in revenue</span>
              <span className="chip"><span className="dot" style={{ background: "var(--coral)" }} />The effect of your current electricity plan</span>
              <span className="chip"><span className="dot" style={{ background: "var(--purple)" }} />The potential effect of changing plans</span>
              <span className="chip"><span className="dot" style={{ background: "var(--blue)" }} />Future system expansion</span>
            </div>
            <p className="cloud-callout">
              The best option is not necessarily the largest system or the one with
              the highest advertised savings. It is the configuration that is{" "}
              <b>appropriately matched to your consumption, tariff, priorities and future plans</b>.
            </p>
          </div>
        </section>

        {/* ---------- WHY GENERIC CAN MISLEAD ---------- */}
        <section className="light tint" id="why1">
          <div className="wrap split" style={{ alignItems: "start" }}>
            <div>
              <span className="pill pill-teal">A word of caution</span>
              <h2 className="h-serif">Why generic recommendations can be misleading.</h2>
              <p className="lead">
                A standard recommendation may be based on limited information about
                your home. It may also combine equipment savings, tariff changes and
                optimistic operating assumptions into one projected result.
              </p>
              <p className="lead">That makes it difficult to answer basic questions:</p>
            </div>
            <div>
              <div className="q-grid">
                <div className="q-item"><span className="qn">Q1</span>Would the system still make sense on your current plan?</div>
                <div className="q-item"><span className="qn">Q2</span>Is changing plans more valuable than installing additional equipment?</div>
                <div className="q-item"><span className="qn">Q3</span>How much of the projected saving comes from the battery?</div>
                <div className="q-item"><span className="qn">Q4</span>Would a smaller system provide a stronger return?</div>
                <div className="q-item"><span className="qn">Q5</span>Is the recommendation designed around your consumption or a standard package?</div>
              </div>
              <p className="q-close">
                <b>Solar Sensei is designed to make these distinctions visible</b>{" "}
                before you rely on a sales proposal.
              </p>
            </div>
          </div>
        </section>

        {/* ---------- WHO IT'S FOR ---------- */}
        <section className="dark" id="situations1" style={{ padding: "100px 0", background: "var(--wash-lav)" }}>
          <div className="wrap">
            <div className="sec-head">
              <span className="pill pill-lime">Who it&apos;s for</span>
              <h2 className="h-serif">Designed for your situation.</h2>
              <p className="lead">The calculator can help if you are:</p>
            </div>
            <ul className="sit-grid" style={{ margin: "0 auto" }}>
              <li>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Considering solar for the first time
              </li>
              <li>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Deciding whether a battery is worthwhile
              </li>
              <li>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Comparing solar-only with solar-and-battery options
              </li>
              <li>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Expanding an existing solar system
              </li>
              <li>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Assessing whether your current plan remains suitable
              </li>
              <li>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Considering a different electricity retailer or tariff
              </li>
              <li>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Reviewing a system recommended by an installer
              </li>
              <li>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Trying to improve savings or reduce grid dependence
              </li>
            </ul>
          </div>
        </section>

        {/* ---------- START WITH ANALYSIS ---------- */}
        <section className="light" id="free1">
          <div className="wrap">
            <div className="sec-head">
              <span className="pill pill-teal">Analysis first</span>
              <h2 className="h-serif">Start with analysis, not a sales pitch.</h2>
            </div>
            <div className="offer">
              <div className="offer-card feature">
                <span className="pill pill-teal" style={{ fontSize: "10px" }}>Free · No obligation</span>
                <h3>Your free analysis</h3>
                <p>
                  Solar Sensei provides the initial analysis at no cost. You are not
                  required to request a quote, choose an installer or purchase a
                  particular product.
                </p>
                <ul className="checks">
                  <li>
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                      <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    Hundreds of configurations modelled
                  </li>
                  <li>
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                      <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    Current-plan vs plan-change pathways separated
                  </li>
                  <li>
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                      <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    Ranked options and a personalised PDF report
                  </li>
                </ul>
              </div>
              <div className="offer-card">
                <span className="pill pill-blue" style={{ fontSize: "10px" }}>When you&apos;re ready</span>
                <h3>From analysis to installation</h3>
                <p>
                  Happy with your results? Take your ranked report anywhere — or
                  let Solar Sensei arrange the install. We work with a small vetted
                  installer network in each area, chosen for reputation, track record
                  and business stability, and every install includes a free
                  independent inspection at no extra cost. Along the way, guidance
                  can help you explore:
                </p>
                <ul className="checks">
                  <li>
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                      <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    The differences between your ranked options
                  </li>
                  <li>
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                      <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    System and battery sizing
                  </li>
                  <li>
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                      <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    Battery quality, warranty and expansion capability
                  </li>
                  <li>
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                      <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    Electricity-plan considerations and future energy requirements
                  </li>
                  <li>
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                      <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    Installer selection and installation quality
                  </li>
                </ul>
                <p className="offer-note">
                  The choice stays yours. Many homeowners simply take their report
                  into the quote process; if you proceed with Solar Sensei, vetting
                  and an independent inspection are included at no extra cost.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ---------- LIMITATIONS ---------- */}
        <section className="limits">
          <div className="wrap">
            <div className="limits-box">
              <h3>Important limitations</h3>
              <ul>
                <li>
                  Solar Sensei provides independent analysis; installs are arranged
                  via a vetted third-party network — Solar Sensei is not an installer
                  and does not provide financial advice.
                </li>
                <li>
                  Results are indicative modelled estimates based on the information
                  you provide — not guaranteed savings.
                </li>
                <li>
                  The analysis is not an installation quote, financial guarantee or
                  electrical design.
                </li>
                <li>
                  Tariffs, plans and prices can change over time, which may affect
                  modelled outcomes.
                </li>
                <li>
                  Consult a suitably qualified installer or electrician before any
                  purchase decision.
                </li>
                <li>
                  Analysis is available Australia-wide; installation availability
                  varies by state.
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* ---------- FAQ ---------- */}
        <section className="light" id="faq1" style={{ paddingTop: "60px" }}>
          <div className="wrap">
            <div className="sec-head">
              <span className="pill pill-teal">FAQ</span>
              <h2 className="h-serif">Calculator questions, answered.</h2>
            </div>
            <FaqList
              items={[
                {
                  q: "Is the calculator free?",
                  a: "Yes. The core Solar Sensei calculator is available at no cost, and you can generate a personalised PDF report from your analysis.",
                },
                {
                  q: "Do I need to change electricity plans?",
                  a: "No. The calculator first assesses potential solutions against your current plan. It can then show the possible effect of changing plans separately.",
                },
                {
                  q: "Why does the calculator analyse electricity plans?",
                  a: "Usage rates, supply charges, feed-in tariffs and time-of-use pricing can affect the performance of solar and batteries. Separating the current-plan and new-plan outcomes helps show what is actually contributing to the result.",
                },
                {
                  q: "Do I need interval data?",
                  a: "No. You can upload a bill or enter your consumption figures manually. Interval data may provide a more detailed view of your usage patterns where it is available.",
                },
                {
                  q: "Can I analyse an existing solar system?",
                  a: "Yes. Existing solar or battery equipment can be included when assessing expansion or additional storage options.",
                },
                {
                  q: "Does Solar Sensei sell a particular battery?",
                  a: "The analysis is designed to help you understand suitable system and battery characteristics before considering specific brands or installers. Consultant support is available if you want to explore those choices further.",
                },
                {
                  q: "Does completing the analysis commit me to an installer?",
                  a: "No. The calculator is intended to give you information before you decide whether to seek quotes, change plans or proceed with an installation.",
                },
                {
                  q: "What does the PDF report contain?",
                  a: "The report summarises your household energy profile and presents ranked system options, including the distinction between outcomes on your current plan and outcomes involving a potential plan change.",
                },
              ]}
            />
          </div>
        </section>

        {/* ---------- CTA ---------- */}
        <section className="cta" id="cta1">
          <div className="wrap cta-grid">
            <div>
              <span className="pill pill-lime">Start your free analysis</span>
              <h2 className="h-serif">Know what is creating the value.</h2>
              <p className="lead">
                Find out how solar, battery storage and electricity-plan changes may
                perform for your home — and see the contribution of each decision
                separately.
              </p>
              <ul className="checks">
                <li>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Upload a bill, authorise interval data, or enter figures manually.
                </li>
                <li>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Compare solutions on your current plan, then with a plan change.
                </li>
                <li>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  Download a personalised PDF report for quote conversations.
                </li>
              </ul>
              <div className="trust-row">
                <span>🔒 Free to use</span>
                <span>✅ No obligation to proceed</span>
                <span>📍 Australia-wide</span>
              </div>
            </div>
            <div className="form-card">
              <div className="form-head">
                <h3>Start your free analysis</h3>
                <span className="tag" style={{ background: "#F2F9D3", color: "#55731A", borderColor: "#DDEBB0" }}>
                  Free · No sign-up
                </span>
              </div>
              <p>
                Choose how you&apos;d like to provide your energy information. You
                can change approach later.
              </p>
              <OptGroup
                opts={[
                  {
                    title: "Upload my electricity bill",
                    desc: "PDF or image — the fastest path to a specific analysis.",
                    defaultSelected: true,
                  },
                  {
                    title: "Authorise interval data",
                    desc: "Where available — the most detailed view of usage timing.",
                  },
                  {
                    title: "Enter my figures manually",
                    desc: "Start without a bill. Results may be less specific.",
                  },
                ]}
              />
              <button className="btn btn-teal btn-block">Continue to my analysis →</button>
              <p className="form-fine">
                Next, you&apos;ll be guided through providing your bill, data
                authorisation or manual figures. Results are modelled and
                indicative.
              </p>
              <div className="form-chips">
                <div>Secure start</div>
                <div>Customer-controlled</div>
                <div>Quote-ready output</div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* ---------- FOOTER (mini) ---------- */}
      <footer className="f-mini">
        <div className="wrap fmini">
          <div className="f-logo">
            <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
              <use href="#mark-lantern" />
            </svg>
            <span className="wm-text">
              Solar <b>Sensei</b>
            </span>
          </div>
          <nav>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("home"); }}>Home</a>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("hub"); }}>All guides</a>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("pl"); }}>Before you quote</a>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("qd"); }}>QLD installs</a>
          </nav>
          <p>
            Independent analysis for Australian homeowners. Indicative modelling
            only — not a quote or financial advice. © {year} Solar Sensei.
          </p>
        </div>
      </footer>

      {/* ---------- STICKY CTA ---------- */}
      <div className="stickybar">
        <p>Informed choice starts here.</p>
        <a className="btn btn-teal" href="#cta1">Start analysis</a>
      </div>
    </div>
  );
}
