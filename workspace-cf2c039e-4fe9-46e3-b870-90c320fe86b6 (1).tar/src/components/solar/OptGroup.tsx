"use client";

import { useState, type ReactNode } from "react";

export interface Opt {
  title: string;
  desc: string;
  /** mark as the default-selected option */
  defaultSelected?: boolean;
}

/**
 * Selectable option cards matching `.opts` / `.opt` markup.
 * `columns` controls the home (2-col grid) vs lp1 (stacked) layout.
 */
export function OptGroup({
  opts,
  columns = 2,
}: {
  opts: Opt[];
  columns?: 1 | 2;
}) {
  const initial = opts.findIndex((o) => o.defaultSelected);
  const [sel, setSel] = useState(initial >= 0 ? initial : 0);
  return (
    <div className="opts">
      {opts.map((o, i) => (
        <div
          key={i}
          className={`opt${sel === i ? " sel" : ""}`}
          onClick={() => setSel(i)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              setSel(i);
            }
          }}
        >
          <b>{o.title}</b>
          <p>{o.desc}</p>
        </div>
      ))}
      {/* keep grid template consistent; columns prop not strictly needed because
          CSS handles responsive columns, but exposed for future use */}
      {columns === 1 ? null : null}
    </div>
  );
}

/**
 * Generic check-mark icon used throughout the site.
 */
export function Check({ size = 18, className }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
    >
      <path
        d="M5 13l4 4L19 7"
        stroke="currentColor"
        strokeWidth="2.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
