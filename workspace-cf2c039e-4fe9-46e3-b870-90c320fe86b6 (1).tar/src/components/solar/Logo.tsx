"use client";

import { PageName } from "./types";

interface LogoProps {
  /** Anchor href (e.g. "#top"). */
  href?: string;
  /** When set, clicking navigates to a page. */
  goto?: PageName;
  onNavigate?: (page: PageName) => void;
  className?: string;
}

/**
 * Solar Sensei logo: lantern mark + "Solar Sensei" wordmark.
 * The `mark-lantern` symbol is defined once in layout.tsx.
 */
export function Logo({ href = "#top", goto, onNavigate, className = "logo" }: LogoProps) {
  const handleClick = (e: React.MouseEvent) => {
    if (goto && onNavigate) {
      e.preventDefault();
      onNavigate(goto);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };
  return (
    <a className={className} href={href} onClick={handleClick}>
      <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
        <use href="#mark-lantern" />
      </svg>
      <span className="wm-text">
        Solar <b>Sensei</b>
      </span>
    </a>
  );
}

/** Footer logo (no link wrapper, used inside footer brand block) */
export function FooterLogo({
  className = "f-logo",
}: {
  className?: string;
}) {
  return (
    <div className={className}>
      <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
        <use href="#mark-lantern" />
      </svg>
      <span className="wm-text">
        Solar <b>Sensei</b>
      </span>
    </div>
  );
}
