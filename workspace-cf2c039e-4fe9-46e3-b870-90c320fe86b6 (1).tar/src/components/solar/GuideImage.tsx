"use client";

/**
 * Hero banner image for guide/article pages.
 * Renders a rounded, full-width image with an italic caption, styled by
 * the `.hero-banner` class in globals.css.
 */
export function HeroImage({
  src,
  alt,
  caption,
}: {
  src: string;
  alt: string;
  caption?: string;
}) {
  return (
    <figure className="hero-banner">
      <img src={src} alt={alt} loading="eager" />
      {caption ? <figcaption>{caption}</figcaption> : null}
    </figure>
  );
}

/**
 * Smaller inline figure for embedding inside article prose.
 * Styled by the `.inset-img` class.
 */
export function InsetImage({
  src,
  alt,
  caption,
}: {
  src: string;
  alt: string;
  caption?: string;
}) {
  return (
    <figure className="inset-img">
      <img src={src} alt={alt} loading="lazy" />
      {caption ? <figcaption>{caption}</figcaption> : null}
    </figure>
  );
}
