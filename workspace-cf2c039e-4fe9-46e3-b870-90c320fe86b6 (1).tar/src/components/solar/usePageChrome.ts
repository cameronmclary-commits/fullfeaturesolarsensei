"use client";

import { useEffect, type RefObject } from "react";

/**
 * Per-page chrome interactions:
 *  - toggles `scrolled` on the page `<header>` (scrollY > 8)
 *  - toggles `show` on the page `.stickybar` (scrollY > 640)
 *  - highlights the active `.toc a` based on which `<article h2[id]>` is in view
 *  - burger menu open/close (`[data-burger]` toggles `[data-mobile-menu]`)
 *
 * Pass a ref to the page root element.
 */
export function usePageChrome(rootRef: RefObject<HTMLElement | null>) {
  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;

    const header = root.querySelector("header");
    const sticky = root.querySelector(".stickybar");
    const tocLinks = Array.from(
      root.querySelectorAll<HTMLAnchorElement>(".toc a[href^='#']")
    );
    const headings = Array.from(
      root.querySelectorAll<HTMLElement>("article h2[id]")
    );

    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        ticking = false;
        const y = window.scrollY;
        if (header) header.classList.toggle("scrolled", y > 8);
        if (sticky) sticky.classList.toggle("show", y > 640);

        if (tocLinks.length && headings.length) {
          let current: string | null = null;
          for (const h of headings) {
            if (h.getBoundingClientRect().top < 180) current = h.id;
          }
          for (const l of tocLinks) {
            l.classList.toggle("on", l.getAttribute("href") === "#" + current);
          }
        }
      });
    };

    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    // burger menu toggle
    const burger = root.querySelector<HTMLElement>("[data-burger]");
    const menu = root.querySelector<HTMLElement>("[data-mobile-menu]");
    let cleanupBurger: (() => void) | undefined;
    if (burger && menu) {
      const toggle = () => menu.classList.toggle("open");
      burger.addEventListener("click", toggle);
      const close = () => menu.classList.remove("open");
      menu.querySelectorAll("a").forEach((a) =>
        a.addEventListener("click", close)
      );
      cleanupBurger = () => {
        burger.removeEventListener("click", toggle);
        menu.querySelectorAll("a").forEach((a) =>
          a.removeEventListener("click", close)
        );
      };
    }

    return () => {
      window.removeEventListener("scroll", onScroll);
      cleanupBurger?.();
    };
  }, [rootRef]);
}

/**
 * Global reading-progress bar (fixed top). Updates width based on scroll.
 * The `.progress` element should live outside individual pages (in page.tsx).
 */
export function useProgressBar() {
  useEffect(() => {
    const bar = document.getElementById("progress");
    if (!bar) return;
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        ticking = false;
        const max =
          document.documentElement.scrollHeight - window.innerHeight;
        bar.style.width = (max > 0 ? (window.scrollY / max) * 100 : 0) + "%";
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
}
