export type PageName =
  | "home"
  | "lp1"
  | "hub"
  | "a1"
  | "a2"
  | "a3"
  | "pl"
  | "qd";

export interface PageProps {
  onNavigate: (page: PageName, target?: string) => void;
}

export interface NavItem {
  label: string;
  /** anchor target within current page, e.g. "#how" */
  href?: string;
  /** navigate to another page */
  goto?: PageName;
  /** optional anchor target on the destination page */
  target?: string;
  className?: string;
}

export const PAGE_TITLES: Record<PageName, string> = {
  home: "Solar and Battery Analysis Australia | Solar Sensei",
  lp1: "Is Solar or Battery Storage Worth It? Free Calculator | Solar Sensei",
  hub: "Solar & Battery Guides — Bills, Tariffs & Batteries Explained | Solar Sensei",
  a1: "How to Read Your Electricity Bill for Solar Analysis | Solar Sensei",
  a2: "When Does Solar Battery Storage Make Financial Sense? | Solar Sensei",
  a3: "Time-of-Use Tariffs and Solar: What Homeowners Need to Know | Solar Sensei",
  pl: "Before You Get Solar Quotes: Find the Right Setup | Solar Sensei",
  qd: "Solar Quotes Queensland: Ensuring a Quality Install | Solar Sensei",
};

export const PAGE_TABS: { key: PageName; label: string }[] = [
  { key: "home", label: "Home" },
  { key: "lp1", label: "Calculator" },
  { key: "hub", label: "Guides" },
  { key: "a1", label: "Bill" },
  { key: "a2", label: "Battery" },
  { key: "a3", label: "Tariffs" },
  { key: "pl", label: "Quotes pillar" },
  { key: "qd", label: "QLD install" },
];
