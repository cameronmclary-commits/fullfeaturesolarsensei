"use client";

import { useState, useRef, useEffect, type ReactNode } from "react";

/**
 * Animated FAQ item matching `.faq-item` / `.faq-q` / `.faq-a` markup.
 * Only one item open per list (matches original behaviour).
 */
export function FaqItem({
  question,
  children,
  open,
  onToggle,
}: {
  question: ReactNode;
  children: ReactNode;
  open: boolean;
  onToggle: () => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [maxH, setMaxH] = useState<string | undefined>(open ? undefined : "0px");

  useEffect(() => {
    if (!ref.current) return;
    if (open) {
      setMaxH(`${ref.current.scrollHeight}px`);
    } else {
      setMaxH("0px");
    }
  }, [open]);

  return (
    <div className={`faq-item${open ? " open" : ""}`}>
      <button
        type="button"
        className="faq-q"
        aria-expanded={open}
        onClick={onToggle}
      >
        {question}
        <span className="plus">+</span>
      </button>
      <div className="faq-a" ref={ref} style={{ maxHeight: maxH }}>
        <p>{children}</p>
      </div>
    </div>
  );
}

/**
 * Self-contained FAQ list with single-open accordion behaviour.
 * Pass an array of { q, a } items.
 */
export function FaqList({
  items,
}: {
  items: { q: ReactNode; a: ReactNode }[];
}) {
  const [openIdx, setOpenIdx] = useState<number | null>(null);
  return (
    <div className="faq-list">
      {items.map((it, i) => (
        <FaqItem
          key={i}
          question={it.q}
          open={openIdx === i}
          onToggle={() => setOpenIdx(openIdx === i ? null : i)}
        >
          {it.a}
        </FaqItem>
      ))}
    </div>
  );
}
