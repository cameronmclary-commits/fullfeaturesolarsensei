"use client";

import { ThemeProvider } from "next-themes";

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider
      attribute="data-theme"
      defaultTheme="light"
      enableSystem
      // keep the body's smooth background/color transition on theme switch
      disableTransitionOnChange={false}
    >
      {children}
    </ThemeProvider>
  );
}
