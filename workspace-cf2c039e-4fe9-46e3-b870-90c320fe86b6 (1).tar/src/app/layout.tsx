import type { Metadata } from "next";
import "./globals.css";
import { Providers } from "@/components/solar/providers";

export const metadata: Metadata = {
  title: "Solar and Battery Analysis Australia | Solar Sensei",
  description:
    "Solar Sensei analyses your electricity bill and models hundreds of solar and battery combinations against your household's actual energy profile — then ranks the options by potential savings, ROI and break-even.",
  robots: { index: false, follow: false },
  icons: {
    icon: [
      {
        type: "image/svg+xml",
        url:
          "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%23FBFCE8'/%3E%3Crect x='10' y='12' width='44' height='32' rx='5' fill='none' stroke='%23191919' stroke-width='5'/%3E%3Cpath d='M32 12v32M10 28h44' stroke='%23191919' stroke-width='4'/%3E%3Cpath d='M10 17 L19 12 L25 12 L10 24 Z' fill='%23C9F24C'/%3E%3Cpath d='M23 44v6M41 44v6' stroke='%23191919' stroke-width='4.5' stroke-linecap='round'/%3E%3Cpath d='M16 55h32' stroke='%23191919' stroke-width='5' stroke-linecap='round'/%3E%3C/svg%3E",
      },
    ],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en-AU" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Poppins:wght@600;700;800;900&family=Outfit:wght@700;800&family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        {/* Lantern logo symbol — referenced via <use href="#mark-lantern"/> */}
        <svg
          width="0"
          height="0"
          style={{ position: "absolute" }}
          aria-hidden="true"
          focusable="false"
        >
          <symbol id="mark-lantern" viewBox="0 0 64 64">
            <rect
              x="7"
              y="9"
              width="50"
              height="37"
              rx="6"
              fill="none"
              stroke="currentColor"
              strokeWidth="5.5"
            />
            <path
              d="M32 9v37M7 27.5h50"
              stroke="currentColor"
              strokeWidth="4.5"
            />
            <path d="M7 14.5 L18 9 L26 9 L7 26 Z" fill="var(--glint,#C9F24C)" />
            <path
              d="M22 46v7M42 46v7"
              stroke="currentColor"
              strokeWidth="5"
              strokeLinecap="round"
            />
            <path
              d="M14 57h36"
              stroke="currentColor"
              strokeWidth="5.5"
              strokeLinecap="round"
            />
          </symbol>
        </svg>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
