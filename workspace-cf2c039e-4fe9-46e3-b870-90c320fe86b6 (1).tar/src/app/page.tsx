"use client";

import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { PAGE_TABS, PAGE_TITLES, type PageName } from "@/components/solar/types";
import { useProgressBar } from "@/components/solar/usePageChrome";
import HomePage from "@/components/pages/home";
import Lp1Page from "@/components/pages/lp1";
import HubPage from "@/components/pages/hub";
import A1Page from "@/components/pages/a1";
import A2Page from "@/components/pages/a2";
import A3Page from "@/components/pages/a3";
import PlPage from "@/components/pages/pl";
import QdPage from "@/components/pages/qd";

const PAGE_COMPONENTS: Record<
  PageName,
  React.ComponentType<{ onNavigate: (page: PageName, target?: string) => void }>
> = {
  home: HomePage,
  lp1: Lp1Page,
  hub: HubPage,
  a1: A1Page,
  a2: A2Page,
  a3: A3Page,
  pl: PlPage,
  qd: QdPage,
};

export default function Home() {
  const [active, setActive] = useState<PageName>("home");
  const [pendingTarget, setPendingTarget] = useState<string | null>(null);
  // ref so the layout effect can read the latest pendingTarget without
  // re-triggering on every change (the effect must key off `active` only,
  // otherwise a target update would cause a second scroll-to-top flash).
  const pendingTargetRef = useRef<string | null>(null);
  useProgressBar();

  // update document title per active page
  useEffect(() => {
    document.title = PAGE_TITLES[active] ?? "Solar Sensei";
  }, [active]);

  const onNavigate = useCallback((page: PageName, target?: string) => {
    pendingTargetRef.current = target ?? null;
    setPendingTarget(target ?? null);
    setActive(page);
  }, []);

  // Reset scroll position synchronously AFTER the new page has rendered but
  // BEFORE the browser paints. This eliminates the "skip"/flash where the old
  // page (still in DOM during the state update) would visibly jump to top, and
  // guarantees every page switch starts cleanly at the top like a fresh page.
  useLayoutEffect(() => {
    window.scrollTo(0, 0);
    const target = pendingTargetRef.current;
    if (target) {
      const id = target.replace(/^#/, "");
      // defer the in-page smooth-scroll to the next frame so the page paints
      // at top first, then scrolls to the target section — no double-jump.
      const raf = requestAnimationFrame(() => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
        pendingTargetRef.current = null;
        setPendingTarget(null);
      });
      return () => cancelAnimationFrame(raf);
    }
  }, [active]);

  const ActivePage = PAGE_COMPONENTS[active];

  return (
    <>
      {/* fixed reading-progress bar */}
      <div className="progress" id="progress" />

      {/* page tab switcher (top utility strip) */}
      <nav className="topbar" aria-label="Pages">
        <span className="tb-label">Pages</span>
        {PAGE_TABS.map((t) => (
          <button
            key={t.key}
            className={`tb-tab${active === t.key ? " active" : ""}`}
            onClick={() => onNavigate(t.key)}
            role="tab"
            aria-selected={active === t.key}
          >
            {t.label}
          </button>
        ))}
      </nav>

      <ActivePage onNavigate={onNavigate} />
    </>
  );
}
