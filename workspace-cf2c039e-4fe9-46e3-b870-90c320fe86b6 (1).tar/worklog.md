# Solar Sensei — Build Worklog

Project: Converting the standalone HTML preview (`solar-preview.html`, v3.4, 8 tabs) into a
production Next.js 16 App Router site. Single user-visible route `/` with client-side tab switching.

Source preview: `/home/z/my-project/solar-preview.html` (2802 lines).
Extracted page slices live in `/tmp/page-*.txt`.

## Architecture
- `src/app/globals.css` — full Solar Sensei design system (CSS custom properties, light/dark via `html[data-theme]`). Tailwind import kept at top but design is driven by the custom CSS.
- `src/app/layout.tsx` — fonts (Poppins/Outfit/Fraunces/Inter via Google Fonts link), favicon, `mark-lantern` SVG symbol, `Providers` (next-themes `attribute="data-theme"`).
- `src/app/page.tsx` — client component: topbar page tabs, progress bar, active-page state, `onNavigate(page, target?)`, per-page `document.title`.
- `src/components/solar/*` — shared building blocks: `types`, `ThemeToggle`, `Logo`, `Faq`, `OptGroup`, `usePageChrome` hook.
- `src/components/pages/*` — one client component per page (home, lp1, hub, a1, a2, a3, pl, qd). Each renders its own `<header>`, `<main>`, `<footer>`, `<stickybar>` and receives `onNavigate`.

## Page contract (for all page subagents)
```ts
export type PageName = 'home' | 'lp1' | 'hub' | 'a1' | 'a2' | 'a3' | 'pl' | 'qd';
export interface PageProps { onNavigate: (page: PageName, target?: string) => void; }
```
- Each page is `'use client'`, default export, takes `{ onNavigate }`.
- Convert HTML → JSX: `class`→`className`, `for`→`htmlFor`, self-close void/inline SVG/path/rect/circle/use/img/br/hr/input, `style="..."`→`style={{...}}` (CSS custom props like `var(--x)` stay as string values), HTML comments → `{/* */}`.
- `data-goto="X"` links → `<a href="#" onClick={e=>{e.preventDefault(); onNavigate('X')}}>`. `data-goto="X" data-target="#y"` → `onNavigate('X','#y')`.
- Anchor links `href="#how"` stay as-is (smooth scroll within page).
- `<button data-theme-toggle>` → use shared `<ThemeToggle/>`.
- `<svg class="mark"><use href="#mark-lantern"/></svg>` → `<LogoMark/>` (or keep inline; symbol is in layout).
- `<span class="yr"></span>` → render `{new Date().getFullYear()}`.
- Each page uses `usePageChrome(rootRef)` hook for: header `scrolled` class on scroll>8, stickybar `show` on scroll>640, TOC active highlighting, progress bar width.
- FAQ items use shared `<FaqItem q={...}><p>...</p></FaqItem>`.
- Home page heatmaps generated from data arrays in React (no DOM manipulation).

## Tab → file map
| tab key | label | slice file | lines |
|---|---|---|---|
| home | Home | /tmp/page-home.txt | 355 |
| lp1 | Calculator | /tmp/page-lp1.txt | 377 |
| hub | Guides | /tmp/page-hub.txt | 148 |
| a1 | Bill | /tmp/page-a1.txt | 226 |
| a2 | Battery | /tmp/page-a2.txt | 201 |
| a3 | Tariffs | /tmp/page-a3.txt | 223 |
| pl | Quotes pillar | /tmp/page-pl.txt | 250 |
| qd | QLD install | /tmp/page-qd.txt | 170 |

---
Task ID: 2-lp1
Agent: general-purpose (lp1 converter)
Task: Convert the Solar Sensei "Calculator" (lp1) HTML slice into src/components/pages/lp1.tsx

Work Log:
- Read worklog.md, home.tsx (reference), types.ts, usePageChrome.ts, ThemeToggle.tsx, Faq.tsx, OptGroup.tsx, and the full /tmp/page-lp1.txt slice (377 lines).
- Read existing lp1.tsx placeholder (just a "Building Lp1…" stub) and overwrote it.
- Converted all markup faithfully: header (logo with onNavigate("home"), nav-links mixing page nav + on-page anchors, ThemeToggle, burger with data-burger), mobile-menu with data-mobile-menu, hero with window/panel/meter-bars, value-attribution (#driving1) vs-cards, baseline (#baseline1), plan-change (#plans1) with custom inline styles, your-data (#data1) with icon-bub SVGs, six-step how (#how1), outcomes cloud (#outcomes1), why-generic (#why1) q-grid, situations (#situations1) check-list, offer (#free1) with checks, .limits box, FAQ (#faq1) using <FaqList items={[...]}/> with 8 items, CTA (#cta1) with <OptGroup opts={[...]}/> (3 stacked options, first defaultSelected), mini footer (.f-mini) with footer-nav onNavigate calls, stickybar.
- Applied all conversion rules: class→className, for→htmlFor (none here), self-closed void/inline elements (<path/>, <circle/>, <use/>, <i .../> for meter/dot/wdot cells, <br/>, <img/>, <input/>), inline style="..." → style={{...}} with camelCase keys (fontSize, padding, width, background, color, marginTop, marginBottom, textAlign, maxWidth, fontFamily, fontWeight, letterSpacing, textTransform, alignItems, flexWrap, gap, margin), CSS custom-property VALUES like var(--teal)/linear-gradient(...) kept as strings.
- All data-goto links converted to onClick handlers (logo→home, Home/Guides nav links, "See sample output"→onNavigate("home","#results"), footer Home/All guides/Before you quote/QLD installs).
- Apostrophes in JSX text escaped to &apos; ("Why it's different", "Know what's creating the value", "When you're ready", "Choose how you'd like...", "Next, you'll be guided...", "Who it's for"). <span class="yr"></span> replaced with {year} const.
- Anchor links like href="#driving1", href="#cta1" left as-is for in-page smooth scroll.
- Ran `bunx eslint src/components/pages/lp1.tsx` → exit 0 (clean). Full `bun run lint` shows only the pre-existing layout.tsx font warning, not in my file.

Stage Summary:
- File written: /home/z/my-project/src/components/pages/lp1.tsx (overwrote placeholder; ~830 lines).
- All 12 sections + header + mini-footer + stickybar converted faithfully to original slice.
- Uses shared FaqList (8 FAQ items) and OptGroup (3 stacked options; CSS #page-lp1 .opts handles the column layout, so no columns prop needed).
- usePageChrome(rootRef) wired for header scrolled class, stickybar show, and burger menu toggle.
- Lints clean (zero errors/warnings for lp1.tsx).

---
Task ID: 2-hub
Agent: general-purpose (hub converter)
Task: Convert the Solar Sensei "Guides" hub HTML slice into src/components/pages/hub.tsx

Work Log:
- Read worklog.md, home.tsx reference, shared types/usePageChrome/ThemeToggle, globals.css class confirmations, /tmp/page-hub.txt (148 lines) and the original solar-preview.html hub section + the original hub-filter JS (lines 2739-2748) to mirror filtering semantics exactly.
- Read the placeholder hub.tsx and wrote the full replacement component.
- Converted the slice to JSX following the home.tsx contract verbatim: `"use client"`; imports `useRef`/`useState`, `PageProps`, `usePageChrome`, `ThemeToggle`; `HubPage({ onNavigate })` default export; root `<div className="page" id="page-hub" ref={rootRef}>`; `usePageChrome(rootRef)`; `const year = new Date().getFullYear()`.
- Header: nav-links with `onNavigate` for home, anchor links for `#hub-grid`/`#hub-start`/`#hub-cta` left as-is, `<ThemeToggle/>` replacing the raw themebtn, `<button className="burger" data-burger>` with self-closed `<span/>`s, `<nav className="mobile-menu" data-mobile-menu>`.
- Hero, hub-band (3 start-cards), hub-body (hub-top + cat-chips + featured + hub-grid + cta-sec), and `f-mini` footer all converted. `data-goto="X"` links → `onClick` preventDefault + `onNavigate("X")`; `data-target="#cta1"` → `onNavigate("lp1","#cta1")`. `<span class="yr"></span>` → `{year}`. Apostrophes (`can't`→`can&apos;t`) and `&amp;`/`&nbsp;` entities preserved. Inline `style="k:v"` → `style={{ k:"v" }}` (CSS vars like `var(--mut-2)` stay strings; numeric → "px"). SVG `<use/>` self-closed; JSON-LD preserved via `<script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(HUB_JSONLD)}}/>`.
- No stickybar present in the hub slice (usePageChrome gracefully skips absence) — did not invent one.

Stage Summary:
- File written: /home/z/my-project/src/components/pages/hub.tsx (full replacement of placeholder).
- Lint status: `bun run lint` → 0 errors / 0 warnings for hub.tsx (only the pre-existing layout.tsx font warning remains project-wide). tsc notes a RefObject<HTMLElement|null> → <div> mismatch that is shared with home.tsx, lp1, a3 (consistent contract pattern, not introduced here).
- Hub structure: header + hero-a (breadcrumb + lede + 3 m-chip meta) → hub-band `.start` (3 step cards: bill → tariff → lp1) → `.hub-body` containing `.hub-top` (title + "filter by topic" hint), `.cat-chips` (6 filter buttons), `.featured` (always-visible marquee card to `pl` with sparkline viz), `.hub-grid` (5 live gcards + 3 dashed `.gcard.soon` "Coming soon" cards), and `.cta-sec` (#hub-cta CTA box). Footer `f-mini` with brand + 6 nav links + copyright.
- Filter implementation: `const [filter, setFilter] = useState<string>("all")`. Each `.ccat` button maps filter key → label via a FILTERS array, with `className={"ccat" + (filter===f.key ? " on" : "")}` and `aria-pressed={filter===f.key}`, `onClick={() => setFilter(f.key)}`. Each `.hub-grid .gcard` gets `style={{ display: cardDisplay(cat) }}` where `cardDisplay = (filter==="all" || cat===filter) ? undefined : "none"` — exactly mirroring the original JS logic `card.style.display = (f==='all' || card.dataset.cat===f) ? '' : 'none'`. The featured card and start-cards are outside `.hub-grid` so they are NOT filtered (matches original behaviour). All `.gcard.soon` cards in the slice already carry a `data-cat` value, so they participate in filtering normally (no special-case needed). Anchor gcards use `onClick preventDefault + onNavigate`.

---
Task ID: 2-pl
Agent: general-purpose (pl converter)
Task: Convert the Solar Sensei "Quotes pillar" (pl) HTML slice into src/components/pages/pl.tsx

Work Log:
- Read worklog.md, home.tsx reference, shared types/usePageChrome/ThemeToggle/Faq, and /tmp/page-pl.txt (250 lines).
- Confirmed class names exist in globals.css (q-grid, q-item, icb, why, related, rel-card, limits-box, a-layout, side-card, side-cta, h3num, nbadge, cta-sec, cta-box, cta-trust, f-mini, meta-row, m-chip, crumb, faq-list, faq-item).
- Read placeholder pl.tsx and overwrote with full conversion.
- Converted class→className, for→htmlFor, self-closed void/inline SVGs (use, path, circle, span dots).
- Inline styles converted to style={{...}} with camelCase keys; var(--x) kept as string.
- `data-goto` links converted to onClick handlers calling onNavigate (with target arg when data-target="#cta1" present).
- `<button class="themebtn" data-theme-toggle>` replaced with `<ThemeToggle />`.
- Burger button given `data-burger`; mobile menu given `data-mobile-menu`.
- `<span class="yr"></span>` replaced with `{year}`.
- Two JSON-LD `<script type="application/ld+json">` blocks (BlogPosting + FAQPage) preserved via `dangerouslySetInnerHTML={{ __html: JSON.stringify(...) }}`; FAQ items shared between visible `<FaqList>` and the FAQ schema via a single `FAQ_ITEMS` const.
- FAQ block converted to `<FaqList items={FAQ_ITEMS} />`.
- Apostrophes in visible text converted to `&apos;` (can't, Here's, aren't, household's, doesn't); `&amp;` and `&nbsp;` preserved.
- In-page anchor links (`href="#pl-intro"` etc.) kept as plain anchors (no onClick).
- `<a class="logo" href="#" data-goto="home">` and breadcrumb / footer / sidebar / related-card data-goto links converted to onClick.
- Ran `bun run lint 2>&1 | grep -E "src/components/pages/pl"` — no errors for pl.tsx. (Only an unrelated pre-existing warning in layout.tsx.)

Stage Summary:
- File written: /home/z/my-project/src/components/pages/pl.tsx (~520 lines, full conversion).
- Lint status: clean (0 errors / 0 warnings for pl.tsx).
- Page structure: hero-a with breadcrumb + pill + lede + meta-row chips → `.a-layout` two-column grid (sidebar with TOC + side-cta + more-guides TOC, and `.prose` article with 8 h2 sections: pl-intro, pl-platforms (with chip row), pl-notlike (with `.why` callout), pl-why (plain ul), pl-paths (4 numbered `.h3num`/`.nbadge` blocks), pl-use (`.q-grid` of 9 question cards), pl-free (with `.icb` inline CTA), pl-faq (FaqList) + `.cta-sec`/`.cta-box` + `.limits-box` + `.related` keep-reading cards) → `<footer class="f-mini">` with year.

---
Task ID: 2-a3
Agent: general-purpose (a3 converter)
Task: Convert the Solar Sensei "Tariffs" article (a3) HTML slice into src/components/pages/a3.tsx

Work Log:
- Read worklog.md contract, home.tsx (reference patterns), types.ts, usePageChrome.ts, ThemeToggle.tsx, Faq.tsx, and the placeholder a3.tsx.
- Read /tmp/page-a3.txt (223 lines) — Tariffs article with hero-a, a-layout (sticky side + prose), TOU bar, period-grid, mis heatmap blocks, eq chip equation, steps grid, yn-grid, take, icb, cta-sec, related cards, f-mini footer.
- Verified all referenced class names exist in globals.css (a-layout, side, prose, tou, tou-bar, seg/seg-off/seg-sh/seg-pk, tou-axis, period-grid, period-card(.sh/.off), mis, mis-row, ml, blocks, eq, eq-chip(.result), eq-op, steps, step-card, step-num, yn-grid, yn(.y/.n), take, icb, cta-sec, cta-box, cta-trust, related, rel-card, hero-a, crumb, meta-row, m-chip, pill-lime, note-fine, plain, fmini, f-mini, mm-primary, mark, btn-teal, btn-nav, btn-block, stickybar).
- Wrote full a3.tsx following home.tsx conventions:
  * "use client"; imports useRef, PageProps, usePageChrome, ThemeToggle, FaqList.
  * Default export A3Page({ onNavigate }) with rootRef + usePageChrome + year.
  * Root <div className="page" id="page-a3" ref={rootRef}>.
  * JSON-LD scripts (BlogPosting + FAQPage) inlined as <script type="application/ld+json" dangerouslySetInnerHTML={{__html: ...}} />.
  * Header: logo (data-goto home -> onNavigate("home")), nav-links (mix of anchor #a3-* kept as-is and onNavigate hub), ThemeToggle replaces inline theme button, burger with data-burger, mobile-menu with data-mobile-menu.
  * Hero-a section with crumb, pill-lime, h1 with <em className="c-orange" style={{fontStyle:"normal"}}>, lede, meta-row chips.
  * a-layout: aside.side with three side-cards (TOC anchor links kept as-is, side-cta with width:100% button -> onNavigate("lp1","#cta1"), more-guides with onNavigate pl/a1/a2/hub).
  * article.prose wrapping all content with h2 ids matching the TOC (a3-what, a3-solar, a3-battery, a3-verdict, a3-plan, a3-faq) so usePageChrome can highlight active TOC link.
  * TOU bar rendered with .seg .seg-off/.seg-sh/.seg-pk divs and inline style={{width:"X%"}} widths (29.2/37.5/20.8/4.2/8.3) faithfully.
  * period-grid 3 cards (peak/shoulder/off) with <ul> bullet lists.
  * "timing mismatch" .mis heatmap rendered via MIS_GEN / MIS_USE color arrays mapped to <i> blocks (12 × 2hr bands) instead of inline-each.
  * .eq equation with eq-chip / eq-op / eq-chip.result.
  * .steps grid with inline gridTemplateColumns:"repeat(3,1fr)".
  * .yn-grid (y/n) "More attractive / Less attractive" lists.
  * .take key takeaways list (id="a3-take" on div as in source).
  * FAQ rendered via <FaqList items={[...5 questions...]} />.
  * .cta-sec/#a3-cta box with pill, h2, button (onNavigate lp1 #cta1), trust chips.
  * .related 3 rel-cards -> onNavigate pl/a1/a2.
  * Mini footer f-mini with f-logo (inline mark-lantern svg), nav (onNavigate hub/a1/a2/pl), p with © {year} Solar Sensei.
  * All class->className, for->htmlFor, self-closed void/svg/path/use/circle/img/br, style strings -> camelCase object style, HTML comments -> {/* */}, &amp;/&nbsp; kept, apostrophe -> &apos; (in "tariff's" / "You're"), data-goto/data-target -> onNavigate with preventDefault.

Stage Summary:
- File written: /home/z/my-project/src/components/pages/a3.tsx (full conversion of 223-line HTML slice).
- Lint: bun run lint shows 0 errors, 0 warnings for a3.tsx (only pre-existing layout.tsx font warning).
- TypeScript: tsc shows the same pre-existing RefObject<HTMLElement|null> vs Ref<HTMLDivElement> mismatch as home.tsx (project-wide pattern, kept consistent with home.tsx).
- TOC active-highlighting: h2 ids (a3-what/solar/battery/verdict/plan/faq) live inside <article className="prose"> so usePageChrome's `article h2[id]` selector finds them; the #a3-take TOC link scrolls to the div (id on the .take div, not h2 — source design, preserved).
- TOU bar: rendered as 5 .seg divs with their inline width % preserved exactly; classes seg-off/seg-sh/seg-pk carry the colours from globals.css.
- No globals.css/layout.tsx/page.tsx/shared-component modifications; no new dependencies added.

---
Task ID: 2-a2
Agent: general-purpose (a2 converter)
Task: Convert the Solar Sensei "Battery" article (a2) HTML slice into src/components/pages/a2.tsx

Work Log:
- Read worklog.md (architecture + page contract), home.tsx (reference patterns), types.ts / usePageChrome.ts / ThemeToggle.tsx (shared building blocks), Faq.tsx (FaqList named export), and /tmp/page-a2.txt (201-line slice).
- Confirmed existing src/components/pages/a2.tsx was a placeholder; read it before overwriting.
- Wrote full replacement following home.tsx conventions: `"use client"` directive, `useRef` root + `usePageChrome(rootRef)` + `year` constant, `id="page-a2"` on root div.
- Converted HTML → JSX: `class`→`className`, self-closed `<use/>`, `<span/>` (burger), inline `style="..."` → `style={{ ... }}` (camelCase keys, `var(--band-ink)`/`var(--teal-deep)` kept as strings, `font-weight:600` → `fontWeight: 600`), HTML comments → `{/* */}`.
- Apostrophes in text → `&apos;` (When it doesn't, battery's); preserved `&amp;` and `&nbsp;` entities to match home.tsx.
- `data-goto="X"` → `onClick={(e)=>{e.preventDefault(); onNavigate("X")}}`; with `data-target="#cta1"` added second arg → `onNavigate("lp1", "#cta1")` (header nav button, side-cta button, mobile-menu CTA, cta-sec CTA).
- `<button class="themebtn" data-theme-toggle>` → `<ThemeToggle />`.
- `<span class="yr"></span>` → `{year}` in mini footer.
- Burger button: added `data-burger`; mobile menu: added `data-mobile-menu`.
- Kept `<svg className="mark"><use href="#mark-lantern" /></svg>` inline in header logo and footer f-logo (per task instruction, did not swap for Logo component).
- Skipped the two `<script type="application/ld+json">` blocks from the slice for parity with home.tsx (which carries no JSON-LD); can be added later if SEO requires.
- Used shared `FaqList` component (single-open accordion) for the 6-item FAQ, matching home.tsx pattern.
- Article structure preserved: `<div className="wrap a-layout">` containing `<aside className="side">` (3 side-cards: TOC / side-cta / More guides) and `<article className="prose">` with 7 `<h2 id="...">` headings (a2-intro, a2-good, a2-bad, a2-questions, a2-assess, a2-quality, a2-faq) plus the takeaways `<div className="take" id="a2-take">`, cta-sec, and related cards.
- Mini footer `<footer className="f-mini">` rendered with `{year}`.

Stage Summary:
- File written: /home/z/my-project/src/components/pages/a2.tsx (~440 lines).
- Lint: clean — `bun run lint` shows only a pre-existing warning in src/app/layout.tsx (custom-font), zero errors or warnings for the a2 file.
- Article/TOC handling: usePageChrome scans `article h2[id]` (7 headings) and highlights the matching `.toc a` on scroll; the 8th TOC entry (`#a2-take`) sits on a `<div className="take">` wrapper rather than an h2, matching the original HTML — anchor jump still works, only active-highlight tracking skips it (faithful to source). No `<stickybar>` on this page (matches original slice); `usePageChrome` tolerates the missing selector via `if (sticky)` guard.

---
Task ID: 2-a1
Agent: general-purpose (a1 converter)
Task: Convert the Solar Sensei "Bill" article (a1) HTML slice into src/components/pages/a1.tsx

Work Log:
- Read worklog.md, home.tsx (reference patterns), types.ts, usePageChrome.ts, ThemeToggle.tsx, Faq.tsx, and /tmp/page-a1.txt (226-line source slice).
- Read existing placeholder a1.tsx and overwrote it with the full conversion.
- Followed home.tsx patterns exactly: "use client"; imports of useRef, PageProps, usePageChrome, ThemeToggle, FaqList; default export `A1Page({ onNavigate })` with rootRef and year.
- Root element: `<div className="page" id="page-a1" ref={rootRef}>` (id required for #page-a1 CSS).
- Header: logo (data-goto="home"), nav-links (1 data-goto + 4 anchor #a1-* links), nav-cta group (CTA button data-goto="lp1" data-target="#cta1" → onNavigate("lp1","#cta1"), ThemeToggle, burger with data-burger), mobile-menu with data-mobile-menu.
- Hero-a dark section: breadcrumb (home › guides › reading your bill), pill, h1, lede, meta-row with 4 chips.
- Article layout (.a-layout): sticky .side with three side-cards (TOC, side-cta → lp1/#cta1, more-guides with links to pl/a2/a3/hub), then `<article className="prose">` containing all h2[id] headings.
- Converted 8 article h2 sections: intro, look (with .bill illustrative + 6 numbered .h3num/.nbadge h3 subsections), formats (3 .fmt cards), gaps (.gap-card), steps (4 .step-card), quotes (.icb CTA), take (.take#id), faq, cta-sec#id, plus "Keep reading" related-cards section.
- FAQ: used shared <FaqList items={[...]}/> with 6 items matching the source (kept "don't" in q text, matching the rendered HTML — JSON-LD schema text preserves the original "do not" SEO wording).
- JSON-LD scripts: 2 module-level constants (BLOG_POSTING_LD, FAQ_PAGE_LD) rendered via `<script type="application/ld+json" dangerouslySetInnerHTML={{__html: ...}} />`.
- Conversion hygiene: class→className, self-closed <use/>, inline styles → style={{...}} (camelCase keys; var(--teal-deep) kept as string; fontWeight: 600 numeric), HTML comment → {/* */}, apostrophes in JSX text → &apos; (e.g. "you're", "retailer's", "won't"), kept &amp; / &nbsp;, cent sign ¢ and em-dash — preserved as Unicode.
- All data-goto links → onClick with preventDefault + onNavigate (target as 2nd arg where data-target present). Anchor links (#a1-*) left as plain hrefs for smooth scroll + TOC active-highlight via usePageChrome.
- Mini footer (f-mini) rendered with {year} for the © year span.
- Ran `bun run lint` — no errors for src/components/pages/a1.tsx. Only a pre-existing warning in layout.tsx (no-page-custom-font), which is unrelated.

Stage Summary:
- a1.tsx written (696 lines) — faithful Bill article conversion following home.tsx conventions.
- Article uses `<article className="prose">` wrapper with 8 h2[id] headings → usePageChrome auto-highlights active .toc a[href^='#'] link on scroll (hook selects `article h2[id]`).
- TOC links are plain anchor `href="#a1-*"` (no onClick) so the hook can manage `.on` state; cross-page nav links (More guides, side-cta, related cards, footer) all use onNavigate. CTA buttons targeting the calculator pass "#cta1" as the second arg so lp1 scrolls to that anchor.
- Lint clean for a1.tsx; no new dependencies added; globals.css / layout.tsx / page.tsx / shared components untouched.

---
Task ID: 2-qd
Agent: general-purpose (qd converter)
Task: Convert the Solar Sensei "QLD install" (qd) HTML slice into src/components/pages/qd.tsx

Work Log:
- Read worklog.md (architecture + page contract), home.tsx (reference patterns), types.ts, usePageChrome.ts, ThemeToggle.tsx, Faq.tsx, and the placeholder qd.tsx before overwriting.
- Read /tmp/page-qd.txt (170 lines) — QLD quality-install article with hero-a, a-layout (sticky side + prose), yn-grid (VIC vs QLD), steps grid (2 cards), q-grid (5 questions), icb, cta-sec, limits-box, related cards, f-mini footer.
- Confirmed class names in globals.css: hero-a, crumb, meta-row, m-chip, pill pill-orange/pill-lime, c-orange, a-layout, side, side-card, side-cta, prose, yn-grid, yn y, yn n, steps, step-card, step-num, q-grid, q-item, icb, cta-sec, cta-box, cta-trust, limits, limits-box, related, rel-card, f-mini, fmini, f-logo. No stat-chips in qd slice despite task hint (faithfully rendered only what the slice contains).
- Wrote full qd.tsx following home.tsx conventions:
  * "use client"; imports useRef, PageProps, usePageChrome, ThemeToggle. (FaqList NOT imported — slice has no FAQ block.)
  * Default export QdPage({ onNavigate }) with rootRef + usePageChrome + year const.
  * Root <div className="page" id="page-qd" ref={rootRef}>.
  * Header: logo (data-goto home -> onNavigate("home")), nav-links (1 data-goto hub + 3 anchor #qd-* kept as plain hrefs), nav-cta group (CTA button data-goto="lp1" data-target="#cta1" -> onNavigate("lp1","#cta1"), ThemeToggle, burger with data-burger), mobile-menu with data-mobile-menu.
  * Hero-a dark section: breadcrumb (home › guides › Queensland installs, all onNavigate), pill pill-orange, h1 with "Here's how to ensure a <em className='c-orange' style={{fontStyle:'normal'}}>quality install</em>", lede, meta-row with 4 chips.
  * a-layout: aside.side with 3 side-cards (TOC #qd-* plain anchors for smooth scroll + active-highlight via usePageChrome, side-cta -> lp1/#cta1 with style width:100%, more-guides -> pl/a2/a1/hub onNavigate).
  * article.prose wrapping all content with h2 ids matching the TOC (qd-intro, qd-mislead, qd-vic, qd-help, qd-ask, qd-value) so usePageChrome can highlight active .toc a on scroll.
  * .yn-grid rendered with 2 cards: <div className="yn y"> (Victoria — independent check, 3 bullets) and <div className="yn n"> (Queensland — self-reliance, 3 bullets) per source.
  * .steps grid rendered with inline style={{ gridTemplateColumns: "1fr 1fr" }} (the source had style="grid-template-columns:1fr 1fr"); 2 step-cards (Vetted installer selection, Free independent inspection).
  * .q-grid with 5 q-items (single div per source).
  * .icb inline CTA box (h3 + p + onNavigate lp1/#cta1).
  * section.cta-sec#qd-cta with cta-box (pill pill-lime, h2, p, button -> onNavigate lp1/#cta1, cta-trust 3 chips).
  * .limits/.limits-box with style={{ padding: "20px 0 0" }} wrapper and inner <p> with style={{ fontSize: "13.5px", color: "var(--l-mut)", margin: 0 }}.
  * "Keep reading" h2 + .related 3 rel-cards (pl, a2, lp1/#cta1) using onNavigate.
  * Mini footer f-mini with f-logo (inline mark-lantern svg), 4-link nav (hub/pl/a2/lp1#cta1 using onNavigate), p with © {year} Solar Sensei.
  * No stickybar in qd slice — usePageChrome gracefully tolerates the missing selector.
- Conversion hygiene applied: class->className, self-closed void/inline <use/>, <span/> (burger dots), inline style="..." -> style={{...}} (camelCase keys: display, gap, alignItems, fontStyle, width, gridTemplateColumns, padding, fontSize, color, margin; CSS custom-property VALUES like var(--l-mut) kept as strings), HTML comment -> {/* */}, apostrophes in JSX text -> &apos; (Here's, doesn't, you're, installer's, That's, household's), &amp; preserved (Solar &amp; battery calculator rel-card), em-dash — preserved, · and ✦ emojis preserved.
- All data-goto links -> onClick with preventDefault + onNavigate; target "#cta1" passed as 2nd arg where data-target present (header CTA, side-cta, icb CTA, cta-sec CTA, footer Calculator link, related calc card, mobile-menu mm-primary).
- Anchor links (#qd-intro, #qd-mislead, #qd-vic, #qd-ask) left as plain hrefs for smooth scroll + TOC active-highlighting via usePageChrome.
- Skipped the JSON-LD BlogPosting script from the slice for parity with home.tsx (which carries no JSON-LD); can be added later if SEO requires.
- Ran `bun run lint 2>&1 | grep -E "src/components/pages/qd"` — no matches (file is clean). Full `bun run lint` shows only the pre-existing layout.tsx no-page-custom-font warning, nothing for qd.tsx.

Stage Summary:
- File written: /home/z/my-project/src/components/pages/qd.tsx (full conversion of the 170-line HTML slice).
- Lint status: clean (0 errors / 0 warnings for qd.tsx); only pre-existing layout.tsx warning remains project-wide.
- Page structure: hero-a (breadcrumb + pill pill-orange + h1 with em + lede + 4 meta chips) → .a-layout two-column grid (sticky aside.side with TOC + side-cta + More guides, and .prose article with 6 h2 sections: qd-intro inspection gap, qd-mislead why comparisons mislead, qd-vic with .yn-grid VIC-vs-QLD comparison, qd-help with 2-card .steps grid (1fr 1fr), qd-ask with 5-item .q-grid, qd-value) + .icb inline CTA + section.cta-sec#qd-cta box + .limits-box general-information disclaimer + .related 3 keep-reading cards) → <footer class="f-mini"> with year.
- TOC active-highlighting: 6 h2 ids (qd-intro/mislead/vic/help/ask/value) live inside <article className="prose"> so usePageChrome's `article h2[id]` selector finds them; .toc a[href^="#qd-..."] links highlighted on scroll.
- No globals.css/layout.tsx/page.tsx/shared-component modifications; no new dependencies added.

---
Task ID: 3
Agent: orchestrator (main)
Task: Wire all pages, lint, dev server, Agent Browser self-verification

Work Log:
- Foundation built: globals.css (676-line Solar Sensei design system), layout.tsx (Google Fonts Poppins/Outfit/Fraunces/Inter, mark-lantern SVG symbol, next-themes ThemeProvider attribute="data-theme", favicon), providers.tsx.
- Shared components: types (PageName/PageProps/PAGE_TITLES/PAGE_TABS), ThemeToggle, Logo, Faq (FaqList/FaqItem with maxHeight animation), OptGroup, usePageChrome (scroll: header.scrolled, stickybar.show, TOC active, burger toggle) + useProgressBar.
- page.tsx: topbar 8 tabs, fixed progress bar, active-page state, onNavigate(page,target?) with smooth-scroll to target, per-page document.title.
- Home page built as reference (1007 lines): hero dashboard, heatmaps (React-generated from data arrays), trio, results+donut, brisbane, CTA form with OptGroup, limits, FaqList (8 items), full footer, stickybar.
- Dispatched 7 parallel general-purpose subagents (2-lp1, 2-hub, 2-a1, 2-a2, 2-a3, 2-pl, 2-qd) — all completed, each appending a worklog entry. qd retried once after a transient 429.
- All 8 page components lint clean (0 errors; only a benign no-page-custom-font warning in layout.tsx).
- Dev server running on :3000, GET / 200.

Self-verification (Agent Browser):
- Home renders fully (all sections, headings, FAQ accordion expands, theme toggle switches data-theme dark<->light, hub filter 8->1 cards, mobile burger menu opens).
- All 8 tabs switch + update document.title correctly.
- Cross-page nav links (data-goto) navigate correctly (e.g. Guides -> hub).
- Article page a1 renders breadcrumb + sticky TOC + prose + FAQ + related cards.
- Mobile (iPhone 14): hero stacks, burger menu appears and opens.
- Footer flush at page bottom (gap_px ~= 0.3, sub-pixel) — sticky-footer requirement satisfied; all pages are long so footer is always pushed down naturally.
- Sticky CTA (.stickybar) shows after scroll>640px, hides at top.
- CSS design system verified via computed styles: topbar/hero wash-lemon #FBFCE8, active tab ink(#191D19)-on-lime(#C9F24C), body Inter, H1 Poppins, pill-lime #F2F9D3.
- Zero runtime/console errors across all 8 pages (titles + H1s confirmed for each).

Stage Summary:
- Solar Sensei preview successfully converted to a production Next.js 16 single-route app with 8 client-switched "pages". Site is interactive, responsive, themed (light/dark), and faithful to the original v3.4 design. Browser-verified done.

---
Task ID: 4
Agent: orchestrator (main)
Task: Fix guide navigation "skipping" + add images to all guides

Work Log:
- Diagnosed navigation skip: `window.scrollTo` in onNavigate ran BEFORE React swapped the page, so the OLD page visibly jumped to top before the new page appeared. Cross-page target-scrolls (e.g. lp1#cta1) also caused a visible jump.
- Fix (src/app/page.tsx): replaced synchronous scrollTo-in-handler with a `useLayoutEffect([active])` that runs AFTER the new page renders but BEFORE paint — guarantees every page switch starts cleanly at the top with no flash. Cross-page target-scroll (rare, only CTA links) now deferred to next animation frame so the page paints at top first, then smooth-scrolls to the section (no double-jump).
- Verified formatting via VLM: hub + article pages were already polished (sidebar TOC, constrained prose column, callouts, cards, data-viz). No broken layout.
- Sourced images via `z-ai image-search` (--gl us, --no-rank): 6 hero images (hub + 5 articles) + 5 inline images. Downloaded to /public/guides/. VLM-verified each for relevance; re-sourced a1 (was a CPI chart), qd (was a video thumbnail), a1-inset (was a student reading), pl-inset (was a breaker panel).
- Added CSS for `.hero-banner` (rounded full-width image + italic caption, 440px max-height, responsive) and `.inset-img` (smaller inline figure) to globals.css.
- Created shared `GuideImage.tsx` exporting `HeroImage` + `InsetImage` components.
- Inserted HeroImage into all 6 guides' hero-a sections (after meta-row) and InsetImage into all 5 articles' prose (before the 2nd h2). Each article now has 2 images.
- Lint clean (0 errors). Dev server compiles.

Verification (Agent Browser):
- Rapid nav test: scrolled to 1800 then clicked each of 8 tabs — scrollY reset to 0 on EVERY switch (no skip). Zero runtime errors.
- Cross-page related-card nav (a1 → pl): scroll reset 5351 → 0 cleanly.
- Hero image loads on all 6 guides (hub, a1, a2, a3, pl, qd); inset image loads on all 5 articles. Mobile (iPhone 14): hero image renders at 342px width, loaded.
- VLM final check on Bill article: "hero image at top + second inline image in body + professional and well-formatted with no layout/image problems."

Stage Summary:
- Navigation "skipping" eliminated via useLayoutEffect scroll reset (page swaps now feel like clean separate page loads, starting at the top every time).
- All 6 guides now have a relevant hero image; all 5 articles have a hero + an inline image (2 images each). Formatting was already polished and is unchanged. Images are local in /public/guides (self-contained, always load).
