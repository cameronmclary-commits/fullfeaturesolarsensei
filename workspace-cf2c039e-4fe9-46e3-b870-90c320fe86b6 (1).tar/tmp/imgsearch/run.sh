#!/bin/bash
cd /home/z/my-project
run() {
  local name="$1"; local query="$2"
  z-ai image-search -q "$query" -c 4 --gl us --no-rank -o "tmp/imgsearch/$name.json" 2> "tmp/imgsearch/$name.err"
  echo "done: $name"
}
run hub "solar panels installed on Australian suburban house roof bright sunny day"
run a1 "Australian household electricity bill document with usage charges on table"
run a2 "home battery storage system wall mounted unit in garage"
run a3 "smart electricity meter digital display screen close up"
run pl "solar panel installer worker installing photovoltaic panels on residential roof"
run qd "Queensland Australia house with solar panels on roof sunny day"
echo "ALL DONE"
